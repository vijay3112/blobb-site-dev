export const environment = {
    production: true,
    API_END_POINT: "http://qa-api.blobb.in/api",
};
