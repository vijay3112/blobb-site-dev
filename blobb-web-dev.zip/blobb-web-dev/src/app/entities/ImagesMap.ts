  

export class ImagesMap { 
    id: string ; 
    name: string ; 
    data: string ; 
    type: string ; 
    rel: string ;   
}
