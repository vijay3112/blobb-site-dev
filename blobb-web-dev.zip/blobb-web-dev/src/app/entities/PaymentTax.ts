  

export class PaymentTax { 
    id: string ; 
    cost: number ; 
    cgst: number ; 
    sgst: number ; 
    igst: number ; 
    refType: string ;   
}
