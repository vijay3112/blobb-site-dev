/* ----appdata------ */
export class AppData {
  id: string;
  name: string;
  code: string;
  data: string;
  active: boolean = true;
  updatedBy: string;
  updatedOn: Date;
}
