export class ImgSrc {
  id: string;
  name: string;
  src:string;
}
