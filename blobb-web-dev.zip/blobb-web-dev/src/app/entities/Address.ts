export class Address {
  id: string;
  lane: string;
  landMark:string;
  city: string;
  state: string;
  country: string;
  zipcode: number;
}
