export class Profile {
  id: string;
  name: any;
  email: any;
  mobile: string;
  status: string;
  role: string;
  active: boolean;
  createdBy: string;
  createdOn: Date;
  updatedBy: any;
  updatedOn: Date;
  data: any;
}
