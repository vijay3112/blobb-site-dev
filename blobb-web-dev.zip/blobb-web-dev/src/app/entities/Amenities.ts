export class Amenities {
  id: string;
  name: string;
  data: string;
  active: boolean;
}
