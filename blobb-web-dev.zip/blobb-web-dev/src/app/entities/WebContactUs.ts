export class WebContactUs {
    id: string;
    name: string;
    email: string;
    countryCode: string;
    mobile: string;
    message: string;
    active: boolean;
    subscribe: boolean;
    vid: string;
    createdBy: string;
    createdOn: Date;
    updatedBy: string;
    updatedOn: Date;
}
