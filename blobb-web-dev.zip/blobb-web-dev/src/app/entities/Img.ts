export class Img{
  id: string;
  name: string;
}
