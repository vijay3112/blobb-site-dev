  

export class WebMetadata { 
    id: string ; 
    name: string ; 
    title: string ; 
    summary: string ;   
}
