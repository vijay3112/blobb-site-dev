export class CorporateBooking {
    id: string;
    name: string;
    email: string;
    mobile: string;
    companyName: string;
    message: string;
    active: boolean = true;
    createdBy: string;
    createdOn: Date;
    updatedBy: string;
    updatedOn: Date;
}
