export class AppSubscribe {
    id: string;
    name: string;
    email: string;
    mobile: string;
    active: boolean = true;
    createdBy: string;
    createdOn: Date;
    updatedBy: string;
    updatedOn: Date;
}
