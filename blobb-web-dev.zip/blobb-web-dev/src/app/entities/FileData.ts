export class FileData {
    id: string;
    name: string;
    ref: string;
    refType: string;
}
