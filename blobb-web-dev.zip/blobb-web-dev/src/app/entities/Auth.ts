export class Auth {
    mobile: string;
    email: string;
    countryCode: string;
    userid: string = "";
    password: string = "";
    token: any;
    vid: string;
    username: string = this.vid + "-" + this.userid;
    img: string;
    provider: string = "email";
}
