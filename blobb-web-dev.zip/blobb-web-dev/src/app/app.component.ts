import { Component, OnInit } from "@angular/core";
import { ApexService } from "./shared/service/apex.service";
import { AppService } from "./shared/service/app.service";
import { MatIconRegistry } from "@angular/material";

@Component({
    selector: "app-root",
    templateUrl: "./app.component.html",
    styleUrls: ["./app.component.scss"],
})
export class AppComponent implements OnInit {
    title = "Zero";
    menuList: any[] = [];
    sessionUser: any = null;

    constructor(private apexService: ApexService, private appService: AppService, private _iconRegistry: MatIconRegistry) {
        this.assetsIcons();
        this.apexService.menuEvent().subscribe(($event) => this.menuEvent($event));
        this.apexService.sessionUserEvent().subscribe(($event) => this.sessionUserEvent($event));
    }

    ngOnInit(): void {
        let sessionUser = this.appService.getSessionUser();
        this.appService.sessionUserEmit(sessionUser);

        let menuList = this.appService.getSessionItem("menu");
        this.appService.menuEmit(menuList);
    }

    menuEvent($event: any) {
        this.menuList = $event;
    }
    sessionUserEvent($event: any) {
        this.sessionUser = $event;
    }

    outputEvent($event: any) {
        if ($event) {
            this.appService.navigate($event, []);
        } else {
            this.appService.sessionUserEmit(null);
            this.appService.navigate("", []);
        }
    }
    assetsIcons() {
        this._iconRegistry.addSvgIconInNamespace("assets", "logo", this.apexService.bypassURL("assets/icons/logo.svg"));
        this._iconRegistry.addSvgIconSetInNamespace("icon", this.apexService.bypassURL("assets/icons/icons.svg"));
    }
}
