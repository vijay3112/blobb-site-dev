import { Component, OnChanges, SimpleChanges, Input } from "@angular/core";
import { DomSanitizer, SafeUrl } from "@angular/platform-browser";
import { ReportService } from "../service/report.service";
import { Props } from "../../constants/props";

@Component({
    selector: "img-load",
    template: `
        <div class="img-box" [style.height]="height">
            <img [src]="placeholder" [style.height]="height" [style.borderRadius]="radius" [alt]="alt" [style.fill]="fill" />
        </div>
    `,
    styles: [
        `
            .img-box {
                width: 100%;
                height: auto;
                margin: 0 auto;
                overflow: hidden;
                background: transparent;
            }
            .img-box img {
                position: relative;
                height: auto;
                left: 50%;
                -moz-transform: translate(-50%);
                -ms-transform: translate(-50%);
                -webkit-transform: translate(-50%);
                transform: translate(-50%);
            }
        `,
    ],
})
export class ImgLoadComponent implements OnChanges {
    @Input()
    img: any = null;

    @Input()
    id: any = null;

    innerValue: string = null;

    @Input()
    height: string = "auto";

    @Input()
    radius: string = "5%";

    @Input()
    alt: string = "";

    @Input()
    fill: string = "gray";

    @Input()
    type: string = "img";

    _placeHolderSafe: SafeUrl;

    constructor(private sanitizer: DomSanitizer, private reportService: ReportService) {
        this.imgChange();
    }

    get placeholder() {
        return this._placeHolderSafe;
    }

    ngOnChanges(changes: SimpleChanges) {
        if ((changes["img"] && changes["img"].currentValue != null) || (changes["id"] && changes["id"].currentValue != null)) {
            this.imgChange();
        }
    }

    imgChange() {
        // console.log("-----------------------------");
        // console.log(this.img);
        // console.log(this.id);
        // console.log("-----------------------------");
        if ((!this.img || this.img == "") && !this.id) {
            this.innerValue = this.gif();
            this._placeHolderSafe = this.sanitizer.bypassSecurityTrustUrl(this.innerValue);
        } else {
            //this._placeHolderSafe = this.sanitizer.bypassSecurityTrustUrl(this.img);
            if (this.img && this.img != "") {
                this.innerValue = this.img;
                this._placeHolderSafe = this.sanitizer.bypassSecurityTrustUrl(this.innerValue);
            } else {
                this.imgload(this.id).then((imgData: any) => {
                    this._placeHolderSafe = this.sanitizer.bypassSecurityTrustUrl(imgData);
                });
            }
            // console.log(this.img.length)
            // if (this.id) {
            //   this.imgload(this.id).then((imgData: any) => {
            //     this._placeHolderSafe = this.sanitizer.bypassSecurityTrustUrl(
            //       imgData
            //     );
            //   });
            //   //this._placeHolderSafe = this.sanitizer.bypassSecurityTrustUrl(this.img);
            // } else {
            //   this.innerValue = this.img;
            //   this._placeHolderSafe = this.sanitizer.bypassSecurityTrustUrl(
            //     this.innerValue
            //   );
            // }
        }
    }

    imgload(id) {
        if (this.type == "img") {
            let url = Props.API_END_POINT + "/" + this.type + "/" + id;
            return new Promise((resolve, reject) => {
                var xhr = new XMLHttpRequest();
                xhr.open("GET", url);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = () => {
                    if (xhr.readyState == 0 || xhr.readyState == 4) {
                        var data = xhr.response;
                        resolve(data);
                        //   if (data.status == 1) {
                        //     resolve(data.data);
                        //   } else {
                        //     this.errorMessage(data.error);
                        //     reject(data);
                        //   }
                    }
                };
                xhr.send();
            });
        } else {
            return Promise.resolve(Props.API_END_POINT + "/" + this.type + "/" + id);
        }
    }

    gif() {
        return `data:image/gif;base64,R0lGODlhZAA4APUAAOjQ0I3OskOF9uSYkoew9DSudE23hu7Yjdjj8nSj9u/TdmKZ9uro1wGgWuF4bu3doqvYx/LAFent8OLq8QCeVfHHPcji2uns5t5TQ+WqpvDMVqTC9BmmZeBmW/S6ANXn49/r6+vjxens6+vhtG/CnOjh41iT9snb8+BiVPHDKt1KOea/vejn6bXN89rp5168kN1IN+jc3U6L9uKJgEGyfeTs7unu8c/l37nQ8/W1AD6C991DMN9bTdxDMOnu8P///yH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpERDBFMjI2NTY2NTIxMUU0QjQ0Q0QyRTEzRjJEQUU3RSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpERDBFMjI2NjY2NTIxMUU0QjQ0Q0QyRTEzRjJEQUU3RSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkREMEUyMjYzNjY1MjExRTRCNDRDRDJFMTNGMkRBRTdFIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkREMEUyMjY0NjY1MjExRTRCNDRDRDJFMTNGMkRBRTdFIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkEBQIAPwAh/iBDcm9wcGVkIHdpdGggZXpnaWYuY29tIEdJRiBtYWtlcgAsAAAAAGQAOAAABv9An3BILBqPyKRyyWw6n9CodEqtWq/YrHbL7Xq/4LB4TC6bz+i0es1uR23wuHw+d4vpeLw9nO/H92B+foBHNjUniCc1NlCCfYRGCAkyAgIyCQhELBkdKiodGSxEFwcROTkRBxdyIAEFDQ0FASCQRQs6uLkLRA47vr8ORBWnxDkVcgYUyssGtUS50DpEv9Q7RMXFcg3Lyw3OQ9G509W+19inctzc30LhuOPk5ufp6srsPu7SQ+TlQ+focerZY5cPXjV52OjVu1dwHz+E2QIKZOjOIDWIxBSqoxjO4i+MAOEIpMAxmsd+Qv7l0LiOYEWH8fz9Y7msJLST1mTOk7jQZUesmAd1JuS50adJoBeFRhQ50ehNpB+VZiTa8ltDIfxyppxJtaZTcVBR+lBJc6DVl1gfSg1pY6RNsGljbt3JtOfZn3GDzh1at+jdo3mT7l1qY5s6b+xuRds1pFe1YEOGYTsWJ5m6ZuwkUbKESRMnGDBAiRpCyhQqVaxcwZJFi52hRIoYPXGU5x4W2npsW8FNR/du3nJ8VwEeXLjx48iTK1/OvLnz59CjS59OvTr0IAAh+QQFAwA/ACwcAA0ACAAcAAAGLEDbpLXZtCY2hEmg0wlMiEVzqpNSr9isdsvter/gsHhM5lqpCyXTCRUSjcggACH5BAUCAD8ALBwADAAIAB4AAAYxQNsEt9ngJjZEQiYQyBJKnXSaEEyn1qt2y+16v+CweEwum8/f7FWQ2EKXzSdCSDQigwAh+QQFAwA/ACwcAAsACAAgAAAGMUDbZEMgbCY2hEmg0wlMiERzqkswqU6sdsvter/gsHhMLpvP4CtVIMUmlNcnQkg0IoMAIfkEBQMAPwAsHAAHABQAKAAABp5AG4KwWBAQtqRyqUQsBDqdYIFkWgnRrI5gtcq0UVmXCc6Ol+XoWZnWrZNtZmngcAxKtrgyo9r5dyoZekl9f34qgzaGhomLf42OO5COk4uVjGlLkZKZSpuXj51Jn6KKkaB+qJxlmqelpKyerrGjs2CtlK+2WriWpYWGiKV8wYKlNnN1d3nHXYljz11fYGJvWGBcb05QUlRvSUNFR982QQAh+QQFAgA/ACwcAAQAFAAuAAAGnkBbDUFE1GzIpDJZOyUEgsTpuKwiZLqsToaoVglaLeFHLpvJWB05Kzu7fwJ3/G1Wn+30vH5/Zq0yGSssfD8lDhg7OxgOJXwOiZA7DnwwO2Y7MHyWZ5uEnp+goaKjpKWmp6ipqqusra6nnWWxdJWXmXuPkZJ8hoiKjIR+gIKleGXGdHNmynlpa1t8YGE6Y3tXYVxeS01PUVPa20VG4EpBACH5BAUDAD8ALBwAAwAgADAAAAb/QMlkQyBsJpKkcslsLocLgWBxdFqvOIFuqxPgrmBmQvcr/3SJsFoiM5tl67DAXRbEwWS67n6lm5ciAA4YGA4AImp+ZUsrKjuPOyoriYpLHZCQHZR+S5BljzCbdJ1+O00iqIgSij+kdKZKrKxLs7GynLa4Sbe6q5W5vIvAbrTBf8PHu8bCyr3LzL7Oz8XSy9SjyLfXxNmy28nRxt/Qz63d497n3bXN2O3B6Ojs4dzvvPHrv/bk0+r76f/k6aMHrpwrN7D+zdtR6lSqgEo8/YAkqp6ES5h2aAozrxEmSRXBBRpU6JCaPG728HEyh46dlU3a0IEDUwzKM2lqLsnCpcsXEJ1KoEihggRoUCJGihqVEAQAIfkEBQMAPwAsHAADACAAMAAABv9AG4JgMhEQtqRyyWwuEQnZ7ydLIJ1Y7GbK/W2yYOaiO12EzzYB+SdAh3VrHbO0ymRWJfR6uizNeDAwPDN5YXs/SwM9i4wDZ4dLPIyMPI97S5OTlmuYmYubZJ2eTCIhIyMhIjaQSp6fSgwpHlMeKQysSa49SxFrvZetrkuHuDa6w8ScwaNKycq5ws3OXaKZyNN8y9bS2IjamtzY1eBJ3dnQzOXm44zX4t/t4dPsr+rd9Lvyzvju8/D1q9b9y2fvHbptBf0dJBfw3sB++x7qS8ZPya8uF0NJTBJr1o9at4AtjKek1KlUDTWOBIil2DFDIm1IylQJ5jMbijI5sqnShh8rQIIInYFDRk6fOncKhVFDpo2bLGPImHmqZc0Xqk6gSKFiBSuWIUWOeHUSBAAh+QQFAgA/ACweAAMAHgAwAAAGp8CETJb4GY/IpHLJbDqf0Kh0uozNOp1ZjFpFqXY7FWrLRc7A6N2sjMSkwRj28Y2WG+lg+w+/0/OTDAoVFQoMT39HBzk5RosHTohGHkqTTZFsl2WZXJtUnVOfUqFRo1Clh3h+qXankKtyrZavmLOatZy3nrmgu6KzlUjAS5eKjD+OrnSAgoSGyW+qyqy9UW5vcXZnb2t2MV5gYmTdV1nieufo6UpCROpBACH5BAUDAD8ALBwAAwAgADAAAAb/QIlwSCwaj0UEYbEgIIwxh0rliCGTCZlAIEs8h7GOardTdaxX4Ubwa/8EG+KATN8N0sKF270goupkKHgSbHtvRGM7bWQqg4ZuRIqGO46PP5GPlHiWl0OcRQwHGhoHDBKfnpZEDB45rjkeDKhCsxIpr68ptbW4uLuqQzmPwsC0xRLEe8mGRL+cj83Hz9LU03vR0KnWkNrM3dvY3sbbbeHX39bm3OPk6uXo0+6d7ODw86fk7/Tr+Pny8s7E9WtnD2A1gfn0DTy3L15BewEZLkz3sOGzf8GGReS3rE1Hfrx6udqo8FYvXQclssIVi+Q9CaFGlZqoUNIeTWlq2XSD80qhND0CEJFZVGaQHkN9hvwBJAjPGqBxhswBdAcPgixbunwREiaRGTRWlzTZCkYKFbCD0qodEgQAIfkEBQMAPwAsHAADACwAMAAABv9Am3BIHMZmPN4sVmw6n1BhyYHZ7TCOUnTLHWasv5810+UiEjJZAlHshN+/TjmKMAnCAhN7qIKHVXNQBHdvAgREO35iRRcjDw8jF10yijJEimFEFwoeOTkeCpJbhHACl5hEB56rOQeYr36nikSdrJ+wuD+ysUOecL65r7twRDmKxsGoQ8LLwTUWEBAWNbDDb9aKHwYcYRwGH8xC4TbBBYrmyuLp5LkUiu7r48nzus2z9vS42PXq+fr4xAD6u9ePV8GBBNklRFhNYCaHDPkpNDgx4jWI+xjuy4hwI0SNGD92DHnQokR5JgOWfLgyoseWIFtyHPiyosmaweDB0UkRJS5xdHCA9oyXSxu3H97AEV3oDJo0aj4pIvsV0yZLG8DCZPVXsxYrD8FIFaqpyparXJT8WCJpY1MtUKKiDCp1aEgiPzsYOYIUl44dPHqI9PEDKNCTM2nWtFEkx7DjDDDu7oBBxrHhKVWuZLHs+EiSJZyLBAEAIfkEBQMAPwAsHAADACwAMAAABurAn3BILKJQxaRyyWw6n9DoT3JhMC6SqG3LlQoloYrHUwllndy0zcvw5N45D+NpqyHuiNpaWoHDK081LQsCAgstNV5uOUJvHk8tAkQCLV6MRZdNC0mbUplDn0uSRaNepqeoPy4QAQEQLqmmNxwNFBQNHDexUgW2vhQFu1EUScTCx8jJysvMzc7P0NHS09TV1tfY2drb3N3e18ZE4dC9v8DTs7W3udSrra8/pUPyz51E9lChP/pJkZOVnpLwKyKIkCFEit40ikPHDh49Xvr4yQEIjZotbBY5mkNHjSkwYsiYoUbFCpZvx44oCwIAIfkEBQIAPwAsHAADACwAMAAABv/An3BIHLJWmcyKVWw6n1AhK9NRqToZJlEUGo1CoqiYCFARVYDtKJXLpUbhsdjRpA9DnnbbE5KLMU2AQxU5RDkVcjaKi35DHk2PYouTNo0/hUWYUTYIGwQEGwiVlqRCCAsCqQILCKWlCU2wrlAuASQkAS4/Ak28s043HA0UFA0cN7+NNMRCxDTJfg1N0tDV1tfY2drb3N3e3+Dh4uPk5ebn6Onq6+zt7tzURPHeyxTNFDS+RPrWwcPFx2QREXit1q1cP06pWtUKHCdPoESFo8SokaYhF6FQJBWJSMdfgoiE/EHIECJodoik/IFHTw4+1cqcSTNExJo2b+Ikm9IBBgwOLFpqdvmiE9qRJEusBQEAIfkEBQMAPwAsHAADACwAMAAABv/An3BIHNqOyKJyyWwKbbEZCjWL2YqMisdTYTi/xJIDI8Q4SkRGxCP0RLzgbwZGhGWIihwxp4h/O0qAQ2xFhH5MdEUqe0p6h4+QTEhJkZE2EzgbGzgTV5VNLgEvLwEuPwgJMgICMgkIn0w3HA0UFA0cNwlKurBKNLVCtTQCSsS9RQ1KycdgFErOzNHS09TV1tfY2drb3N3e3+Dh4uPk5ebn6OnqRNDsxkTv0ctEDbxE9tG/0MKoqqyu1GTRsoXrUqZNnaqFGlXqySRP68AlqsOoiKNegohk/GFoELM7RUAKybOnzzExZH6YQTNEDSE3cHpBkULFChYtXGIeewixVxAAIfkEBQMAPwAsHAADACwAMAAABv/An3BILBqJjIrHU2Ecn1ChbUotMlKeXM6Tcka/UqqYqNAKtQowWDweRoxvddRWygwGmZKNmDP2iTckNDQkN2olMzwwMDwzJXJCNwUNFBQNBYZfAz2cnQOQPy+VoxQvYDydnTygHKSVHD9se0SpqaCuo7JTtLWct5VCubq8vbdGFDYIGwQEGwizQr2+kBTHOAJEAjjEtaBPMkbgQ9I93uY/5Ofe6eqQ7O1q7/Bf8vNQ9fZH+PlF+/zj0v7dCyhQH8GC/Q4iBFhsITdbDhl2ixhNoUN/AjH+08iPoxpxRECis3juWrZtEiHCS7as2bOHnYwVQTYsZUxqx3RBG9lQzqhPYMBkJeypBhewL6hqrYLUyhUsTb0+QRLlytQXREkbPYIkiZIlTGvq3Mmz8w+fIoEKFCikRieROG/tuR1S5g+afEKRYNHCxQvFH0mWNFETBAAh+QQFAgA/ACwcAAMALAAwAAAG/8CfcEgsGomXh0LxuByf0OjwcogIIwcnsWbpWmrSsHBkJA9rEFqjQYOAxdGKUT60NCh4SsMitvn/RR5GgkMveXkvYX+LNnBCHHhCeByKjH6OPxRGDYolAw4OAyWNjppFplExGDusOxgxmLFDDq2tDrKyMLWsKrhGNjXBNaRDu62+WxsLAgILG29CxqzIQwlG1sXS1EICRt3Zxtti0jviYeTmUujpUOvsR+7vRfHy4Lv1RvT4+vX88v7vALITmI6gOYPiEG5TSI0hlG9EIP5w+AQbEYsTtW2roYyZM2gZw4kDJoxYNI34hujaBSMlEVq7brkUoqrWq5lCbHgCJcpkGEBUQ4A+sXSplBGhR4j6lALJ1KQ+jAINImLoEIVE2+gQ0frDzqE94swQEfsDjRo2bsRRsfIDi5YzXr6kS7KkiZggACH5BAUDAD8ALBwAAwAsADAAAAb/QJ9wSCwaj0ifK0AiBVzJaFIkOoIChUajEABJv0JGxeOpMIqQBmVNaUDAUobnR/95zkMapf6j0OBRGnx0GkQcgz8cgElzgx5Ee4MUi0iIdESWk5RGlj+YlpucoEOdYCIAKysAVZ+IrYNfJTM8MDA8MyWvfLp1Xw6IDryXpJYTiBNEMIgwwp7Ena7PsNK71NDDQqXW2D7X0dmj4N/d3tXi0+fm5OXc2um929DN8/Hu6+j36uzw7+3h+d7o9XM20J7Bf/v8jTu4TyBAhewcMowYT2JCiwsvVtxYEKHHjA05PiQ4cqK+jxQHYkw5cmU5l/xGGhuEbIiyQcxE2kPya1AwVZ3/kMiiZQsXTG5TUKliBXRcqJYin5qMKRWluqeN+DwaEomPpqdCBA0qNOTQIEVgw2S1g0eIHq9/0oYZU6atkDRs2ryRO4SKFSxauHjh+2VJkyc+ggAAIfkEBQIAPwAsKAADACAAMAAABv9Am3BILBqJtxeH87odn1Dbx8D5/TiGT3Q7DFi/vwDXxlBUKgpGsQC2FriMisfqqaiHjfavwVXoFUR6VlxzbR6BglyCP4h6iolDi4+OkYksMQAAMSxFkpV6JTM8MDA8MyWNbalgDj2urw6rX7JWr7Y9tIyfbbevubm9rr+7YMG4xLPItcHDQovGzTbPzMq6zoLQ1cDU15TdvNzSkN/F4Z7kX9nog9Xq4t7v4L3R0/Pa7ebj8eX269b76fLBq3eLHjaBqvD1A8jOn7tzDH+0uhXrnr9Qo0qdMujoUqZNnfRBfAJx5JGS+kiKTHmkEJhDFqH4aQMo5pM4hercEZKnDR8eOGbQ7BTCps2bMVG8tBGDFMqUKleyNI2SZEkTG0EAACH5BAUDAD8ALCgAAwAfADAAAAavwJ9wSCwai4ZGw3BsOoW0H4Xyiz6v2Kdty81ebZeDQnG42LzOi8Yj9Ggu6KbCOI8b2UW8fc/fc7t9QzYlGTMzGSVngT8rKjuPOyoriz8YkJAYlJeXmpuPnZ6gm6Kci56fpqekkKuogac7rbGpobSjtqWvqrisvK59sLLCi5abmYuNl5KUg4WHiZQ/f1vR1daUekPZfHVE3X1qeG5wi2BiZGbR04rX7VdRU1XWSUs/QQAh+QQFAgA/ACwoAAMAIAAwAAAGscCfcEgsGom2pPLIbP5st1eh8LrZnNjhx8BpNDiGTzYbaBAbgbFySSwY3dj1+mw0x+XJ8R2vd9ouDwcHDxdXfUwMFR5CHhUMh0wVRpJZfJBHLBkdKiodGSyXRg6ioaWmp6ipqqusra6vsLGys7S1tre4uX2jRbynmR0wMJ6gqZa0lETJpomLP42PqH+Bg4XGeIan2Nmm23RFdntsQ3BtqWVnaahbHEJgYtJRU1Xc3XI/QQAh+QQFAwA/ACw0AAQAFAAuAAAGgMCfcEgc2o7IolKIbNqWRdvtxeG8bk/o8FZoCBuFm3b4UpbHP45SjdY6s+j3sW27jB6P0QWuZaQ8Qh4pDG0pSoZtiYqLjI2Oj5CRkpOUlZaXmJmam5GIRJ59f4GDdHZ4enxQcqmqTpyJbESxWmdEtVpcXj9gYnFTVVesSquJbz9BACH5BAUDAD8ALDQABgAUACoAAAaBwJ9wSBzajsiiUohs2pZFW+1zu31qT+iwBqE1GjRITTuENIgNCFlYULbX5+LZmV3bRIxQiCGqaxkaHkIeGgxrPylKiYeMjY6PkJGSk5SVlpeYmZqbnJ2Hi0Sgf4GDhYd3eXt9jHSYcWiHb0SyWmZoamtcXmBip1NVV35QdEesTj9BACH5BAUCAD8ALDQACAAUACYAAAZswJ9wSBzajsiiUohs2pZFmwsSCEBcT+jwY+A0GhzDRzt8Kc3kX0O5dmbTl0NEGDlc0r+KUo/v+/+AgYKDhIWGh4iJiouMjY54fESRWnFzP3V3eG6Ja0WdZGhEoVpcHEJhY2lSVFZYmm5vZJtBACH5BAUDAD8ALEAACgAIACIAAAY3QJtwOARBAgEIyPYxcBoNjqFJqVoNDas1q+16v+CweEwum8/otHr95WobBu/UCZV+bEakksgPAgAh+QQFAwA/ACxAAAsACAAgAAAGMUCbcEgsGomuAIkUcNkgDYqU0oBwptMrdsvter/gsHhMLpvPYi2WA8VWbcll80iv24IAIfkEBQMAPwAsQAAOAAgAGgAABitAiXAoBAUKjUYhADL8nlBDAwqdUq/YrHbL7Xq/4LD4a6U2nFeDEalkEolBACH5BAUqAD8ALEEADgAGABoAAAYVQJtw+Csaj8ikcslsOp/QqHS6HA6DACH5BAUDAD8ALBwADgAIABoAAAYcQIlkQpwIf8ikcslsOp/QqHRKrVqv2CxSWDRKggA7`;
    }
}
