import { Component } from '@angular/core';
import { MouseEvent } from '@agm/core';

@Component({
    selector: 'agm-maps',
    template: `
                <agm-map 
                [latitude]="lat"
                [longitude]="lng"
                [zoom]="zoom"
                [disableDefaultUI]="false"
                [zoomControl]="false"
                (mapClick)="mapClicked($event)">
              
                <agm-marker 
                    *ngFor="let m of markers; let i = index"
                    (markerClick)="clickedMarker(m.label, i)"
                    [latitude]="m.lat"
                    [longitude]="m.lng"
                    [label]="m.label"
                    [markerDraggable]="m.draggable"
                    (dragEnd)="markerDragEnd(m, $event)">
                    
                  <agm-info-window>
                    <strong>InfoWindow content</strong>
                  </agm-info-window>
                  
                </agm-marker>
                
                <agm-circle [latitude]="lat + 0.3" [longitude]="lng" 
                    [radius]="5000"
                    [fillColor]="'red'"
                    [circleDraggable]="true"
                    [editable]="true">
                </agm-circle>
              
              </agm-map>
    `,
    styles: [
        `agm-map {
            height: 300px;
      }`
    ]
})
export class AgmMapsComponent {
    // google maps zoom level
    zoom: number = 8;

    // initial center position for the map
    lat: number = 51.673858;
    lng: number = 7.815982;

    clickedMarker(label: string, index: number) {
        console.log(`clicked the marker: ${label || index}`)
    }

    mapClicked($event: MouseEvent) {
        this.markers.push({
            lat: $event.coords.lat,
            lng: $event.coords.lng,
            draggable: true
        });
    }

    markerDragEnd(m: marker, $event: MouseEvent) {
        console.log('dragEnd', m, $event);
    }

    markers: marker[] = [
        {
            lat: 51.673858,
            lng: 7.815982,
            label: 'A',
            draggable: true
        },
        {
            lat: 51.373858,
            lng: 7.215982,
            label: 'B',
            draggable: false
        },
        {
            lat: 51.723858,
            lng: 7.895982,
            label: 'C',
            draggable: true
        }
    ]
}

// just an interface for type safety.
interface marker {
    lat: number;
    lng: number;
    label?: string;
    draggable: boolean;
}
