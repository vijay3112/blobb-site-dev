import { Injectable, Inject } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Props } from "../../constants/props";
import { Util } from "../utils/util";
import { ApexService } from "./apex.service";

@Injectable()
export class HttpService {
    private host = Props.API_END_POINT;
    private altHost = Props.API_END_POINT;

    constructor(private http: HttpClient, private apexService: ApexService) {}

    get(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        let paramString = Util.GetParamString(data ? data.data : {});
        url = this.host + url + paramString;
        return this.http.get(url);
    }

    post(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        url = this.host + url;
        return this.http.post(url, data);
    }

    put(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        url = this.host + url;
        console.log(data);
        return this.http.put(url, data);
    }

    delete(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        let paramString = Util.GetParamString(data ? data : {});
        url = this.host + url + paramString;
        return this.http.delete(url);
    }

    formData(url: string, _formData: FormData, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        url = this.host + url;
        return this.http.post(url, _formData);
    }

    getAlt(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        let paramString = Util.GetParamString(data ? data.data : {});
        url = this.altHost + url + paramString;
        return this.http.get(url);
    }

    postAlt(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        url = this.altHost + url;
        return this.http.post(url, data);
    }

    putAlt(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        url = this.altHost + url;
        return this.http.put(url, data);
    }

    print(url: string, data: any, loader?: boolean) {
        this.apexService.showLoader(loader ? true : false);
        let paramString = Util.GetParamString(data ? data.data : {});
        url = this.host + "/report" + url + "/html" + paramString;
        console.log(url);
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        //xhr.responseType = "blob";
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onload = () => {
            if (xhr.status === 200) {
                this.apexService.showLoader(false);
                var blob = xhr.response;
                this.printPopup(blob);
            }
        };
        xhr.send();
    }

    private printPopup(data: any) {
        //    console.log(data);
        // if(typeof cordova === 'undefined') {
        var frame1 = document.createElement("iframe");
        frame1.name = "frame1";
        frame1.style.position = "absolute";
        frame1.style.top = "-1000000px";
        document.body.appendChild(frame1);
        var frameDoc = frame1.contentWindow ? frame1.contentWindow : frame1.contentDocument["document"] ? frame1.contentDocument["document"] : frame1.contentDocument;
        frameDoc.document.open();
        frameDoc.document.write(data);
        frameDoc.document.close();
        setTimeout(function() {
            window.frames["frame1"].focus();
            window.frames["frame1"].print();
            document.body.removeChild(frame1);
        }, 500);
        return false;
        // }else {
        //     cordova.plugins.printer.print(data, {duplex: 'long'}, function (res : any) {
        //         alert(res ? 'Done' : 'Canceled');
        //     });
        // }
    }
}
