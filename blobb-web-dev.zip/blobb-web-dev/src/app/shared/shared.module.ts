import { NgModule, ModuleWithProviders, ErrorHandler } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { HttpClientModule } from "@angular/common/http";
import { AppInterceptor } from "./service/app.interceptor";
import { CommonModule } from "@angular/common";
import { ConfirmDirective } from "./directives/confirm.directive";
import { ReportService } from "./service/report.service";
import { AppService } from "./service/app.service";
import { HttpService } from "./service/http.service";
import { LoadService } from "../constants/load.service";
import { NavService } from "../constants/nav.service";
import { MatSnackBarModule, MatProgressBarModule } from "@angular/material";
import { ScrollDispatchModule } from "@angular/cdk/scrolling";
import { MaterialModule } from "./material.module";
import { DffCardsModule } from "dff-cards";
import { FormMessagesComponent } from "./component/form.messages.component";
import { ImageCropperModule } from "ngx-image-cropper";
import { CropImgComponent } from "./component/cropimg.component";
import { ImgLoadComponent } from "./component/img-load.component";
import {
    FilterPipe,
    KeyValuesPipe,
    DecodeURIPipe,
    DatePipe,
    DateTimePipe,
    FlagPipe,
    CurrencyPipe,
    AgePipe,
    DecodePipe,
    DateTimeISOPipe,
    PercentagePipe,
    BreakOnWordPipe,
} from "./utils/pipes";
import { MatBadgeModule } from "@angular/material/badge";
import { ScrollDirective } from "./directives/scroll.directive";
import { DataScrollComponent } from "./component/data-scroll.component";
import { DataTableComponent } from "./component/data-table.component";

import { FlexLayoutModule } from "@angular/flex-layout";
import { ProgressBarComponent } from "./component/progress-bar.component";
import { ErrorsService } from "./service/errors.service";
import { AgmCoreModule } from "@agm/core";
import { MaterialTimePickerModule } from '@candidosales/material-time-picker';


import { NoRecordFoundComponent } from "./component/no-record-found.component";
import { ImgUploadComponent } from "./component/imgupload.component";
import { FileUploadComponent } from "./component/file-upload.component";
import { AgmMapsComponent } from "./component/agm-maps.component";

@NgModule({
    imports: [
        CommonModule,
        FlexLayoutModule,
        FormsModule,
        HttpClientModule,
        MaterialModule,
        DffCardsModule,
        MatSnackBarModule,
        MatProgressBarModule,
        ScrollDispatchModule,
        ImageCropperModule,
        MatBadgeModule,
        MaterialTimePickerModule,
        AgmCoreModule.forRoot({
            apiKey: "AIzaSyDJpndR1PgCcaqAdZEnX4wR-wDTXIEAgpU",
        }),
    ],
    declarations: [
        ConfirmDirective,
        FilterPipe,
        KeyValuesPipe,
        DecodeURIPipe,
        DecodePipe,
        DatePipe,
        DateTimePipe,
        FlagPipe,
        CurrencyPipe,
        PercentagePipe,
        AgePipe,
        DateTimeISOPipe,
        BreakOnWordPipe,
        FormMessagesComponent,
        ProgressBarComponent,
        CropImgComponent,
        ImgLoadComponent,
        ImgUploadComponent,
        ScrollDirective,
        DataScrollComponent,
        DataTableComponent,
        NoRecordFoundComponent,
        FileUploadComponent,
        AgmMapsComponent,
    ],
    exports: [
        CommonModule,
        FormsModule,
        FlexLayoutModule,
        MaterialModule,
        ConfirmDirective,
        FilterPipe,
        KeyValuesPipe,
        DecodeURIPipe,
        DecodePipe,
        DatePipe,
        DateTimePipe,
        FlagPipe,
        CurrencyPipe,
        PercentagePipe,
        AgePipe,
        DateTimeISOPipe,
        BreakOnWordPipe,
        FormMessagesComponent,
        ScrollDispatchModule,
        ProgressBarComponent,
        AgmCoreModule,
        DffCardsModule,
        CropImgComponent,
        ImgLoadComponent,
        ImgUploadComponent,
        ScrollDirective,
        DataScrollComponent,
        DataTableComponent,
        MatBadgeModule,
        NoRecordFoundComponent,
        FileUploadComponent,
        AgmMapsComponent,MaterialTimePickerModule
    ],
})
export class SharedModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                ReportService,
                AppService,
                LoadService,
                NavService,
                HttpService,
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: AppInterceptor,
                    multi: true,
                },
                {
                    provide: ErrorHandler,
                    useClass: ErrorsService,
                },
            ],
        };
    }
}
