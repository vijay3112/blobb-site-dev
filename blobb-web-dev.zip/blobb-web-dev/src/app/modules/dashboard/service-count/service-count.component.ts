import { Component, OnInit } from "@angular/core";

declare const require: any;

@Component({
    selector: "app-service-count",
    templateUrl: "./service-count.component.html",
    styleUrls: ["./service-count.component.scss"],
    preserveWhitespaces: true,
})
export class ServiceCountComponent implements OnInit {
    demo_hint = `
  interface initOpts {{'{'}}
  devicePixelRatio?: number,
  renderer?: string,
  width?: number|string,
  height? number|string,
}`;

    options = {
        title: {
            text: "User Report",
        },
        color: ["#3398DB"],
        tooltip: {
            trigger: "axis",
            axisPointer: {
                type: "shadow",
            },
        },
        grid: {
            left: "10%",
            right: "10%",
            bottom: "3%",
            containLabel: true,
        },
        xAxis: [
            {
                type: "category",
                data: ["Jan", "Feb", "Mar", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"],
                axisTick: {
                    alignWithLabel: true,
                },
            },
        ],
        yAxis: [
            {
                type: "value",
            },
        ],
        series: [
            {
                name: "Counters",
                type: "bar",
                barWidth: "60%",
                data: [10, 52, 200, 334, 390, 330, 220, 333, 222, 111, 333, 11],
            },
        ],
    };

    initOpts = {
        renderer: "svg",
        width: 510,
        height: 340,
    };
    constructor() {}

    ngOnInit() {}
}
