import { Component, OnInit, Input } from "@angular/core";
import { graphic } from "echarts";
declare const require: any;

@Component({
    selector: "app-monthly-report",
    templateUrl: "./monthly-report.component.html",
    styleUrls: ["./monthly-report.component.scss"],
})
export class MonthlyReportComponent implements OnInit {
    options: any;
    detectEventChanges = true;

    constructor() {}

    ngOnInit() {
        const dataAxis = ["Jubilee Hills", "Banjarahills", "Gachibowli"];
        const data = [220, 182, 191];
        const yMax = 500;
        const dataShadow = [];

        for (let i = 0; i < data.length; i++) {
            dataShadow.push(yMax);
        }

        this.options = {
            title: {
                text: "Location profits",
            },
            xAxis: {
                data: dataAxis,
                axisLabel: {
                    inside: true,
                    textStyle: {
                        color: "#fff",
                    },
                },
                axisTick: {
                    show: false,
                },
                axisLine: {
                    show: false,
                },
                z: 10,
            },
            yAxis: {
                axisLine: {
                    show: false,
                },
                axisTick: {
                    show: false,
                },
                axisLabel: {
                    textStyle: {
                        color: "#999",
                    },
                },
            },
            dataZoom: [
                {
                    type: "inside",
                },
            ],
            series: [
                {
                    // For shadow
                    type: "bar",
                    itemStyle: {
                        normal: { color: "rgba(0,0,0,0.05)" },
                    },
                    barGap: "-100%",
                    barCategoryGap: "40%",
                    data: dataShadow,
                    animation: false,
                },
                {
                    type: "bar",
                    itemStyle: {
                        normal: {
                            color: new graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: "#83bff6" }, { offset: 0.5, color: "#188df0" }, { offset: 1, color: "#188df0" }]),
                        },
                        emphasis: {
                            color: new graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: "#2378f7" }, { offset: 0.7, color: "#2378f7" }, { offset: 1, color: "#83bff6" }]),
                        },
                    },
                    data: data,
                },
            ],
        };
    }

    onChartEvent(event: any, type: string) {
        console.log("chart event:", type, event);
    }
}
