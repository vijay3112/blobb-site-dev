import { NgModule } from "@angular/core";

import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { Routes, RouterModule } from "@angular/router";
import { ComponentsModule } from "../../components/components.module";

import { DashboardService } from "./dashboard.service";
import { HomePageComponent } from "./home-page/home-page.component";
import { DashboardPageComponent } from "./dashboard-page/dashboard-page.component";
import { NgxEchartsModule } from "ngx-echarts";

import { MonthlyReportComponent } from "../dashboard/monthly-report/monthly-report.component";
import { ServiceCountComponent } from "./service-count/service-count.component";
import { UserCountComponent } from "./user-count/user-count.component";

const routes: Routes = [{ path: "dashboard", component: DashboardPageComponent }, { path: "home", component: HomePageComponent }];

@NgModule({
    imports: [CommonModule, SharedModule, ComponentsModule, NgxEchartsModule, RouterModule.forChild(routes)],
    declarations: [HomePageComponent, DashboardPageComponent, MonthlyReportComponent, ServiceCountComponent, UserCountComponent],
    providers: [DashboardService],
})
export class DashboardModule {}
