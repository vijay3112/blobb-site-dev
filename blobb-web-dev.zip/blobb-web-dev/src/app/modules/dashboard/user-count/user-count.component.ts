import { Component, OnInit } from "@angular/core";

declare const require: any;

@Component({
    selector: "app-user-count",
    templateUrl: "./user-count.component.html",
    styleUrls: ["./user-count.component.scss"],
})
export class UserCountComponent implements OnInit {
    echartsInstance: any;
    options = {
        // backgroundColor: "#2c343c",

        title: {
            text: "Locations",
        // },
            // left: 0,
            // top: 20,
            textStyle: {
                color: "#000",
            },
        },

        tooltip: {
            trigger: "item",
            formatter: "{a} <br/>{b} : {c} ({d}%)",
        },

        visualMap: {
            show: false,
            min: 80,
            max: 600,
            inRange: {
                colorLightness: [0, 1],
            },
        },
        series: [
            {
                name: "Counters",
                type: "pie",
                radius: "55%",
                center: ["50%", "50%"],
                data: [{ value: 335, name: "Jubilee Hills" }, { value: 310, name: "Banjara Hills" }, { value: 274, name: "Gachibowli" }].sort(function(a, b) {
                    return a.value - b.value;
                }),
                roseType: "radius",
                label: {
                    normal: {
                        textStyle: {
                            color: "#000",
                        },
                    },
                },
                labelLine: {
                    normal: {
                        lineStyle: {
                            color: "#000",
                        },
                        smooth: 0.2,
                        length: 10,
                        length2: 20,
                    },
                },
                itemStyle: {
                    normal: {
                        color: "#d81b60",
                        // shadowBlur: 200,
                        shadowColor: "#d81b60",
                    },
                },

                animationType: "scale",
                animationEasing: "elasticOut",
                animationDelay: function(idx) {
                    return Math.random() * 200;
                },
            },
        ],
    };
    constructor() {}

    ngOnInit() {}
}
