import { Component, OnInit } from "@angular/core";
import { Props } from "../../../constants/props";
import { WelcomeService } from "../welcome.service";

@Component({
  selector: "app-welcome-page",
  templateUrl: "./welcome-page.component.html",
  styleUrls: ["./welcome-page.component.scss"]
})
export class WelcomePageComponent implements OnInit {
  Props: Props = Props;
  constructor(private service: WelcomeService) {
    this.service.getApp().sessionClear();
  }

  ngOnInit() {}

  login() {
    this.service.getNav().signin(null);
  }
}
