import { Injectable } from "@angular/core";
import { AppService } from "../../shared/service/app.service";
import { HttpService } from "../../shared/service/http.service";
import { NavService } from "../../constants/nav.service";

@Injectable()
export class WelcomeService {
  constructor(
    private http: HttpService,
    private appService: AppService,
    private navService: NavService
  ) {}

  getNav(): NavService {
    return this.navService;
  }

  getApp(): AppService {
    return this.appService;
  }

  showMessage(message: string) {
    this.appService.showMessage(message);
  }

  getParam(key: string): String {
    return this.navService.param(key);
  }
}
