import { NgModule } from "@angular/core";
import { WelcomePageComponent } from "./welcome-page/welcome-page.component";

import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { Routes, RouterModule } from "@angular/router";

import { WelcomeService } from "./welcome.service";
import { ComponentsModule } from "../../components/components.module";
const routes: Routes = [{ path: "", component: WelcomePageComponent }];

@NgModule({
    imports: [CommonModule, SharedModule, ComponentsModule, RouterModule.forChild(routes)],
    declarations: [WelcomePageComponent],
    providers: [WelcomeService],
})
export class WelcomeModule {}
