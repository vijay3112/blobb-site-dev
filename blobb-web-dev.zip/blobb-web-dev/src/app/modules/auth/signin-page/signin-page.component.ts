import { Component, OnInit, ViewChild } from "@angular/core";
import { Auth } from "../../../entities/Auth";
import { AuthService } from "../auth.service";
import { NgForm } from "@angular/forms";

@Component({
    selector: "app-signin-page",
    templateUrl: "./signin-page.component.html",
    styleUrls: ["./signin-page.component.scss"],
})
export class SigninPageComponent implements OnInit {
    auth: Auth;
    @ViewChild(NgForm) myForm: NgForm;

    constructor(private service: AuthService) {
        this.service.getApp().sessionClear();
        this.auth = new Auth();
    }

    ngOnInit() {}

    formReset() {
        this.auth = new Auth();
        this.myForm.form.reset();
    }

    onLogin() {
        this.service.login(this.auth).subscribe((result: any) => {
            if (result) {
                this.service.storageSave(result);
                setTimeout(() => {
                    if (this.service.getApp().getSessionUser().role == "USER") {
                        this.service.getNav().home(null);
                    } else {
                        this.service.getNav().dashBoard(null);
                    }
                    this.formReset();
                }, 100);
            }
        });
    }

    keyDownFunction(myForm) {
        if (myForm && myForm.valid) {
            this.onLogin();
        }
    }

    onForgotPassword() {
        this.formReset();
        this.service.getNav().forgotPassword(null);
    }

    onSingup() {
        this.formReset();
        this.service.getNav().signup(null);
    }
}
