import { Component, OnInit, ViewChild } from "@angular/core";
import { Props } from "../../../constants/props";
import { Auth } from "../../../entities/Auth";
import { AuthService } from "../auth.service";
import { NgForm } from "@angular/forms";

@Component({
    selector: "app-signup-page",
    templateUrl: "./signup-page.component.html",
    styleUrls: ["./signup-page.component.scss"],
})
export class SignupPageComponent implements OnInit {
    auth: Auth;
    @ViewChild(NgForm) myForm: NgForm;
    constructor(private service: AuthService) {
        this.service.getApp().sessionClear();
        this.auth = new Auth();
    }

    ngOnInit() {}

    formReset() {
        this.auth = new Auth();
        this.myForm.form.reset();
    }

    onSignup() {
        this.service.signup(this.auth).subscribe((result: any) => {
            if (result) {
                setTimeout(() => {
                    this.service.getApp().showMessage(result.message + Props.PLEASE_LOGIN);
                    this.onSingin();
                    this.formReset();
                }, 100);
            }
        });
    }

    keyDownFunction(myForm) {
        if (myForm && myForm.valid) {
            this.onSignup();
        }
    }

    onForgotPassword() {
        this.formReset();
        this.service.getNav().forgotPassword(null);
    }
    onSingin() {
        this.formReset();
        this.service.getNav().signin(null);
    }
}
