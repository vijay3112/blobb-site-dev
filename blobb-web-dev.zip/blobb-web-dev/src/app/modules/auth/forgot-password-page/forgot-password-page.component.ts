import { Component, OnInit, ViewChild } from "@angular/core";
import { Props } from "../../../constants/props";
import { Auth } from "../../../entities/Auth";
import { AuthService } from "../auth.service";
import { NgForm } from "@angular/forms";

@Component({
    selector: "app-forgot-password-page",
    templateUrl: "./forgot-password-page.component.html",
    styleUrls: ["./forgot-password-page.component.scss"],
})
export class ForgotPasswordPageComponent implements OnInit {
    auth: Auth;
    @ViewChild(NgForm) myForm: NgForm;
    constructor(private service: AuthService) {
        this.service.getApp().sessionClear();
        this.auth = new Auth();
    }

    ngOnInit() {}

    formReset() {
        this.auth = new Auth();
        this.myForm.form.reset();
    }

    onSubmit() {
        this.service.forgotPassword(this.auth.userid).subscribe((result: any) => {
            if (result) {
                this.service.getApp().showMessage(result.message);
                this.resetPassword();
            }
        });
    }

    keyDownFunction(myForm) {
        if (myForm && myForm.valid) {
            this.onSubmit();
        }
    }

    resetPassword() {
        let userId: string = this.auth.userid;
        console.log(userId);
        this.formReset();
        this.service.getNav().resetPassword([{ userid: userId }]);
    }

    onSingin() {
        this.formReset();
        this.service.getNav().signin(null);
    }
}
