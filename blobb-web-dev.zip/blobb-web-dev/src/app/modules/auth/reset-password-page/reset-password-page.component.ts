import { Component, OnInit, ViewChild } from "@angular/core";
import { Props } from "../../../constants/props";
import { Auth } from "../../../entities/Auth";
import { AuthService } from "../auth.service";
import { NgForm } from "@angular/forms";

@Component({
    selector: "app-reset-password-page",
    templateUrl: "./reset-password-page.component.html",
    styleUrls: ["./reset-password-page.component.scss"],
})
export class ResetPasswordPageComponent implements OnInit {
    auth: Auth;
    @ViewChild(NgForm) myForm: NgForm;
    constructor(private service: AuthService) {
        this.service.getApp().sessionClear();
        this.auth = new Auth();
    }

    ngOnInit() {}

    formReset() {
        this.auth = new Auth();
        this.myForm.form.reset();
    }

    onSubmit() {
        this.auth.userid = this.service.getParam("userid");
        this.service.resetPassword(this.auth).subscribe((result: any) => {
            if (result) {
                this.service.getApp().showMessage(result.message);
                this.onSingin();
            }
        });
    }

    keyDownFunction(myForm) {
        if (myForm && myForm.valid) {
            this.onSubmit();
        }
    }

    onSingin() {
        this.formReset();
        this.service.getNav().signin(null);
    }
}
