import { Component, OnInit, Output, EventEmitter, SimpleChange, SimpleChanges, Input } from "@angular/core";
import { PropertyService } from "./../property.service";
import { Props } from "../../../constants/props";

import { Flat } from "../../../entities/Flat";
import { Property } from "../../../entities/Property";

@Component({
    selector: "app-flat-search-page",
    templateUrl: "./flat-search-page.component.html",
    styleUrls: ["./flat-search-page.component.scss"],
})
export class FlatSearchPageComponent implements OnInit {
    showFlatEdit: boolean = false;
    @Input()
    propertyId: String;
    flatList: Flat[] = null;
    selectedFlatObj: Flat = new Flat();
    newFlatObj: Flat = new Flat();
    activeFlat: any;
    constructor(private propertyService: PropertyService) {
        this.activeFlat = this.activeFlat ? this.activeFlat : 0;
    }

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    @Output()
    selectedFlatEvent: EventEmitter<any> = new EventEmitter<any>();

    ngOnInit() {
        //this.getFlatDetails(this.propertyId);
    }

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["propertyId"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            this.propertyId = changeValue.currentValue;
            if (!!this.propertyId) {
                this.getFlatDetails(this.propertyId);
            }
        }
    }
    toggleEdit(val: any) {
        if (val === null) {
            this.newFlatObj = new Flat();
            this.outputEvent.emit(this.newFlatObj);
        } else {
            this.outputEvent.emit(val);
        }
    }
    getFlatDetails(propertyId: any) {
        this.flatList = null;
        let searchObj: any = {
            propertyId: propertyId,
        };
        this.propertyService.searchFlat(searchObj).subscribe((result: any) => {
            this.flatList = result;
            this.selectedFlat(this.flatList[0]);
        });
    }
    selectedFlat(item: any) {
        if (!!item) {
            this.activeFlat = item.id;
            this.selectedFlatObj = item;
            this.selectedFlatEvent.emit(this.selectedFlatObj);
        }
    }
}
