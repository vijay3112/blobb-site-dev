import { Component, OnInit, Input, SimpleChanges, SimpleChange } from "@angular/core";
import { PropertyService } from "../property.service";
import { MatBottomSheet, MatBottomSheetRef } from "@angular/material";
import { Orders } from "../../../entities/Orders";
@Component({
    selector: "app-property-order-page",
    templateUrl: "./property-order-page.component.html",
    styleUrls: ["./property-order-page.component.scss"],
})
export class PropertyOrderPageComponent implements OnInit {
    ordersList: any[];
    bottomSheetRef: MatBottomSheetRef<any>;
    orders: any;
    @Input()
    propertyId: string;

    constructor(private propertyService: PropertyService, private bottomSheet: MatBottomSheet) {
        this.orders = new Orders();
        this.orders.property.id = this.propertyId;
    }

    ngOnInit() {}

    ordersDataList() {
        let data: any = { propertyId: this.propertyId };
        this.propertyService.getOrders(data).subscribe((results: any[]) => {
            this.ordersList = results;
        });
    }
    save($event) {
        this.propertyService.saveOrders($event).subscribe((data: any) => {
            this.propertyService.showMessage(data.message);
            this.ordersDataList();
            this.bottomSheet.dismiss();
        });
    }

    openBottomSheet($tag, orders: any): void {
        if (!orders) {
            this.orders = new Orders();
            this.orders.property.id = this.propertyId;
        } else {
            this.orders = orders;
        }
        this.bottomSheet.open($tag);
    }
    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["propertyId"];
        if (!!changeValue && changeValue.previousValue != changeValue.currentValue) {
            this.orders.property.id = this.propertyId;
            this.ordersDataList();
        }
    }
}
