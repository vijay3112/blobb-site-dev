import { NgModule } from "@angular/core";

import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { Routes, RouterModule } from "@angular/router";
import { ComponentsModule } from "../../components/components.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { PropertyService } from "./property.service";
import { PropertyEditPageComponent } from "./property-edit-page/property-edit-page.component";
import { RoomSearchPageComponent } from "./room-search-page/room-search-page.component";
import { RoomEditPageComponent } from "./room-edit-page/room-edit-page.component";
import { FlatEditPageComponent } from "./flat-edit-page/flat-edit-page.component";
import { FlatSearchPageComponent } from "./flat-search-page/flat-search-page.component";
import { PropertySearchPageComponent } from "./property-search-page/property-search-page.component";
import { PropertyOrderPageComponent } from "./property-order-page/property-order-page.component";
import { PropertyFilePageComponent } from './property-file-page/property-file-page.component';

const routes: Routes = [{ path: "search", component: PropertySearchPageComponent }, { path: "edit", component: PropertyEditPageComponent }];

@NgModule({
  imports: [CommonModule, SharedModule, ComponentsModule, RouterModule.forChild(routes), ReactiveFormsModule, FormsModule],
  declarations: [
    PropertyEditPageComponent,
    PropertySearchPageComponent,
    RoomSearchPageComponent,
    RoomEditPageComponent,
    FlatEditPageComponent,
    FlatSearchPageComponent,
    PropertyOrderPageComponent,
    PropertyFilePageComponent,
  ],
  providers: [PropertyService],
})
export class PropertyModule {}

// ,{ path: "property",  loadChildren: "./modules/property/property.module#PropertyModule", canActivate: [AuthService] }
