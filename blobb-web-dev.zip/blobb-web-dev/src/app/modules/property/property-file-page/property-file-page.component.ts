import { Component, OnInit, Input, SimpleChange, SimpleChanges } from "@angular/core";
import { FileData } from "../../../entities/FileData";
import { Util } from "../../../shared/utils/util";
import { PropertyService } from "../property.service";

@Component({
    selector: "app-property-file-page",
    templateUrl: "./property-file-page.component.html",
    styleUrls: ["./property-file-page.component.scss"],
})
export class PropertyFilePageComponent implements OnInit {
    @Input()
    propertyId: string;
    fileData: FileData;
    imagesList: any[];
    constructor(private service: PropertyService) {}

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["propertyId"];
        if (!!changeValue && changeValue.previousValue != changeValue.currentValue) {
            this.newFileData();
            this.searchFileData();
        }
    }

    newFileData() {
        this.fileData = new FileData();
        this.fileData.id = this.propertyId + "_" + Util.UID();
        this.fileData.ref = this.propertyId;
        this.fileData.refType = "property";
    }

    searchFileData() {
        let data = { ref: [this.propertyId, this.propertyId] };
        this.service.searchFileData(data).subscribe((result: any[]) => {
            if (result) {
                let list = [];
                result.forEach((element) => {
                    list.push(element.id);
                });
                this.imagesList = Util.MultiList(list, 3);
                console.log(this.imagesList);
            } else {
                this.imagesList = [];
            }
        });
    }
    fileDataEmit($event) {
        this.searchFileData();
        this.fileData.id = this.propertyId + "_" + Util.UID();
    }
}
