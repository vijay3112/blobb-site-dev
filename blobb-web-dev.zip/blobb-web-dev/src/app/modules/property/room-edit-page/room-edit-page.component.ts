import { Component, OnInit, Output, EventEmitter, SimpleChange, SimpleChanges, Input, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Room } from "../../../entities/Room";
import { PropertyService } from "./../property.service";
@Component({
    selector: "app-room-edit-page",
    templateUrl: "./room-edit-page.component.html",
    styleUrls: ["./room-edit-page.component.scss"],
})
export class RoomEditPageComponent implements OnInit {
    @ViewChild(NgForm) myForm: NgForm;

    @Input()
    room: Room;

    @Output()
    cancelRoomEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private propertyService: PropertyService) {}

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["room"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            //toDo
        }
    }
    save() {
        this.propertyService.saveRoomData(this.room).subscribe((data: any) => {
            if (!!data) {
                this.propertyService.showMessage(data.message);
                this.cancel();
            }
        });
    }
    cancel() {
        this.cancelRoomEvent.emit(false);
    }
}
