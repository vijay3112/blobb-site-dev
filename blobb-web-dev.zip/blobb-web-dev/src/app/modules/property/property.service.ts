import { Injectable } from "@angular/core";
import { AppService } from "../../shared/service/app.service";
import { HttpService } from "../../shared/service/http.service";
import { NavService } from "../../constants/nav.service";
import { ReportService } from "../../shared/service/report.service";
import { Props } from "../../constants/props";

@Injectable({
    providedIn: "root",
})
export class PropertyService {
    props: Props = Props;

    private service_url = "/property";
    private flat_url = "/flat";
    private amenities_url = "/amenities";
    private propertyAmenities_url = "/propertyAmenities";
    private room_url = "/room";
    private orders_url = "/orders";
    private file_data_url = "/filedata";

    constructor(private http: HttpService, private appService: AppService, private navService: NavService, private reportService: ReportService) {
        console.log("Property server up");
    }

    getNav(): NavService {
        return this.navService;
    }

    getApp(): AppService {
        return this.appService;
    }

    showMessage(message: string) {
        this.appService.showMessage(message);
    }

    getParam(key: string): String {
        return this.navService.param(key);
    }

    search(filter: any) {
        return this.http.get(this.service_url, { data: filter });
    }

    propertyEntity(id: any) {
        return this.http.get(this.service_url + "/" + id, {});
    }

    searchFlat(filter: any) {
        return this.http.get(this.flat_url, { data: filter });
    }

    saveFlatData(data: any) {
        this.appService.showLoader(true);
        return this.http.put(this.flat_url, { data: data }, true);
    }

    saveProperty(data: any) {
        return this.http.put(this.service_url, { data: data }, true);
    }

    searchRoom(filter: any) {
        return this.http.get(this.room_url, { data: filter });
    }
    saveRoomData(data: any) {
        return this.http.put(this.room_url, { data: data }, true);
    }

    propertyAmenities(filter: any) {
        return this.http.get(this.propertyAmenities_url, { data: filter });
    }

    savePropertyAmenity(data: any) {
        console.log(data);
        return this.http.put(this.propertyAmenities_url, { data: data }, true);
    }

    getOrders(data: any) {
        return this.http.get(this.orders_url, { data: data });
    }
    saveOrders(data: any) {
        return this.http.put(this.orders_url, { data: data }, true);
    }
    searchFileData(data: any) {
        return this.http.get(this.file_data_url, { data: data });
    }
}
