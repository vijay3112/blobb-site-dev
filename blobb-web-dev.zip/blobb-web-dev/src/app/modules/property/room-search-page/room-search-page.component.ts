import { Component, OnInit, Output, EventEmitter, SimpleChange, SimpleChanges, Input } from "@angular/core";
import { Room } from "../../../entities/Room";
import { PropertyService } from "../property.service";

@Component({
    selector: "app-room-search-page",
    templateUrl: "./room-search-page.component.html",
    styleUrls: ["./room-search-page.component.scss"],
})
export class RoomSearchPageComponent implements OnInit {
    @Input()
    flatId: string;

    roomList: Room[] = null;

    @Output()
    addRoomEvent: EventEmitter<any> = new EventEmitter<any>();

    @Output()
    editRoomEvent: EventEmitter<any> = new EventEmitter<any>();
    constructor(private propertyService: PropertyService) {}

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["flatId"];
        console.log(changeValue.currentValue);
        this.roomList = null;
        if (changeValue && changeValue.currentValue && changeValue.previousValue != changeValue.currentValue) {
            this.getRooms();
        }
        if (!changeValue.currentValue) {
            this.roomList = [];
        }
    }
    addRoom() {
        this.addRoomEvent.emit(true);
    }
    editRoom(item: Room) {
        this.editRoomEvent.emit(item);
    }

    search() {}
    getRooms() {
        this.roomList = null;
        let searchObj: any = {
            flatId: this.flatId,
        };
        this.propertyService.searchRoom(searchObj).subscribe((result: any) => {
            this.roomList = result;
        });
    }
}
