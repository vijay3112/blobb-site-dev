import { Component, OnInit, Input, ChangeDetectorRef } from "@angular/core";

import { PropertyService } from "./../property.service";
import { Property } from "../../../entities/Property";
import { Flat } from "../../../entities/Flat";
import { Room } from "../../../entities/Room";
import { Props } from "../../../constants/props";
import { LoadService } from "../../../constants/load.service";

@Component({
    selector: "app-property-search-page",
    templateUrl: "./property-search-page.component.html",
    styleUrls: ["./property-search-page.component.scss"],
})
export class PropertySearchPageComponent implements OnInit {
    propertyList: any;
    dataList: any[];
    flatList: Flat[] = null;
    property: Property = null;
    selectedProperty: string = null;
    flat: Flat = null;
    room: Room = null;
    activeProperty: any;
    constructor(private propertyService: PropertyService, private loadService: LoadService, private changeDetectorRef: ChangeDetectorRef) {
        this.property = new Property();
        this.flat = new Flat();
        this.room = new Room();
        this.getProperties();
    }
    showFlatEdit: boolean = false;
    isCreateRoom: Boolean = false;
    ngOnInit() {
        this.changeDetectorRef.detectChanges();
    }

    getProperties() {
        this.loadService.propertyAll().subscribe((data: any) => {
            console.log(data[0].val);
            if (!!data && data.length) {
                this.propertyList = data;
                this.selectedProperty = data[0].val;
                this.propertyEntity(this.selectedProperty);
            } else {
                this.selectedProperty = "";
                this.propertyList = [];
                this.edit(null);
            }
        });
    }
    propertyEntity(value: any) {
        if (value) {
            this.property = null;
            this.flat = new Flat();
            this.activeProperty = value;
            this.propertyService.propertyEntity(this.activeProperty).subscribe((result: any) => {
                if (!!result) {
                    this.property = result;
                }
            });
        }
        //this.activeProperty = id;
    }

    edit(id: any) {
        console.log(this.activeProperty);
        if (id === null) {
            this.propertyService.getNav().propertyEdit({ id: null });
        } else {
            this.propertyService.getNav().propertyEdit({ id: this.activeProperty });
        }
    }
    editFlat = new Flat();
    toggleEdit(event) {
        console.log(event);
        this.showFlatEdit = true;
        this.editFlat = Object.assign({}, event);
        this.editFlat.property = this.property;
    }
    getSelectedFlat(event) {
        this.flat = event;
        this.flat.property = this.property;
        this.room.flat = this.flat;
        this.room.property = this.property;
        this.toggleRoomPage(false);
    }
    close1(backdrop) {
        this.showFlatEdit = false;
        let tempPropertyValue = this.activeProperty;
        this.activeProperty = null;
        setTimeout(() => {
            this.activeProperty = tempPropertyValue;
        }, 10);

        // this.getFlatDetails(this.activeProperty);
    }

    //add room functionality //
    editRoom = new Room();
    toggleRoomPage(event: any) {
        if (typeof event === "boolean") {
            this.editRoom = Object.assign({}, new Room());
            this.isCreateRoom = event;
        } else {
            this.editRoom = Object.assign({}, event);
            this.isCreateRoom = true;
        }
        this.editRoom.flat = this.flat;
        this.editRoom.property = this.property;
    }
}
