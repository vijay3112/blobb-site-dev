import { Component, OnInit, ViewChild, EventEmitter, Output, Input, SimpleChanges, SimpleChange } from "@angular/core";
import { NgForm } from "@angular/forms";
import { PropertyService } from "../property.service";
import { Flat } from "../../../entities/Flat";

@Component({
  selector: "app-flat-edit-page",
  templateUrl: "./flat-edit-page.component.html",
  styleUrls: ["./flat-edit-page.component.scss"],
})
export class FlatEditPageComponent implements OnInit {
  @ViewChild(NgForm) myForm: NgForm;
  showFlatEdit: boolean = false;
  @Input()
  flat: Flat;
  @Output()
  outputEvent: EventEmitter<any> = new EventEmitter<any>();
  constructor(private service: PropertyService) {
    //this.flat = new Flat();
  }
  ngOnInit() { }
  onClose() {
    this.showFlatEdit = false;
    this.myForm.form.reset();
    this.outputEvent.emit();
  }
  save() {
    console.log(this.flat)
    this.service.saveFlatData(this.flat).subscribe((data: any) => {
      if (data) {
        this.service.showMessage(data.message);
        this.onClose();
      }
    });
  }
}
