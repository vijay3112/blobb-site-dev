import { Component, OnInit, ViewChild, Output, EventEmitter, Sanitizer } from "@angular/core";
import { PropertyService } from "./../property.service";
import { Property } from "../../../entities/Property";
import { PropertyAmenities } from "../../../entities/PropertyAmenities";
import { Props } from "../../../constants/props";
import { NgForm } from "@angular/forms";
import { DomSanitizer } from "@angular/platform-browser";

@Component({
    selector: "app-property-edit-page",
    templateUrl: "./property-edit-page.component.html",
    styleUrls: ["./property-edit-page.component.scss"],
})
export class PropertyEditPageComponent implements OnInit {
    property: Property = new Property();
    @ViewChild(NgForm) myForm: NgForm;
    propertyAmenity: PropertyAmenities = new PropertyAmenities();
    tabs = [
        {
            val: "Property Details",
            active: true,
        },
        // {
        //     val: "Amenities",
        //     active: true,
        // },
        {
            val: "Orders",
            active: true,
        },
        // {
        //     val: "Upload Image",
        //     active: true,
        // },
    ];
    currentTab: String = "Property Details";
    propertyAmenitiesList: PropertyAmenities[] = null;
    selectedIndex: number = 0;
    amenities: any;
    id: any;
    ordersList: any[];
    showEdit: boolean = false;
    mapUrl: string = null;
    isReadOnly: boolean = false;

    constructor(private propertyService: PropertyService, public sanitizer: Sanitizer) {
        this.property = new Property();
        this.propertyAmenity = new PropertyAmenities();
        this.id = this.propertyService.getParam("id");
    }

    ngOnInit() {
        this.selectedIndex = 0;
        this.getPropertyAminities();
        this.propertyEntity(this.id);
        if (!this.id) {
            this.tabs.map((ele: any) => {
                if (ele.val !== "Property Details") {
                    ele.active = false;
                }
            });
        }
        console.log(this.tabs);
    }

    tabChange(event: any) {
        this.currentTab = event.tab.textLabel;
    }
    save() {
        this.propertyService.saveProperty(this.property).subscribe((data: any) => {
            if (!!data) {
                this.propertyService.showMessage(data.message);
                this.selectedIndex = 0;
                this.onClose();
                this.propertyService.getNav().propertySearch(data);
            }
        });
    }
    onClose() {
        this.showEdit = false;
        this.myForm.form.reset();
    }
    propertyEntity(id: any) {
        if (!!id) {
            this.propertyService.propertyEntity(id).subscribe((result: any) => {
                if (result) {
                    setTimeout(() => {
                        this.property = result;
                        this.isReadOnly = true;
                        this.mapUrl = this.property.mapLocation;
                    }, Props.TIME_OUT);
                }
            });
        }
    }

    getPropertyAminities() {
        let searchObj: any = {
            propertyId: this.id,
        };
        this.propertyService.propertyAmenities(searchObj).subscribe((data: any) => {
            if (!!data) {
                this.propertyAmenitiesList = data;
                console.log(this.propertyAmenitiesList);
            }
        });
    }

    savePropertyAmenity(event) {
        this.propertyAmenity = event;
        this.propertyAmenity.active = !event.active;
        this.propertyAmenity.property = this.property;
        console.log(this.propertyAmenity);
        this.propertyService.savePropertyAmenity(this.propertyAmenity).subscribe((data: any) => {
            if (!!data) {
                this.propertyService.showMessage(data.message);
            }
        });
    }

    ordersDataList() {
        let data: any = {};
        this.propertyService.getOrders(data).subscribe((results: any[]) => {
            this.ordersList = results;
        });
    }
}
