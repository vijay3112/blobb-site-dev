import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter, ViewChild, ElementRef } from "@angular/core";
import { BookingsService } from "../bookings.service";
import { RoomOrders } from "../../../entities/RoomOrders";
import { NgForm } from "@angular/forms";
import { Payment } from "../../../entities/Payment";
import { PaymentTax } from "../../../entities/PaymentTax";
import { Props } from "src/app/constants/props";

@Component({
    selector: "app-room-orders-page",
    templateUrl: "./room-orders-page.component.html",
    styleUrls: ["./room-orders-page.component.scss"],
})
export class RoomOrdersPageComponent implements OnInit {
    Props = Props;
    @Input()
    status: string;

    @Input()
    roomBookId: string;
    roomOrders: RoomOrders;
    id: any;

    roomOrdersData: RoomOrders[];
    showEdit: boolean = false;
    @ViewChild(NgForm) myForm: NgForm;

    selectedOrders: any = [];
    ordersData: any = [];

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();
    @Output()
    outputServiceWoGst: EventEmitter<any> = new EventEmitter<any>();

    serviceAmount: number = 0;
    serviceAmountWoGST: number = 0;
    constructor(private service: BookingsService) { }

    ngOnInit() { }
    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["roomBookId"];
        if (changes["roomBookId"] && changes["roomBookId"].currentValue) {
            this.roomOrders = new RoomOrders();
            this.roomOrders.roomBook.id = this.roomBookId;
            this.getRoomOrders();
            this.getOrders();
        }
    }
    getRoomOrders() {
        let obj = {
            roomBookId: this.roomBookId,
        };
        this.service.getRoomOrders(obj).subscribe((data: any) => {
            this.serviceAmount = 0;
            this.serviceAmountWoGST = 0;
            this.roomOrdersData = data;
            this.roomOrdersData.map((element) => {
                this.serviceAmount = this.serviceAmount + Number(element.payment.amount);
                this.serviceAmountWoGST = this.serviceAmountWoGST + Number(element.payment.price);
            });
            this.outputEvent.emit(this.serviceAmount);
            this.outputServiceWoGst.emit(this.serviceAmountWoGST);
        });
    }
    getOrders() {
        let obj = {
            propertId: this.roomBookId,
        };
        this.service.getOrders(obj).subscribe((data: any) => {
            console.log(data);
            this.ordersData = data;
        });
    }

    mainSave() {
        this.close1(true);
        let roomOrderItem: RoomOrders;
        setTimeout(() => {
            this.ordersData.forEach((element) => {
                if (element.status) {
                    roomOrderItem = new RoomOrders();
                    roomOrderItem.payment.setData(element.paymentTax);
                    roomOrderItem.orders = element;
                    this.selectedOrders.push(roomOrderItem);
                }
            });
        }, 100);
        console.log(this.selectedOrders);
    }
    add() {
        this.showEdit = true;
        this.roomOrders = new RoomOrders();
        this.roomOrders.roomBook.id = this.roomBookId;
    }
    save(item) {
        this.roomOrders = item;
        this.roomOrders.roomBook.id = this.roomBookId;
        this.service.saveRoomOrders(item).subscribe((data: any) => {
            this.deleteSelectedOrders(item);
            this.getRoomOrders();
        });
    }
    close1(backdrop) {
        this.showEdit = false;
        if (this.roomOrders.roomBook.id && !this.roomOrders.orders.name) {
            this.service.deleteRoomPerson(this.roomOrders.roomBook.id).subscribe((data: any) => {
                this.myForm.form.reset();
            });
        } else {
            this.myForm.form.reset();
        }
    }
    delete(item) {
        if (item.id) {
            this.service.deleteRoomOrders(item.id).subscribe((data: any) => {
                this.deleteSelectedOrders(item);
                this.service.showMessage(data.message);
                this.getRoomOrders();
            });
        } else {
            this.deleteSelectedOrders(item);
        }
    }

    deleteSelectedOrders(item) {
        var index = this.selectedOrders.indexOf(item);
        if (index !== -1) this.selectedOrders.splice(index, 1);
    }
}
