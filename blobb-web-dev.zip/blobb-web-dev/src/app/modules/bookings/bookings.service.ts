import { Injectable } from "@angular/core";
import { HttpService } from "../../shared/service/http.service";
import { AppService } from "../../shared/service/app.service";
import { NavService } from "../../constants/nav.service";
import { MENU } from "../../constants/menu";
import { Props } from "../../constants/props";

@Injectable({
    providedIn: "root",
})
export class BookingsService {
    private profile_url = "/profile";
    private room_book_url = "/roombook";
    private available_rooms_url = "/roombook/avaliblerooms";
    private room_persons_url = "/roompersons";
    private room_orders_url = "/roomorders";
    private orders_url = "/orders";
    private room_book_track_url = "/roombooktrack";
    private payment_addon_url = "/paymentaddon";

    constructor(private http: HttpService, private navService: NavService, private appService: AppService) {}

    getNav(): NavService {
        return this.navService;
    }
    getApp(): AppService {
        return this.appService;
    }
    getParam(key: string): String {
        return this.navService.param(key);
    }

    searchProfile(filter: any) {
        return this.http.get(this.profile_url, { data: filter });
    }
    saveProfileData(data: any) {
        return this.http.put(this.profile_url, { data: data });
    }
    saveBookRoom(data: any) {
        return this.http.put(this.room_book_url, { data: data }, true);
    }
    saveBookRooms(data: any) {
        return this.http.put(this.room_book_url + "/bookrooms", { data: data }, true);
    }
    bookingEdit(params: any) {
        this.appService.navigate(MENU.BOOKING_EDIT.link, params);
    }
    getRoomBookList(filter: any) {
        return this.http.get(this.room_book_url, { data: filter });
    }
    getAvailableRoomsList(filter: any) {
        return this.http.get(this.available_rooms_url, { data: filter });
    }
    roomBookEntityData(id: any) {
        return this.http.get(this.room_book_url + "/" + id, {});
    }
    showMessage(message: string) {
        this.appService.showMessage(message);
    }
    getRoomPersons(data) {
        return this.http.get(this.room_persons_url, { data: data });
    }
    roomPersonsEntityData(id: any) {
        return this.http.get(this.room_persons_url + "/" + id, {});
    }
    saveRoomPerson(data) {
        return this.http.put(this.room_persons_url, { data: data }, true);
    }
    deleteRoomPerson(id) {
        return this.http.delete(this.room_persons_url + "/" + id, {});
    }
    getRoomOrders(data) {
        return this.http.get(this.room_orders_url, { data: data });
    }
    saveRoomOrders(data) {
        return this.http.put(this.room_orders_url, { data: data }, true);
    }
    deleteRoomOrders(id) {
        return this.http.delete(this.room_orders_url + "/" + id, {});
    }
    getOrders(data) {
        return this.http.get(this.orders_url, { data: data });
    }
    searchRoomBookTrack(data) {
        return this.http.get(this.room_book_track_url, { data: data });
    }

    roomBookStatus(status: string) {
        let returnList: any[] = [];
        if (status) {
            switch (status) {
                case Props.TRACK_STATUS_BOOKING: {
                    returnList.push({ name: Props.TRACK_STATUS_CHECK_IN, value: Props.TRACK_STATUS_CHECK_IN });
                    returnList.push({ name: Props.TRACK_STATUS_CANCEL, value: Props.TRACK_STATUS_CANCEL });
                    break;
                }
                case Props.TRACK_STATUS_CHECK_IN: {
                    returnList.push({ name: Props.TRACK_STATUS_CHECK_OUT, value: Props.TRACK_STATUS_CHECK_OUT });
                    break;
                }
                case Props.TRACK_STATUS_CHECK_OUT: {
                    returnList.push({ name: Props.TRACK_STATUS_COMPLETE, value: Props.TRACK_STATUS_COMPLETE });
                    break;
                }
                case Props.TRACK_STATUS_CANCEL: {
                    returnList.push({ name: Props.TRACK_STATUS_REFUND, value: Props.TRACK_STATUS_REFUND });
                    break;
                }
                default:
                    break;
            }
        } else {
            // returnList.push({ name: Props.TRACK_STATUS_BOOKING, value: Props.TRACK_STATUS_BOOKING });
            // returnList.push({ name: Props.TRACK_STATUS_CHECK_IN, value: Props.TRACK_STATUS_CHECK_IN });
            // returnList.push({ name: Props.TRACK_STATUS_CHECK_OUT, value: Props.TRACK_STATUS_CHECK_OUT });
            // returnList.push({ name: Props.TRACK_STATUS_CANCEL, value: Props.TRACK_STATUS_CANCEL });
            // returnList.push({ name: Props.TRACK_STATUS_COMPLETE, value: Props.TRACK_STATUS_COMPLETE });
            // returnList.push({ name: Props.TRACK_STATUS_REFUND, value: Props.TRACK_STATUS_REFUND });
        }
        return returnList;
    }
    searchPaymentAddon(id: any) {
        return this.http.get(this.payment_addon_url + "?paymentId=" + id, {});
    }
    savePaymentAddon(data) {
        return this.http.put(this.payment_addon_url, { data: data }, true);
    }
    deletePaymentAddon(id) {
        return this.http.delete(this.payment_addon_url + "/" + id, {});
    }
    printInvoice(data: any) {
        return this.http.print("/invoice", { data: data }, true);
    }
}
