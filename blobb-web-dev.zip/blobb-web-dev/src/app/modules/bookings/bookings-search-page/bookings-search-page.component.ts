import { Component, OnInit } from "@angular/core";
import { RoomBook } from "../../../entities/RoomBook";
import { BookingsService } from "../bookings.service";
import { Props } from "../../../constants/props";
import { FormGroup, FormBuilder } from "@angular/forms";
import { LoadService } from "../../../constants/load.service";

@Component({
    selector: "app-bookings-search-page",
    templateUrl: "./bookings-search-page.component.html",
    styleUrls: ["./bookings-search-page.component.scss"],
})
export class BookingsSearchPageComponent implements OnInit {
    minDate: any;
    roomBook: RoomBook = null;
    roomBookList: RoomBook[] = null;
    propertyList: any;
    selectedTab: string = "ACTIVE";
    selectedProperty: string;
    bookingTabs: any[] = [{ name: "Active", value: "ACTIVE" }, { name: "History", value: "HISTORY" }];

    constructor(private bookingsService: BookingsService, private loadService: LoadService) {
        this.roomBook = new RoomBook();
        this.getProperties();
        this.getRoomBookList();
    }

    ngOnInit() {}

    getProperties() {
        this.loadService.property().subscribe((data: any) => {
            if (!!data) {
                console.log(data);
                this.propertyList = data;
                if (this.propertyList && this.propertyList.length > 0) {
                    this.selectedProperty = this.propertyList[0].val;
                    this.getRoomBookList();
                }
            } else {
                this.propertyList = [];
            }
        });
    }

    onChangeBookingType(item: any) {
        this.selectedTab = item.value;
        this.getRoomBookList();
    }

    getRoomBookList() {
        this.roomBookList = null;
        setTimeout(() => {
            let searchObj: any = {
                propertyIds: this.selectedProperty,
                isActive: this.selectedTab == "ACTIVE" ? "true" : "false",
                fromDate: this.roomBook.fromDate ? this.roomBook.fromDate.toISOString() : null,
                toDate: this.roomBook.toDate ? this.roomBook.toDate.toISOString() : null,
            };
            console.log(searchObj);
            this.bookingsService.getRoomBookList(searchObj).subscribe((result: any) => {
                if (result) {
                    setTimeout(() => {
                        this.roomBookList = result;
                    }, Props.TIME_OUT);
                }
            });
        }, 1000);
    }

    onChangeFilter() {
        this.getRoomBookList();
    }

    bookedRoom(id: any) {
        this.bookingsService.getNav().bookedRoom({ id: id });
    }
    bookingEdit() {
        this.bookingsService.getNav().bookingEdit({ id: null });
    }
}
