import { Component, OnInit, Output, EventEmitter, ViewChild, Input } from "@angular/core";
import { BookingsService } from "./../bookings.service";
import { PaymentAddon } from "../../../entities/PaymentAddon";
import { NgForm } from "@angular/forms";
import { Props } from "src/app/constants/props";

@Component({
    selector: "app-booking-addon-payment-page",
    templateUrl: "./booking-addon-payment-page.component.html",
    styleUrls: ["./booking-addon-payment-page.component.scss"],
})
export class BookingAddonPaymentPageComponent implements OnInit {
    Props = Props;
    @Input()
    status: string;

    id: any;
    paymentAddon: PaymentAddon = null;
    paymentAddonList: any = [];
    private isDisabled: boolean = false;
    countryCodes: any = [];
    showEdit: boolean = false;
    @ViewChild(NgForm) myForm: NgForm;

    paidAmount: number = 0;

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private bookingService: BookingsService) {
        this.paymentAddon = new PaymentAddon();
        this.id = this.bookingService.getParam("id");
        this.paymentAddonEntity(this.id);
    }

    ngOnInit() { }

    paymentAddonEntity(id: any) {
        this.bookingService.searchPaymentAddon(id).subscribe((data: any) => {
            if (data) {
                this.paidAmount = 0;
                this.paymentAddonList = data;
                this.paymentAddonList.map((element) => {
                    this.paidAmount = this.paidAmount + Number(element.amount);
                });
                this.outputEvent.emit(this.paidAmount);
            }
        });
    }
    addPaymentDetails() {
        this.showEdit = true;
        this.paymentAddon = new PaymentAddon();
        // this.roomOrders.roomBook.id = this.roomBookId;
    }
    close1(backdrop) {
        this.showEdit = false;
        this.myForm.form.reset();
    }
    savePaymentAddon() {
        this.paymentAddon.payment.id = this.id;
        console.log(this.paymentAddon);
        this.bookingService.savePaymentAddon(this.paymentAddon).subscribe((data: any) => {
            if (data) {
                this.bookingService.showMessage(data.message);
                this.paymentAddonEntity(this.id);
                this.close1(true);
            }
        });
    }
    deletePaymentDetails(id) {
        this.bookingService.deletePaymentAddon(id).subscribe((data: any) => {
            console.log(data);
            if (data) {
                this.bookingService.showMessage(data.message);
                this.paymentAddonEntity(this.id);
            }
        });
    }
}
