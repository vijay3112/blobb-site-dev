import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter, ViewChild } from "@angular/core";
import { BookingsService } from "../bookings.service";
import { RoomPersons } from "../../../entities/RoomPersons";
import { FileData } from "../../../entities/FileData";
import { NgForm } from "@angular/forms";
import { Props } from "src/app/constants/props";

@Component({
    selector: "app-room-persons-page",
    templateUrl: "./room-persons-page.component.html",
    styleUrls: ["./room-persons-page.component.scss"],
})
export class RoomPersonsPageComponent implements OnInit {
    Props = Props;
    @Input()
    status: string;

    @Input()
    roomBookId: string;
    roomPersons: any = new RoomPersons();
    id: any;
    roomPersonsData: any = [];
    showEdit: boolean = false;

    @ViewChild(NgForm) myForm: NgForm;

    constructor(private service: BookingsService) { }

    ngOnInit() { }
    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["roomBookId"];
        if (changes["roomBookId"] && changes["roomBookId"].currentValue) {
            this.roomPersons.roomBook.id = this.roomBookId;
            this.getRoomPersons();
            // this.save()
        }
    }
    getRoomPersons() {
        let obj = {
            roomBookId: this.roomBookId,
        };
        this.service.getRoomPersons(obj).subscribe((data: any) => {
            console.log(data);
            this.roomPersonsData = data;
            console.log(this.roomPersonsData);
        });
    }
    save() {
        this.service.saveRoomPerson(this.roomPersons).subscribe((data: any) => {
            if (data) {
                this.roomPersons.id = data.id;
                this.roomPersons.fileData.id = data.id;
                this.roomPersons.img.id = data.id;
            }
        });
    }
    mainSave() {
        this.service.saveRoomPerson(this.roomPersons).subscribe((data: any) => {
            if (data) {
                this.getRoomPersons();
                this.close1(true);
            }
        });
    }
    add() {
        this.showEdit = true;
        this.roomPersons = new RoomPersons();
        this.roomPersons.roomBook.id = this.roomBookId;
        this.save();
    }
    close1(backdrop) {
        this.showEdit = false;

        if (this.roomPersons.id && !this.roomPersons.name) {
            this.service.deleteRoomPerson(this.roomPersons.id).subscribe((data: any) => {
                console.log(data);
                this.myForm.form.reset();
            });
        } else {
            this.myForm.form.reset();
        }
    }
    delete($event) {
        this.service.deleteRoomPerson($event).subscribe((data: any) => {
            console.log(data);
            this.getRoomPersons();
        });
    }

    edit(item) {
        console.log(item);
        if (item) {
            // this.roomPersons = item;
            this.roomPersonsEntityData(item.id);
            //  console.log(this.roomPersonsEntityData(item.id));
            this.showEdit = true;
        } else {
            this.roomPersons = new RoomPersons();
        }
    }
    roomPersonsEntityData(id: any) {
        this.service.roomPersonsEntityData(id).subscribe((data: any) => {
            if (data) {
                this.roomPersons = data;
                this.roomPersons.id = data.id;
                this.roomPersons.fileData.id = data.id;
                this.roomPersons.img.id = data.id;
            }
        });
    }
}
