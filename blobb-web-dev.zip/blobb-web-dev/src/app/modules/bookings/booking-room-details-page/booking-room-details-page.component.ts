import { Component, OnInit, Input, SimpleChanges, SimpleChange, Output, ViewChild, EventEmitter } from "@angular/core";
import { BookingsService } from "../bookings.service";
import { RoomBookTrack } from "../../../entities/RoomBookTrack";
import { RoomBook } from "../../../entities/RoomBook";
import { Props } from "../../../constants/props";
import { NgForm } from "@angular/forms";

@Component({
    selector: "app-booking-room-details-page",
    templateUrl: "./booking-room-details-page.component.html",
    styleUrls: ["./booking-room-details-page.component.scss"],
})
export class BookingRoomDetailsPageComponent implements OnInit {
    Props: Props = Props;
    trackList: RoomBookTrack[];
    @ViewChild(NgForm) myForm: NgForm;

    @Input()
    roomBook: RoomBook;

    @Input()
    balanceAmount: number = 0;
@Input()
balanceAmountWoGST: number = 0;
    @Output()
    statusEvent: EventEmitter<any> = new EventEmitter<any>();

    statusGroup: any[] = null;

    constructor(private service: BookingsService) {}

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["roomBook"];
        if (changes["roomBook"] && changes["roomBook"].previousValue != changes["roomBook"].currentValue) {
            this.searchTrackList();
        }
    }

    searchTrackList() {
        this.trackList = null;
        if (this.roomBook.id) {
            this.service.searchRoomBookTrack({ roomBookId: this.roomBook.id }).subscribe((result: any[]) => {
                if (result) {
                    this.trackList = result;
                    this.statusGroup = this.service.roomBookStatus(this.trackList[0].status);
                    this.statusEvent.emit(this.trackList[0].status);
                } else {
                    this.trackList = [];
                }
            });
        }
    }

    onClickStatus($status) {
        this.roomBook.status = $status;
        console.log(this.roomBook);
        this.service.saveBookRoom(this.roomBook).subscribe((data: any) => {
            if (data.entity) {
                this.roomBook.updatedOn = data.entity.updatedOn;
            }
            if (data.message) {
                this.service.showMessage(data.message);
            }
            this.searchTrackList();
        });
    }
}
