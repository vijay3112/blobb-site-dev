import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BookingsSearchPageComponent } from "./bookings-search-page/bookings-search-page.component";
import { BookingsEditPageComponent } from "./bookings-edit-page/bookings-edit-page.component";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "../../shared/shared.module";
import { ComponentsModule } from "../../components/components.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BookingsService } from "./bookings.service";
import { BookedRoomPageComponent } from "./booked-room-page/booked-room-page.component";
import { RoomPersonsPageComponent } from "./room-persons-page/room-persons-page.component";
import { RoomOrdersPageComponent } from "./room-orders-page/room-orders-page.component";
import { BookingRoomDetailsPageComponent } from "./booking-room-details-page/booking-room-details-page.component";
import { BookingAddonPaymentPageComponent } from "./booking-addon-payment-page/booking-addon-payment-page.component";
 


const routes: Routes = [
    { path: "search", component: BookingsSearchPageComponent },
    { path: "edit", component: BookingsEditPageComponent },
    { path: "bookedRoom", component: BookedRoomPageComponent },
];

@NgModule({
    declarations: [
        BookingsSearchPageComponent,
        BookingsEditPageComponent,
        BookedRoomPageComponent,
        RoomPersonsPageComponent,
        RoomOrdersPageComponent,
        BookingRoomDetailsPageComponent,
        BookingAddonPaymentPageComponent,
    ],
    imports: [CommonModule, RouterModule.forChild(routes), ComponentsModule, SharedModule, ReactiveFormsModule, FormsModule ],
    providers: [BookingsService],
})
export class BookingsModule {}
