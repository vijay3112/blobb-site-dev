import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from "@angular/core";
import { NgForm, FormGroup, FormBuilder, FormControl } from "@angular/forms";

import { Props } from "./../../../constants/props";
import { LoadService } from "../../../constants/load.service";
import { BookingsService } from "../bookings.service";
import { Profile } from "../../../entities/Profile";
import { RoomBook } from "../../../entities/RoomBook";
import { Room } from "../../../entities/Room";
import { Payment } from "../../../entities/Payment";
import { Property } from "../../../entities/Property";
import { Util } from "../../../shared/utils/util";
import { Flat } from "../../../entities/Flat";
import { element } from "@angular/core/src/render3";
import { PaymentAddon } from "../../../entities/PaymentAddon";

@Component({
    selector: "app-bookings-edit-page",
    templateUrl: "./bookings-edit-page.component.html",
    styleUrls: ["./bookings-edit-page.component.scss"],
})
export class BookingsEditPageComponent implements OnInit {
    Props: any = Props;
    @ViewChild(NgForm) myForm: NgForm;
    roomBook: RoomBook = null;

    @Input()
    type: string;

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    profile: Profile = null;
    flatList: Flat[];

    roomBookList: RoomBook[] = [];
    state: any;
    personsCount: any = 0;
    disabled = true;
    profileId: any;
    discountPrice: number = 0;
    totalPrice: any = 0;
    totalCgstPrice: any = 0;
    totalSgstPrice: any = 0;
    TotalAmount: any = 0;
    updatedAmount: number = 0;
    selectedRooms: any = 0;
    isARoomSelected: Boolean = false;
    cgst: number = 0;
    sgst: number = 0;
    roomPriceAfterDiscount: number = 0;

    daysDiff: number = 0;
    bookingAmount: number = 0;
    showEdit: boolean = false;
    discount: number = 0;
    constructor(private loadService: LoadService, private bookingsService: BookingsService) {
        this.roomBook = new RoomBook();
        this.roomBook.room = new Room();
        this.roomBook.room.property = new Property();
        this.profile = new Profile();
    }

    ngOnInit() {
        this.roomBook.fromDate = Util.CurrentDate();
        this.roomBook.toDate = Util.DaysBack(Util.CurrentDate(), -1);
        // this.onChangePeriod(this.roomBook);
        this.decrement();
    }

    onChangeBookType(event: any) {
        if (this.roomBookList.length >= 0) {
            this.roomBookList.map((obj: RoomBook) => {
                obj.bookType = this.roomBook.bookType;
            });
        }
    }

    increment() {
        this.personsCount = this.personsCount == 10 ? this.personsCount : ++this.personsCount;
        if (this.personsCount > 0) {
            this.disabled = false;
        }
    }
    decrement() {
        this.personsCount = this.personsCount > 0 ? --this.personsCount : 0;
        if (this.personsCount <= 0) {
            this.disabled = true;
        }
    }
    onChangePeriod(event: any) {
        this.roomBookList = null;
        this.flatList = null;
        let searchObj: any = {
            fromDate: event.fromDate.toISOString(),
            toDate: event.toDate.toISOString(),
            propertyIds: [event.room.property.id],
        };
        this.daysDiff = Util.DaysDiff(event.fromDate, event.toDate);
        this.bookingsService.getAvailableRoomsList(searchObj).subscribe((roomList: any) => {
            this.roomBookList = [];
            if (!!roomList) {
                this.flatList = roomList;
                this.prepareRoomBookList();
            } else {
                this.flatList = [];
            }
        });
        setTimeout(() => {
            this.resetToDefaultValues();
            this.selectedRooms = 0;
        }, 100);
    }
    prepareRoomBookList() {
        this.flatList.forEach((item: Flat) => {
            if (!item.roomBookList) {
                item.roomBookList = [];
            }
            //let found = this.roomBookList.some((item) => item.room.id === element.id);
            item.rooms.forEach((element: Room) => {
                let obj: RoomBook = new RoomBook();
                obj.payment = new Payment();
                obj.bookType = this.roomBook.bookType;
                obj.fromDate = this.roomBook.fromDate;
                obj.toDate = this.roomBook.toDate;
                obj.room = element;
                if (!element.isLock) {
                    obj.payment.units = this.daysDiff;
                } else {
                    obj.payment.units = 0;
                }
                obj.payment.cost = element.paymentTax.cost;
                obj.payment.cgst = element.paymentTax.cgst;
                obj.payment.sgst = element.paymentTax.sgst;
                obj.payment.igst = element.paymentTax.igst;
                item.roomBookList.push(obj);
                this.roomBookList.push(obj);
            });
        });
    }
    selectRoom(selectedItem: RoomBook) {
        selectedItem.isSelected = !selectedItem.isSelected;
        this.isARoomSelected = this.roomBookList.some((item) => item.isSelected);
        this.finalCalculation();
        // let found = this.selectedRoomBookList.some(item => item.room.id === selectedItem.room.id);
        // if (!found) {
        //   this.selectedRoomBookList.push(selectedItem);
        //   //this.calculate()
        // } else {
        //   let index = this.selectedRoomBookList.indexOf(selectedItem)
        //   this.selectedRoomBookList.splice(index, 1);
        //   //this.calculate()
        // }
    }
    resetToDefaultValues() {
        this.totalPrice = 0;
        this.totalCgstPrice = 0;
        this.totalSgstPrice = 0;
        this.discountPrice = 0;
        this.TotalAmount = 0;
        this.roomPriceAfterDiscount = 0;
    }
    finalCalculation() {
        this.resetToDefaultValues();
        this.roomBookList.forEach((element: RoomBook) => {
            if (element.payment && element.isSelected == true) {
                element.price = element.payment.price;
                // element.cgstPrice = element.payment.cgstPrice;
                // element.sgstPrice = element.payment.sgstPrice;
                // element.igstPrice = element.payment.igstPrice;
                element.payment.discount = this.discount;
                element.payment.discountPrice = (Number(element.payment.price) * Number(element.payment.discount)) / 100;
                let subTotal = element.price - element.payment.discountPrice;
                element.payment.cgstPrice = (Number(subTotal) * Number(element.payment.cgst)) / 100;
                element.payment.sgstPrice = (Number(subTotal) * Number(element.payment.sgst)) / 100;
                element.amount = subTotal + element.payment.sgstPrice + element.payment.cgstPrice;
                this.discountPrice += Number(element.payment.discountPrice);
                this.totalCgstPrice += Number(element.payment.cgstPrice);
                this.totalSgstPrice += Number(element.payment.sgstPrice);
                this.totalPrice += Number(element.price);
                this.roomPriceAfterDiscount += Number(subTotal);
                this.TotalAmount += Number(element.amount);
                // this.updatedAmount += Number(element.amount);
            }
        });
        this.paymentAddonDistrubution();
    }
    /**
     * Amount is distrubuted in the amount sorting order
     */
    paymentAddonDistrubution() {
        // this.discountPrice = Math.ceil((Number(this.totalPrice) * Number(this.discount)) / 100);
        // this.TotalAmount = this.updatedAmount - this.discountPrice;
        let roomsSelected = this.roomBookList.filter((element) => element.isSelected);
        this.selectedRooms = roomsSelected.length;
        roomsSelected = roomsSelected.sort((a, b) => a.amount - b.amount);
        let isRoomAmount = this.TotalAmount == this.bookingAmount;
        let adjectAmt = 0;
        let advanceAmt = Math.floor(this.bookingAmount / this.selectedRooms);
        adjectAmt = this.bookingAmount - advanceAmt * this.selectedRooms;
        if (!isRoomAmount) {
        }

        roomsSelected.forEach((element) => {
            element.payment.paymentAddonList = [];
            if (isRoomAmount) {
                element.payment.paymentAddonList.push(Object.assign(new PaymentAddon(), { amount: element.payment.amount }));
            } else {
                if (element.payment.amount < advanceAmt + adjectAmt) {
                    adjectAmt = advanceAmt + adjectAmt - element.payment.amount;
                    element.payment.paymentAddonList.push(Object.assign(new PaymentAddon(), { amount: element.payment.amount }));
                } else {
                    element.payment.paymentAddonList.push(Object.assign(new PaymentAddon(), { amount: advanceAmt + adjectAmt }));
                    adjectAmt = 0;
                }
            }
        });
    }

    bookNow() {
        // this.bookingsService.searchProfile({}).subscribe((result: any) => {
        //     if (result) {
        //         let filterResult = result.filter((item) => item.email === this.profile.email || item.mobile === this.profile.mobile);
        //         if (filterResult.length) {
        //             this.profile = filterResult[0];
        //             this.bookRoom();
        //         } else {
        //             this.bookingsService.saveProfileData(this.profile).subscribe((data: any) => {
        //                 this.profile.id = data.id;
        //                 this.bookRoom();
        //             });
        //         }
        //     }
        // });
        if (this.profile.id) {
            this.bookRoom();
            this.bookingsService.getNav().bookingSearch(null);
        } else {
            this.bookingsService.showMessage("Please check profile");
        }
    }
    bookRoom() {
        this.roomBookList.map((ele) => {
            ele.profile = this.profile;
        });
        let bookedRooms: RoomBook[] = this.roomBookList.filter((item: RoomBook) => item.isSelected);
        this.bookingsService.saveBookRooms(bookedRooms).subscribe((data: any) => {
            this.bookingsService.showMessage(data.message);
        });
    }
    profileSave($event) {
        this.bookingsService.saveProfileData($event).subscribe((data: any) => {
            if (data.id) {
                this.profile.id = data.id;
            }
        });
    }
    changeAmount() {
        setTimeout(() => {
            this.paymentAddonDistrubution();
        }, 100);
    }
    isInValidBookingAmount: boolean = false;
    checkForValidAmount() {
        if (this.bookingAmount > this.TotalAmount) {
            this.isInValidBookingAmount = true;
        } else {
            this.isInValidBookingAmount = false;
        }
    }

    onDiscount() {
        setTimeout(() => {
            if (this.discount > 100) {
                this.discount = 0;
                this.bookingsService.showMessage("Invalid Discount");
            } else {
                this.finalCalculation();
            }
        }, 100);
    }
}
