import { Component, OnInit, Input } from "@angular/core";

import { RoomBook } from "./../../../entities/RoomBook";
import { RoomOrders } from "./../../../entities/RoomOrders";
import { RoomPersons } from "./../../../entities/RoomPersons";

import { BookingsService } from "./../bookings.service";
import { PaymentAddon } from "../../../entities/PaymentAddon";
import { element } from "@angular/core/src/render3";
import { Props } from "src/app/constants/props";
import { ThrowStmt } from "@angular/compiler";

@Component({
    selector: "app-booked-room-page",
    templateUrl: "./booked-room-page.component.html",
    styleUrls: ["./booked-room-page.component.scss"],
})
export class BookedRoomPageComponent implements OnInit {
    Props = Props;
    id: any;
    imgId: string;
    roomBook: RoomBook = null;
    roomOrders: RoomOrders = null;
    roomPersons: RoomPersons = null;
    paymentAddon: PaymentAddon = null;
    paymentAddonList: any = [];
    private isDisabled: boolean = false;
    countryCodes: any = [];
    showEdit: boolean = false;
    status: string = "init";
    tabs = ["Details", "Room Orders", "Room Persons"];
    serviceAmount: number = 0;
    paidAmount: number = 0;
    roomOrdersData: RoomOrders[];
    balanceAmount: number = 0;
    balanceAmountWoGST: number = 0;
    serviceAmountWoGST: number = 0;
    roomAmountWoGST: number=0;
    constructor(private bookingService: BookingsService) {
        this.roomBook = new RoomBook();
        this.paymentAddon = new PaymentAddon();
        this.id = this.bookingService.getParam("id");
        this.roomBookEntity(this.id);
        //this.paymentAddonEntity(this.id);
    }

    ngOnInit() { }
    roomBookEntity(id: any) {
        this.bookingService.roomBookEntityData(id).subscribe((data: any) => {
            if (data) {
                this.roomBook = data;
                this.roomAmountWoGSTEmit();
                this.balanceAmountEmit();
                this.balanceAmountWoGSTEmit();
            }
        });
    }
    // paymentAddonEntity(id: any) {
    //     this.bookingService.searchPaymentAddon(id).subscribe((data: any) => {
    //         if (data) {
    //             this.paidAmount = 0;
    //             this.paymentAddonList = data;
    //             this.paymentAddonList.map((element) => {
    //                 this.paidAmount = this.paidAmount + element.amount;
    //             });
    //             this.balanceAmountEmit();
    //         }
    //     });
    // }
    addPaymentDetails() {
        this.showEdit = true;
        this.paymentAddon = new PaymentAddon();
        // this.roomOrders.roomBook.id = this.roomBookId;
    }

    tabChange($event) { }
    close1(backdrop) {
        this.showEdit = false;
    }
    // savePaymentAddon() {
    //     this.paymentAddon.payment.id = this.id;
    //     console.log(this.paymentAddon);
    //     this.bookingService.savePaymentAddon(this.paymentAddon).subscribe((data: any) => {
    //         if (data) {
    //             this.bookingService.showMessage(data.message);
    //             this.close1(true);
    //             this.paymentAddonEntity(this.id);
    //         }
    //     });
    // }
    deletePaymentDetails(id) {
        console.log(id);
    }
    paidAmountEmit($event) {
        this.paidAmount = $event;
        this.balanceAmountEmit();
        this.balanceAmountWoGSTEmit();
    }
    serviceAmountEmit($event) {
        this.serviceAmount = $event;
        this.balanceAmountEmit();
    }
    serviceAmountWoGSTEmit($event) {
       this.serviceAmountWoGST = $event;
       this.balanceAmountWoGSTEmit();
    }
    balanceAmountEmit() {
        console.log(this.serviceAmount);
        this.balanceAmount = (this.roomBook.amount - this.paidAmount) + this.serviceAmount;
        console.log(this.balanceAmount);
    }
    balanceAmountWoGSTEmit(){
        this.balanceAmountWoGST = (this.roomAmountWoGST - this.paidAmount) + this.serviceAmountWoGST;
    }
    roomAmountWoGSTEmit(){
        let subTotal = this.roomBook.price - this.roomBook.payment.discountPrice;
     this.roomAmountWoGST += Number(subTotal);
    }
    statusChange($event: any) {
        this.status = $event;
    }
    print() {
        this.bookingService.printInvoice({ id: this.roomBook.id });
    }
}
