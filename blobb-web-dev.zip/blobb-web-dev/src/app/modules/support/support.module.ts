import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "../../shared/shared.module";
import { ComponentsModule } from "../../components/components.module";
import { SubscribePageComponent } from "./subscribe-page/subscribe-page.component";
import { ContactPageComponent } from "./contact-page/contact-page.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

const routes: Routes = [{ path: "subscribe", component: SubscribePageComponent }, { path: "contact", component: ContactPageComponent }];

@NgModule({
    declarations: [SubscribePageComponent, ContactPageComponent],
    imports: [CommonModule, FormsModule, ReactiveFormsModule, SharedModule, ComponentsModule, RouterModule.forChild(routes)],
    providers: [],
})
export class SupportModule {}
