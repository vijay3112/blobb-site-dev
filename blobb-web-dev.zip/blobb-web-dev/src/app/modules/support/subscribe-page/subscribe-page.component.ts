import { Component, OnInit } from "@angular/core";
import { LoadService } from "../../../constants/load.service";
import { AppSubscribe } from "src/app/entities/AppSubscribe";
import { SupportService } from "../support.service";

@Component({
    selector: "app-subscribe-page",
    templateUrl: "./subscribe-page.component.html",
    styleUrls: ["./subscribe-page.component.scss"],
})
export class SubscribePageComponent implements OnInit {
    dataList: any = [];
    appSubscribe: AppSubscribe = null;
    constructor(private service: SupportService, private loadService: LoadService) {
        this.getSubscribe();
    }

    ngOnInit() {}

    // getSubscribe() {
    //     this.service.subscribeEntityData(this.appSubscribe).subscribe((data: any) => {
    //         this.dataList = data;
    //         console.log(this.dataList);
    //     });
    // }

    getSubscribe() {
        this.service.subscribeEntityData(this.dataList).subscribe((data: any) => {
            if (data) {
                this.dataList = data;
                console.log(this.dataList);
            }
        });
    }
    save(item: any) {
        this.service.subscribeSave(item).subscribe((data: any) => {
            this.service.showMessage(data.message);
        });
    }
}
