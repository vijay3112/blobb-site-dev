import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { WebContactUs } from "../../../entities/WebContactUs";
import { Props } from "../../../constants/props";
import { SupportService } from "../support.service";

@Component({
    selector: "app-contact-page",
    templateUrl: "./contact-page.component.html",
    styleUrls: ["./contact-page.component.scss"],
})
export class ContactPageComponent implements OnInit {
    @ViewChild(NgForm) myForm: NgForm;
    contact: WebContactUs;
    dataList: any[] = null;
    showEdit: boolean = false;
    searchText: string;
    searchObj: Object = null;
    selectedTab: any = "active";

    displayedColumns: string[] = ["name", "email", "mobile", "message"];

    ratingTabs: any[] = [{ name: "Unread", value: "true" }, { name: "read", value: "false" }];

    constructor(private service: SupportService) {}

    ngOnInit() {
        this.search(this.selectedTab);
    }
    toggleEdit($event: any) {
        if ($event == "open") {
            this.showEdit = true;
        } else {
            this.showEdit = false;
            // this.search();
        }
    }

    onChangeBookingType(item: any) {
        this.selectedTab = item.value;
        this.search(this.selectedTab);
    }
    close1(backdrop) {
        this.showEdit = false;
        this.myForm.form.reset();
    }
    edit(item) {
        if (item) {
            this.entityData(item.id);
            this.showEdit = true;
        } else {
            this.showEdit = true;
            this.contact = new WebContactUs();
        }
    }
    search(data: any) {
        this.dataList = null;
        data = { active: data };
        this.service.search(data).subscribe((data: any) => {
            if (data) {
                setTimeout(() => {
                    this.dataList = data;
                    console.log(this.dataList);
                }, Props.TIME_OUT);
            }
        });
    }
    entityData(id: any) {
        this.service.entityData(id).subscribe((data: any) => {
            if (data) {
                this.contact = data;
            }
        });
    }
    save() {
        this.service.save(this.contact).subscribe((data: any) => {
            if (data) {
                console.log(data);
                this.search(this.selectedTab);
                this.service.showMessage(data.message);
                this.close1(true);
            }
        });
    }
}
