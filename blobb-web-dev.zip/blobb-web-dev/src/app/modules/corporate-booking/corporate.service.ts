import { Injectable } from "@angular/core";
import { AppService } from "../../shared/service/app.service";
import { HttpService } from "../../shared/service/http.service";
import { LoadService } from "../../constants/load.service";
import { NavService } from "../../constants/nav.service";

@Injectable({
    providedIn: "root",
})
export class CorporateService {
    private service_url = "/corporatebooking";

    constructor(private http: HttpService, private appService: AppService, private loadService: LoadService, private navService: NavService) {}
    getLoad(): LoadService {
        return this.loadService;
    }

    getNav(): NavService {
        return this.navService;
    }

    getApp(): AppService {
        return this.appService;
    }

    showMessage(message: string) {
        this.appService.showMessage(message);
    }

    getParam(key: string): String {
        return this.navService.param(key);
    }

    search(filter: any) {
        return this.http.get(this.service_url, { data: filter });
    }

    entityData(id: any) {
        return this.http.get(this.service_url + "/" + id, {});
    }
    save(data: any) {
        return this.http.put(this.service_url, { data: data }, true);
    }
}
