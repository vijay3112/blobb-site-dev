import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { Routes, RouterModule } from "@angular/router";
import { ComponentsModule } from "../../components/components.module";
import { CorporatePageComponent } from "./corporate-page/corporate-page.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

const routes: Routes = [{ path: "booking", component: CorporatePageComponent }];

@NgModule({
    imports: [CommonModule, SharedModule, ComponentsModule, RouterModule.forChild(routes), FormsModule, ReactiveFormsModule],
    declarations: [CorporatePageComponent],
    providers: [],
})
export class CorporateModule {}
