import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { CorporateBooking } from "../../../entities/CorporateBooking";
import { CorporateService } from "../corporate.service";
import { Props } from "src/app/constants/props";

@Component({
    selector: "app-corporate-page",
    templateUrl: "./corporate-page.component.html",
    styleUrls: ["./corporate-page.component.scss"],
})
export class CorporatePageComponent implements OnInit {
    @ViewChild(NgForm) myForm: NgForm;
    corporateBooking: CorporateBooking;
    dataList: any[];
    showEdit: boolean = false;
    searchText: string;
    searchObj: Object = null;
    selectedTab: any = "active";

    displayedColumns: string[] = ["name", "email", "mobile"];
    ratingTabs: any[] = [{ name: "All", value: "all" }, { name: "Active", value: "active" }, { name: "De-Active", value: "de-active" }];

    constructor(private service: CorporateService) {}

    ngOnInit() {
        this.search(this.selectedTab);
    }
    toggleEdit($event: any) {
        if ($event == "open") {
            this.showEdit = true;
        } else {
            this.showEdit = false;
            // this.search();
        }
    }

    onChangeBookingType(item: any) {
        this.selectedTab = item.value;
        this.search(this.selectedTab);
    }

    close1(backdrop) {
        this.showEdit = false;
        this.myForm.form.reset();
    }

    edit(item) {
        if (item) {
            this.entityData(item.id);
            this.showEdit = true;
        } else {
            this.showEdit = true;
            this.corporateBooking = new CorporateBooking();
        }
    }

    search(data: any) {
        this.dataList = null;
        data = { param: data };
        this.service.search(data).subscribe((data: any) => {
            if (data) {
                setTimeout(() => {
                    this.dataList = data;
                    console.log(this.dataList);
                }, Props.TIME_OUT);
            }
        });
    }

    entityData(id: any) {
        this.service.entityData(id).subscribe((data: any) => {
            if (data) {
                this.corporateBooking = data;
            }
        });
    }
    save() {
        this.service.save(this.corporateBooking).subscribe((data: any) => {
            if (data) {
                console.log(data);
                this.search(this.selectedTab);
                this.service.showMessage(data.message);
                this.close1(true);
            }
        });
    }
}
