import { Component, OnInit, Output, EventEmitter, ViewChild } from "@angular/core";
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";
import { Expenses } from "../../../entities/Expenses";
import { ExpensesService } from "../expenses.service";
import { LoadService } from "../../../constants/load.service";
import { FormControl, NgForm } from "@angular/forms";
import { AppData } from "../../../entities/AppData";
import { Property } from "../../../entities/Property";

@Component({
    selector: "app-expenses-page",
    templateUrl: "./expenses-page.component.html",
    styleUrls: ["./expenses-page.component.scss"],
})
export class ExpensesPageComponent implements OnInit {
    showEdit: boolean = false;
    searchText: string;
    searchObj: any = null;
    dataSource: MatTableDataSource<any>;
    expensesList: any[];
    expenses: Expenses;
    typeList: any = [];
    branchList: any = [];
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(NgForm) myForm: NgForm;

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();
    selectedTypes: string[];
    selectedBranches: string[];
    typesControl = new FormControl();
    branchControl = new FormControl();
    auxT: any = [];

    constructor(private service: ExpensesService, private loadService: LoadService) {}

    ngOnInit() {
        // this.search();
        this.expensesDataList(this.searchObj);
        this.loadType();
        this.loadBranches();
    }
    toggleEdit($event: any) {
        if ($event == "open") {
            this.showEdit = true;
        } else {
            this.showEdit = false;
            // this.search();
        }
    }

    close1(backdrop) {
        this.showEdit = false;
        this.myForm.form.reset();
    }

    expensesDataList(searchObject) {
        this.service.getexpenses(searchObject).subscribe((results: any[]) => {
            this.expensesList = results;
        });
    }
    editExpenses(item) {
        if (item) {
            // this.expenses = item;
            this.entityData(item.id);
            this.showEdit = true;
        } else {
            this.showEdit = true;
            this.expenses = new Expenses();
        }
    }

    save() {
        // this.expenses = null;
        this.service.save(this.expenses).subscribe((data: any) => {
            // var searchObject = {
            //     fromDate: Date,
            //     toDate: Date,
            // };
            // searchObject.fromDate = this.searchObj.fromDate.toISOString();
            // searchObject.toDate = this.searchObj.toDate.toISOString();

            // this.expensesDataList(searchObject);
            if (data) {
                this.expensesDataList(this.searchObj);
                this.service.showMessage(data.message);
                this.close1(true);
            }
        });
    }
    search() {
        console.log(this.searchObj);

        var searchObject = {
            fromDate: Date,
            toDate: Date,
        };

        searchObject.fromDate = this.searchObj.fromDate.toISOString();
        searchObject.toDate = this.searchObj.toDate.toISOString();

        console.log(searchObject);
        this.expensesDataList(searchObject);
    }
    private loadType() {
        this.loadService.expensesTypes().subscribe((results: any[]) => {
            if (results) {
                this.typeList = results;
            } else {
                this.typeList = [];
            }
        });
    }
    private loadBranches() {
        this.loadService.propertyAll().subscribe((results: any[]) => {
            if (results) {
                this.branchList = results;
            } else {
                this.branchList = [];
            }
        });
    }
    compareFn(user1: AppData, user2: AppData) {
        return user1 && user2 ? user1.id === user2.id : user1 === user2;
    }
    compareFn1(user1: Property, user2: Property) {
        return user1 && user2 ? user1.name === user2.name : user1 === user2;
    }
    entityData(id: any) {
        this.service.entityData(id).subscribe((data: any) => {
            if (data) {
                this.expenses = data;
            }
        });
    }
}
