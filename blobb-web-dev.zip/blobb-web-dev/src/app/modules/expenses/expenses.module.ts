import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ExpensesPageComponent} from './expenses-page/expenses-page.component';
import {Routes, RouterModule} from '@angular/router';
import {SharedModule} from '../../shared/shared.module';
import {ComponentsModule} from '../../components/components.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {ExpensesService} from './expenses.service';

const routes: Routes = [
  {path: 'expenses', component: ExpensesPageComponent},
  ];

@NgModule({
  declarations: [ExpensesPageComponent],
  imports: [    CommonModule,
    SharedModule.forRoot(),
    ComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)],
  providers: [ExpensesService],
})
export class ExpensesModule {
}
