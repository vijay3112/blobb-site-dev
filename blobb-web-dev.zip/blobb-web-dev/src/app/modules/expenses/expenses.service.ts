import { Injectable } from "@angular/core";
import { HttpService } from "../../shared/service/http.service";
import { AppService } from "../../shared/service/app.service";
import { NavService } from "../../constants/nav.service";
import { MENU } from "../../constants/menu";

@Injectable({
  providedIn: "root",
})
export class ExpensesService {
  private expenses_url = "/expenses";

  constructor(private http: HttpService, private navService: NavService, private appService: AppService) { }

  getNav(): NavService {
    return this.navService;
  }

  save(data: any) {
    return this.http.put(this.expenses_url, { data: data });
  }
  bookingEdit(params: any) {
    this.appService.navigate(MENU.BOOKING_EDIT.link, params);
  }
  getexpenses(filter: any) {
    return this.http.get(this.expenses_url, { data: filter });
  }
  showMessage(message: string) {
    this.appService.showMessage(message);
  }
  entityData(id: any) {
    return this.http.get(this.expenses_url + "/" + id, {});
  }
}
