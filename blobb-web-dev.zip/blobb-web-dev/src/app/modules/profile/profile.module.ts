import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { Routes, RouterModule } from "@angular/router";
import { ComponentsModule } from "../../components/components.module";
import { ProfileService } from "../profile/profile.service";
import { MyprofilePageComponent } from "./myprofile-page/myprofile-page.component";
import { ProfileSearchPageComponent } from "./profile-search-page/profile-search-page.component";
import { ProfileEditPageComponent } from "./profile-edit-page/profile-edit-page.component";
import { ChangePasswordComponent } from "./change-password/change-password.component";
import { ProfileAddPageComponent } from './profile-add-page/profile-add-page.component';

const routes: Routes = [
  { path: "myprofile", component: MyprofilePageComponent },
  { path: "search", component: ProfileSearchPageComponent },
  { path: "edit", component: ProfileEditPageComponent }
];

@NgModule({
  declarations: [
    MyprofilePageComponent,
    ProfileSearchPageComponent,
    ProfileEditPageComponent,
    ChangePasswordComponent,
    ProfileAddPageComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    ComponentsModule,
    RouterModule.forChild(routes)
  ],
  providers: [ProfileService]
})
export class ProfileModule { }
