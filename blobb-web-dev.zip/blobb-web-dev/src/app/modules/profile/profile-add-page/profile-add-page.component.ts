import {
  Component,
  OnInit,
  ViewChild,
  Input,
  Output,
  EventEmitter
} from "@angular/core";
import { Profile } from "../../../entities/Profile";
import { ProfileService } from "../profile.service";
import { NgForm } from "@angular/forms";

@Component({
  selector: "app-profile-add-page",
  templateUrl: "./profile-add-page.component.html",
  styleUrls: ["./profile-add-page.component.scss"]
})
export class ProfileAddPageComponent implements OnInit {
  profile: Profile = new Profile();
  @ViewChild(NgForm) myForm: NgForm;
  showEdit: boolean = false;

  @Output()
  outputEvent: EventEmitter<any> = new EventEmitter<any>();

  constructor(private service: ProfileService) { }

  ngOnInit() { }
  save() {
    this.service.saveProfileData(this.profile).subscribe((data: any) => {
      if (data) {
        this.service.showMessage(data.message);
        // this.ngOnInit();
        this.onClose();
        this.service.getNav().profileEdit(data);
      }
    });
  }
  onClose() {
    this.showEdit = false;
    this.myForm.form.reset();
    this.profile.data = null;
        this.outputEvent.emit();
  }
}
