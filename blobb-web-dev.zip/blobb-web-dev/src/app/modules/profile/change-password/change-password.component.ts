import {Component, OnInit, ViewEncapsulation, Input} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material';
import {ControlContainer, NgForm} from '@angular/forms';
import {AppService} from '../../../shared/service/app.service';
import {HttpService} from '../../../shared/service/http.service';
import {Props} from '../../../constants/props';
import {Title} from '@angular/platform-browser';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
  viewProviders: [{provide: ControlContainer, useExisting: NgForm}],
  encapsulation: ViewEncapsulation.None
})
export class ChangePasswordComponent {
  Props: any = Props;
  obj: any = {};
  oldpasswordErrMsg: string = 'Password required';
  password: string;
  inputType = 'password';
  viewSource: boolean;
  viewSource2: boolean;
  color = '';
  dialogRef: MatDialogRef<any>;

  @Input()
  type: string;

  constructor(
    private appService: AppService,
    private httpService: HttpService,
    private titleService: Title,
    private dialog: MatDialog
  ) {
  }

  // onStrengthChanged(strength: number) {
  //   console.log("password strength = ", strength);
  // }

  onSubmit() {
    this.obj.id = this.appService.getSessionUser().id;
    this.httpService.post('/profile', {data: this.obj}).subscribe(data => {
      if (data) {
        this.appService.showMessage('Password changed succesfully');
        this.dialogRef.close();
      }
    });
  }

  onClose(mode: any) {
    this.dialogRef.close();
  }

  hide: boolean = true;
  hide1: boolean = true;

  openDialog($event): void {
    this.dialogRef = this.dialog.open($event, {
      width: '50%',
      height: 'auto'
    });
    this.dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
}
