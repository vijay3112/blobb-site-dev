import { Component, OnInit, ViewChild, Output, EventEmitter } from "@angular/core";
import { ProfileService } from "../profile.service";
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";

import { NgForm } from "@angular/forms";
import { Props } from "../../../constants/props";

@Component({
  selector: "app-profile-search-page",
  templateUrl: "./profile-search-page.component.html",
  styleUrls: ["./profile-search-page.component.scss"],
})
export class ProfileSearchPageComponent implements OnInit {
  dataList: any[];
  profileId: string;
  showEdit: boolean = false;
  searchText: string;
  searchObj: Object = null;
  dataSource: MatTableDataSource<any>;

  displayedColumns: string[] = ["name", "email", "mobile", "role", "status"];

  @ViewChild(MatSort) sort: MatSort;
  @Output()
  outputEvent: EventEmitter<any> = new EventEmitter<any>();
  countryCodes: any = [];

  constructor(private service: ProfileService) { }

  ngOnInit() {
    this.search();
  }
  toggleEdit($event: any) {
    if ($event == "open") {
      this.showEdit = true;
    } else {
      this.showEdit = false;
      this.search();
    }
  }

  close1(backdrop) {
    this.showEdit = false;
  }
  search() {
    this.dataList = null;
    this.service.search(null).subscribe((result: any) => {
      if (result) {
        setTimeout(() => {
          this.dataList = result;
        }, Props.TIME_OUT);
      }
    });
  }

  checkNumber(item) {
    return isNaN(item) ? "" : item;
  }
  edit(id: any) {
    this.service.getNav().profileEdit({ id: id });
  }
}
