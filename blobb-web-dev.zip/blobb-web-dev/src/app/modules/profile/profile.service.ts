import { Injectable } from "@angular/core";
import { AppService } from "../../shared/service/app.service";
import { HttpService } from "../../shared/service/http.service";
import { LoadService } from "../../constants/load.service";
import { NavService } from "../../constants/nav.service";
import { ReportService } from "../../shared/service/report.service";
import { Props } from "../../constants/props";

@Injectable({
    providedIn: "root",
})
export class ProfileService {
    private service_url = "/profile";
    private profile_docs_url = "/profiledocs";
    private profile_docs_tweet_url = "/profiledocstweet";
    private file_upload_url = "/filedata";
    private address_url = "/address";
    constructor(private http: HttpService, private appService: AppService, private loadService: LoadService, private navService: NavService, private reportService: ReportService) {
        this.reportService.PY_ENDPOINT = Props.PY_END_POINT;
    }

    getLoad(): LoadService {
        return this.loadService;
    }

    getNav(): NavService {
        return this.navService;
    }

    getApp(): AppService {
        return this.appService;
    }

    showMessage(message: string) {
        this.appService.showMessage(message);
    }

    getParam(key: string): String {
        return this.navService.param(key);
    }

    search(filter: any) {
        return this.http.get(this.service_url, { data: filter });
    }

    entityData(id: any) {
        return this.http.get(this.service_url + "/" + id, {});
    }
    saveProfileData(data: any) {
        return this.http.put(this.service_url, { data: data }, true);
    }

    searchprofileDocs(filter: any) {
        return this.http.get(this.profile_docs_url, { data: filter });
    }

    entityprofileDocs(profileId: any) {
        return this.http.get(this.profile_docs_url + "/" + profileId, {});
    }

    saveprofileDocs(data: any) {
        return this.http.put(this.profile_docs_url, { data: data }, true);
    }
    saveAddress(data: any) {
        return this.http.put(this.address_url, { data: data }, true);
    }
    profileDocsTweetSearch(docId: any) {
        return this.http.get(this.profile_docs_tweet_url, {
            data: { docId: docId },
        });
    }

    profileDocsTweetSave(data: any) {
        return this.http.put(this.profile_docs_tweet_url, { data: data });
    }
    fileUpload(_formData: FormData) {
        return this.http.formData(this.file_upload_url, _formData);
    }
    getFile(docId: any) {
        return this.reportService.pdf(
            this.file_upload_url,
            {
                data: { id: docId },
            },
            docId
        );
    }
}
