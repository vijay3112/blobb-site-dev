import { Component, OnInit, Input } from "@angular/core";
import { Profile } from "../../../entities/Profile";
import { ProfileDocs } from "../../../entities/ProfileDocs";
import { NavService } from "../../../constants/nav.service";
import { ProfileService } from "../profile.service";
import { ChangePasswordComponent } from "../change-password/change-password.component";
import { ApexService } from "../../../shared/service/apex.service";

import { MatDialog } from "@angular/material";
import { Props } from "../../../constants/props";

// profile docs entities //
import { Address } from "../../../entities/Address";

@Component({
    selector: "app-myprofile-page",
    templateUrl: "./myprofile-page.component.html",
    styleUrls: ["./myprofile-page.component.scss"],
})
export class MyprofilePageComponent implements OnInit {
    id: string;
    imgId: string;
    profile: Profile = null;
    address: Address = null;
    profileDocs: ProfileDocs = null;
    private isDisabled: boolean = false;
    countryCodes: any = [];
    tabs = ["DETAILS", "ADDRESS", "PROFILE_DOCS", "FILE_UPLOAD"];

    constructor(private profileService: ProfileService) {
        this.profile = new Profile();
        this.profileDocs = new ProfileDocs();
        this.id = this.profileService.getApp().getSessionUser().id;
        this.entityData(this.id);
        this.entityprofileDocs(this.id);
        this.imgId = this.id;
    }

    ngOnInit() {}

    entityData(id: any) {
        this.profileService.entityData(id).subscribe((data: any) => {
            if (data) {
                this.profile = data;
                let mobile: any = this.profile.mobile;
                this.profile.mobile = isNaN(mobile) ? "" : this.profile.mobile;
            }
        });
    }

    entityprofileDocs(id: any) {
        this.profileService.entityprofileDocs(id).subscribe((data: any) => {
            this.profileDocs = data;
            let mobile: any = this.profileDocs.profile.mobile;
            this.profileDocs.profile.mobile = isNaN(mobile) ? "" : this.profileDocs.profile.mobile;

            // if (this.profileDocs) {
            //   this.profiledocstweet();
            // }
        });
    }

    tabChange($event) {
        if ($event.tab.textLabel === "PROFILE") {
        } else if ($event.tab.textLabel === "PROFILE_DOCS") {
        }
    }

    imgChange($event: any) {
        this.imgId = null;
        setTimeout(() => {
            this.imgId = this.id;
        }, 100);
        this.profileService.getApp().dataEmit($event);
    }

    uploadFile($event: FormData) {
        this.profileService.fileUpload($event).subscribe((data: any) => {
            if (data) {
                this.profileService.showMessage(data.message);
            }
        });
    }

    saveProfile() {
        this.profileService.saveProfileData(this.profile).subscribe((data: any) => {
            if (data) {
                this.entityData(this.id);
                this.profileService.showMessage(data.message);
            }
        });
    }

    saveProfileDocs() {
        this.profileService.saveprofileDocs(this.profileDocs).subscribe((data: any) => {
            if (data) {
                this.entityprofileDocs(this.id);
                this.profileService.showMessage(data.message);
            }
        });
    }

    saveAddress() {
        this.profileService.saveAddress(this.profileDocs.address).subscribe((data: any) => {
            if (data) {
                this.profileService.showMessage(data.message);
            }
        });
    }
}
