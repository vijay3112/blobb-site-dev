import { Component, OnInit } from "@angular/core";
import { Profile } from "../../../entities/Profile";
import { ProfileDocs } from "../../../entities/ProfileDocs";
import { NavService } from "../../../constants/nav.service";
import { ProfileService } from "../profile.service";

import { MatDialog } from "@angular/material";
import { Props } from "../../../constants/props";

// profile docs entities //
import { Address } from "../../../entities/Address";

@Component({
    selector: "app-profile-edit-page",
    templateUrl: "./profile-edit-page.component.html",
    styleUrls: ["./profile-edit-page.component.scss"],
})
export class ProfileEditPageComponent implements OnInit {
    id: String;
    profile: Profile = null;
    address: Address = null;
    profileDocs: ProfileDocs = null;
    private isDisabled: boolean = false;
    countryCodes: any = [];
    tabs = ["DETAILS", "ADDRESS", "PROFILE_DOCS", "FILE_UPLOAD"];
    currentTab: String = "DETAILS";

    constructor(private profileService: ProfileService) {
        this.profile = new Profile();
        this.profileDocs = new ProfileDocs();
        this.id = this.profileService.getParam("id");
        this.entityData(this.id);
        this.entityprofileDocs(this.id);
    }

    ngOnInit() {}

    entityData(id: any) {
        this.profileService.entityData(id).subscribe((data: any) => {
            if (data) {
                this.profile = data;
                let mobile: any = this.profile.mobile;
                this.profile.mobile = isNaN(mobile) ? "" : this.profile.mobile;
            }
        });
    }

    entityprofileDocs(id: any) {
        this.profileService.entityprofileDocs(id).subscribe((data: any) => {
            this.profileDocs = data;
            let mobile: any = this.profileDocs.profile.mobile;
            this.profileDocs.profile.mobile = isNaN(mobile) ? "" : this.profileDocs.profile.mobile;
        });
    }

    tabChange($event) {
        this.currentTab = $event.tab.textLabel;
    }

    // save() {
    //   if (this.currentTab === "DETAILS") {
    //     this.profileService
    //       .saveProfileData(this.profile)
    //       .subscribe((data: any) => {
    //         if (data) {
    //           console.log(data);
    //           this.profileService.showMessage(data.message);
    //         }
    //       });
    //   } else if (this.currentTab === "PROFILE_DOCS") {
    //     this.profileService
    //       .SaveprofileDocs(this.profileDocs)
    //       .subscribe((data: any) => {
    //         if (data) {
    //           console.log(data);
    //           this.profileService.showMessage(data.message);
    //         }
    //       });
    //   }
    // }

    imgChange($event: any) {
        this.profileService.getApp().dataEmit($event);
    }

    uploadFile($event: FormData) {
        this.profileService.fileUpload($event).subscribe((data: any) => {
            if (data) {
                this.profileService.showMessage(data.message);
            }
        });
    }

    saveProfile() {
        this.profileService.saveProfileData(this.profile).subscribe((data: any) => {
            if (data) {
                this.entityData(this.id);
                this.profileService.showMessage(data.message);
            }
        });
    }

    saveProfileDocs() {
        this.profileService.saveprofileDocs(this.profileDocs).subscribe((data: any) => {
            if (data) {
                this.entityprofileDocs(this.id);
                this.profileService.showMessage(data.message);
            }
        });
    }

    saveAddress() {
        this.profileService.saveProfileData(this.profileDocs.address).subscribe((data: any) => {
            if (data) {
                this.profileService.showMessage(data.message);
            }
        });
    }
}
