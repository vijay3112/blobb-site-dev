import { Component, OnInit } from "@angular/core";
import { LoadService } from "../../../constants/load.service";

@Component({
    selector: "app-orders-page",
    templateUrl: "./orders-page.component.html",
    styleUrls: ["./orders-page.component.scss"],
})
export class OrdersPageComponent implements OnInit {
    constructor(private loadService: LoadService) {}

    ngOnInit() {}
}
