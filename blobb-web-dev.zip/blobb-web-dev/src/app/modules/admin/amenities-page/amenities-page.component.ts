import { Component, OnInit, Output, EventEmitter, ViewChild } from "@angular/core";
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";
import { Amenities } from "../../../entities/Amenities";
import { AdminService } from "../admin.service";

@Component({
    selector: "app-amenities-page",
    templateUrl: "./amenities-page.component.html",
    styleUrls: ["./amenities-page.component.scss"],
})
export class AmenitiesPageComponent implements OnInit {
    showEdit: boolean = false;
    searchText: string;
    searchObj: Object = null;
    amenitiesList: any[];
    amenities: Amenities;

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();
    constructor(private service: AdminService) {
        this.amenities = new Amenities();
    }

    ngOnInit() {
        this.amenitiesDataList();
    }
    toggleEdit($event: any) {
        if ($event == "open") {
            this.showEdit = true;
        } else {
            this.showEdit = false;
            this.amenitiesDataList();
        }
    }

    close1(backdrop) {
        this.showEdit = false;
    }

    amenitiesDataList() {
        this.amenitiesList = null;
        let data: any = {};
        this.service.entityAmenities(data).subscribe((results: any[]) => {
            this.amenitiesList = results;
        });
    }
    saveAmenities(item) {
        this.amenities = item;
        this.amenities.active = !item.active;
        console.log(this.amenities);
        this.service.saveAmenitiesData(this.amenities).subscribe((data: any) => {
            if (!!data) {
                this.service.showMessage(data.message);
            }
        });
    }
}
