import { Component, OnInit, ViewChild, Output, EventEmitter } from "@angular/core";
import { NgForm } from "@angular/forms";
import { AdminService } from "../admin.service";
import { Amenities } from "../../../entities/Amenities";

@Component({
    selector: "app-amenities-add-page",
    templateUrl: "./amenities-add-page.component.html",
    styleUrls: ["./amenities-add-page.component.scss"],
})
export class AmenitiesAddPageComponent implements OnInit {
    @ViewChild(NgForm) myForm: NgForm;
    showEdit: boolean = false;
    imgId: string;
    id: string;
    amenities: Amenities = null;
    constructor(private service: AdminService) {
        this.amenities = new Amenities();
    }
    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    ngOnInit() {}
    onClose() {
        this.showEdit = false;
        this.myForm.form.reset();
        this.amenities.data = null;
        this.outputEvent.emit();
    }
    imgChange($event: any) {
        this.imgId = null;
        setTimeout(() => {
            this.imgId = this.id;
        }, 100);
        this.service.getApp().dataEmit($event);
    }

    save() {
        this.service.saveAmenitiesData(this.amenities).subscribe((data: any) => {
            if (data) {
                this.service.showMessage(data.message);
                this.onClose();
            }
        });
    }
}
