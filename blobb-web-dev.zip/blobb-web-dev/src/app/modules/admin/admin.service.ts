import { Injectable } from "@angular/core";
import { AppService } from "../../../app/shared/service/app.service";
import { HttpService } from "../../../app/shared/service/http.service";
import { LoadService } from "../../../app/constants/load.service";

@Injectable({
  providedIn: "root",
})
export class AdminService {
  private amenities_url = "/amenities";

  constructor(private http: HttpService, private appService: AppService, private loadService: LoadService) {}
  getApp(): AppService {
    return this.appService;
  }
  showMessage(message: string) {
    this.appService.showMessage(message);
  }
  entityData(id: any) {
    return this.http.get(this.amenities_url + "/" + id, {});
  }
  entityAmenities(data: any) {
    return this.http.get(this.amenities_url, { data: data });
  }
  saveAmenitiesData(data: any) {
    return this.http.put(this.amenities_url, { data: data });
  }
}
