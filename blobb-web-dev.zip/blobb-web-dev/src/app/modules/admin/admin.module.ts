import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { ComponentsModule } from "../../components/components.module";
import { Routes, RouterModule } from "@angular/router";
import { OrdersPageComponent } from "./orders-page/orders-page.component";
import { AmenitiesPageComponent } from "./amenities-page/amenities-page.component";
import { AmenitiesAddPageComponent } from "./amenities-add-page/amenities-add-page.component";

const routes: Routes = [{ path: "orders", component: OrdersPageComponent }, { path: "amenities", component: AmenitiesPageComponent }];

@NgModule({
    declarations: [OrdersPageComponent, AmenitiesPageComponent, AmenitiesAddPageComponent],
    imports: [CommonModule, SharedModule, ComponentsModule, RouterModule.forChild(routes)],
})
export class AdminModule {}
