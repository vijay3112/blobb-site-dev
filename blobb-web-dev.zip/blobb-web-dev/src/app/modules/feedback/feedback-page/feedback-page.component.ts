import { Component, OnInit, ViewChild } from "@angular/core";
import { RoomBook } from "../../../entities/RoomBook";
import { FeedbackService } from "../feedback.service";
import { Props } from "../../../constants/props";
import { Feedback } from "../../../entities/Feedback";
import { NgForm } from "@angular/forms";
interface ICompany {
    id: number;
    rating: number;
    contact: string;
    company: string;
}

@Component({
    selector: "app-feedback-page",
    templateUrl: "./feedback-page.component.html",
    styleUrls: ["./feedback-page.component.scss"],
})
export class FeedbackPageComponent implements OnInit {
    feedbackList: any = [];
    selectedTab: any = "active";
    showEdit: boolean = false;
    feedback: Feedback;
    @ViewChild(NgForm) myForm: NgForm;
    ratingTabs: any[] = [
        { name: "All", value: "all" },
        { name: "Active", value: "active" },
        { name: "De-Active", value: "de-active" },
        { name: 1, value: 1 },
        { name: 2, value: 2 },
        { name: 3, value: 3 },
        { name: 4, value: 4 },
        { name: 5, value: 5 },
    ];

    constructor(private feedbackService: FeedbackService) {
        this.getFeedback(this.selectedTab);
    }

    ngOnInit() {}

    getFeedback(data: any) {
        data = { param: data };
        this.feedbackService.getFeedback(data).subscribe((data: any) => {
            this.feedbackList = data;
        });
    }

    onChangeBookingType(item: any) {
        this.selectedTab = item.value;
        this.getFeedback(this.selectedTab);
    }

    toggleEdit($event: any) {
        if ($event == "open") {
            this.showEdit = true;
        } else {
            this.showEdit = false;
            // this.search();
        }
    }
    edit(item) {
        if (item) {
            this.feedback = item;
            this.entityData(item.id);
            this.showEdit = true;
        } else {
            this.showEdit = true;
            this.feedback = new Feedback();
        }
    }

    close1(backdrop) {
        this.showEdit = false;
        // this.myForm.form.reset();
    }
    save() {
        this.feedbackService.save(this.feedback).subscribe((data: any) => {
            if (data) {
                this.getFeedback(this.selectedTab);
                this.feedbackService.showMessage(data.message);
                this.close1(true);
            }
        });
    }
    entityData(id: any) {
        this.feedbackService.entityData(id).subscribe((data: any) => {
            if (data) {
                this.feedback = data;
            }
        });
    }
}
