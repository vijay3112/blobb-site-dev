import { Injectable } from "@angular/core";
import { HttpService } from "../../shared/service/http.service";
import { AppService } from "../../shared/service/app.service";
import { NavService } from "../../constants/nav.service";
import { MENU } from "../../constants/menu";

@Injectable({
    providedIn: "root",
})
export class FeedbackService {
    private feedback_url = "/feedback";

    constructor(private http: HttpService, private navService: NavService, private appService: AppService) {}

    getNav(): NavService {
        return this.navService;
    }

    save(data: any) {
        return this.http.put(this.feedback_url, { data: data }, true);
    }
    bookingEdit(params: any) {
        this.appService.navigate(MENU.BOOKING_EDIT.link, params);
    }
    getFeedback(filter: any) {
        return this.http.get(this.feedback_url, { data: filter });
    }
    showMessage(message: string) {
        this.appService.showMessage(message);
    }
    entityData(id: any) {
        return this.http.get(this.feedback_url + "/" + id, {});
      }
}
