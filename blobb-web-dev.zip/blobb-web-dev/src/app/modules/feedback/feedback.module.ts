import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FeedbackPageComponent} from './feedback-page/feedback-page.component';
import {Routes, RouterModule} from '@angular/router';
import {SharedModule} from '../../shared/shared.module';
import {ComponentsModule} from '../../components/components.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FeedbackService} from './feedback.service';

const routes: Routes = [
  {path: 'feedback', component: FeedbackPageComponent},
  ];

@NgModule({
  declarations: [FeedbackPageComponent],
  imports: [    CommonModule,
    SharedModule,
    ComponentsModule,
    RouterModule.forChild(routes)],
  providers: [FeedbackService],
})
export class FeedbackModule {
}
