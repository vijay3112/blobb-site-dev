import { Component, OnInit } from "@angular/core";
import { AccessService } from "../access.service";
import { LoadService } from "../../../constants/load.service";
import { AccessMenu } from "../../../entities/AccessMenu";
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { Props } from "../../../constants/props";
@Component({
  selector: "app-access-menu-page",
  templateUrl: "./access-menu-page.component.html",
  styleUrls: ["./access-menu-page.component.scss"]
})
export class AccessMenuPageComponent implements OnInit {
  roles: any = [];
  dataList: AccessMenu[] = null;
  constructor(
    private service: AccessService,
    private loadService: LoadService
  ) {
    this.getRoles();
  }

  ngOnInit() {}
  getRoles() {
    this.loadService.roles().subscribe((data: any) => {
      this.roles = data;
    });
  }
  tabChange($event) {
    this.dataList = null;
    this.service.getAccessMenu($event.tab.textLabel).subscribe((data: any) => {
      setTimeout(() => {
        this.dataList = data;
      }, Props.TIME_OUT);
    });
  }
  save() {
    this.service.saveAccessMenu(this.dataList).subscribe((data: any) => {
      this.service.showMessage(data.message);
    });
  }
  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.dataList, event.previousIndex, event.currentIndex);
    for (let i = 0; i < this.dataList.length; i++) {
      this.dataList[i].priority = i + 1;
    }
  }
}
