import { Injectable } from "@angular/core";
import { HttpService } from "../../shared/service/http.service";
import { AppService } from "../../shared/service/app.service";
import { NavService } from "../../constants/nav.service";
import { Props } from "../../constants/props";

@Injectable({
  providedIn: "root"
})
export class AccessService {
  props: Props = Props;
  private auth_url: string = "/auth";
  private access_menu_url = "/accessmenu";
  private app_data_url = "/appdata";
  constructor(
    private http: HttpService,
    private appService: AppService,
    private navService: NavService
  ) {}

  getNav(): NavService {
    return this.navService;
  }

  getApp(): AppService {
    return this.appService;
  }

  showMessage(message: string) {
    this.appService.showMessage(message);
  }

  getParam(key: string): String {
    return this.navService.param(key);
  }

  getAccessMenu(code: String) {
    return this.http.get(this.access_menu_url, { data: { role: code } }, false);
  }
  saveAccessMenu(data: any) {
    return this.http.put(this.access_menu_url, { data: data }, true);
  }
  getAppData(code: String) {
    return this.http.get(this.app_data_url, { data: { code: code } }, false);
  }
  saveAppData(data: any) {
    return this.http.put(this.app_data_url, { data: data }, true);
  }
}
