import { NgModule } from "@angular/core";

import { CommonModule } from "@angular/common";
import { SharedModule } from "../../shared/shared.module";
import { Routes, RouterModule } from "@angular/router";
import { ComponentsModule } from "../../components/components.module";
import { AppDataPageComponent } from "./app-data-page/app-data-page.component";
import { AccessMenuPageComponent } from "./access-menu-page/access-menu-page.component";
import { AccessService } from "./access.service";
const routes: Routes = [{ path: "app_data", component: AppDataPageComponent }, { path: "access_menu", component: AccessMenuPageComponent }];

@NgModule({
    imports: [CommonModule, SharedModule, ComponentsModule, RouterModule.forChild(routes)],
    declarations: [AppDataPageComponent, AccessMenuPageComponent],
    providers: [AccessService],
})
export class AccessModule {}
