import { Component, OnInit } from "@angular/core";
import { AppData } from "../../../entities/AppData";
import { AccessService } from "../access.service";
import { LoadService } from "../../../constants/load.service";
import { Props } from "../../../constants/props";

@Component({
  selector: "app-app-data-page",
  templateUrl: "./app-data-page.component.html",
  styleUrls: ["./app-data-page.component.scss"]
})
export class AppDataPageComponent implements OnInit {
  codes: any = [];
  dataList: AppData[] = null;
  selectedTab: string = "";
  appData: AppData = new AppData();

  constructor(
    private service: AccessService,
    private loadService: LoadService
  ) {
    this.getCodes();
  }

  ngOnInit() {}

  getCodes() {
    this.loadService.codes().subscribe((data: any) => {
      this.codes = data;
    });
  }
  tabChange($event) {
    this.dataList = null;
    this.service.getAppData($event.tab.textLabel).subscribe((data: any) => {
      setTimeout(() => {
        this.dataList = data;
      }, Props.TIME_OUT);
    });
    this.selectedTab = $event.tab.textLabel;
  }
  add() {
    this.appData = new AppData();
    this.appData.code = this.selectedTab;
    this.dataList.push(this.appData);
    // console.log(this.data);
  }
  save($event) {
    this.service.saveAppData($event).subscribe((data: any) => {
      this.service.showMessage(data.message);
    });
  }
}
