import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { Expenses } from "../../entities/Expenses";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
    selector: "app-expenses",
    templateUrl: "./expenses.component.html",
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class ExpensesComponent implements OnInit, OnChanges {
    Props: Props = Props;

    maxDate = new Date();

    @Input()
    expenses: Expenses = null;

    @Input()
    type: string = "view";

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    typeList: any[] = [];
    branchesList: any[] = [];

    constructor(private loadService: LoadService) {
        this.expenses = new Expenses();
    }

    ngOnInit() {
        this.loadType();
        this.loadProperties();
    }

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["expenses"];
        if (changes["type"]) {
            this.type = changes["type"].currentValue;
        }
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            // TO-DO
            this.expenses = changeValue.currentValue;
            console.log(this.expenses);
        } else {
            this.expenses = new Expenses();
        }
    }

    private loadType() {
        this.loadService.expensesTypes().subscribe((results: any[]) => {
            if (results) {
                this.typeList = results;
            } else {
                this.typeList = [];
            }
        });
    }
    private loadProperties() {
        this.loadService.propertyAll().subscribe((results: any[]) => {
            if (results) {
                this.branchesList = results;
            } else {
                this.branchesList = [];
            }
        });
    }
}
