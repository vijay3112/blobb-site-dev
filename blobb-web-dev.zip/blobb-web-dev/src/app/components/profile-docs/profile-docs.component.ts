import { Component, OnInit,Input } from '@angular/core';
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { ProfileDocs } from "../../entities/ProfileDocs";
export interface gender {
  value: string;
  Value: string;
}

@Component({
  selector: 'app-profile-docs',
  templateUrl: './profile-docs.component.html',
  styleUrls: ['./profile-docs.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class ProfileDocsComponent implements OnInit {
  Props: any = Props;
  gender: gender[] = [
    { value: "Male", Value: "Male" },
    { value: "Female", Value: "Female" },
    { value: "Neutral", Value: "Neutral" }
  ];

  @Input()
  profileDocs: ProfileDocs;
  @Input()
  type: string;
  @Input()
  layout: string;
  startDate = new Date(1950, 0, 1);
  constructor() {
    this.profileDocs = new ProfileDocs();
   }

  ngOnInit() {
  }

}
