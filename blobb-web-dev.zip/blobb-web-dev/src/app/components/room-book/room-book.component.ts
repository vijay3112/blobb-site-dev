import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";
import { RoomBook } from "../../entities/RoomBook";
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { Util } from "../../shared/utils/util";
import { PaymentAddon } from "../../entities/PaymentAddon";

@Component({
    selector: "app-room-book",
    templateUrl: "./room-book.component.html",
    // viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RoomBookComponent implements OnInit, OnChanges {
    Props: Props = Props;
    propertiesForm: FormGroup;
    bookTypesForm: FormGroup;
    bookTypes: any;
    propertyList: any[] = [];
    nextDay: any;
    minDate: Date;
    @Input()
    roomBook: RoomBook = null;

    @Input()
    paymentAddon: PaymentAddon;

    @Input()
    type: string;

    @Input()
    status: string;

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    @Output()
    outputPeriodOnChange: EventEmitter<any> = new EventEmitter<any>();

    @Output()
    outputBookTypeOnChange: EventEmitter<any> = new EventEmitter<any>();

    exportTime: any = { format: 24 };

    constructor(private loadService: LoadService) {
        this.minDate = Util.CurrentDate();
        this.exportTime.hour = new Date().getHours();
        this.exportTime.minute = new Date().getMinutes();
    }

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["roomBook"];
        if (changeValue && changeValue.currentValue && changeValue.previousValue != changeValue.currentValue) {
            //this.roomBook = changeValue.currentValue;
            if (this.type == "booking_edit") {
                this.loadProperties();
                this.loadRoomTypes();
            }
        }
    }
    loadProperties() {
        this.roomBook.bookType = "BOOKING";
        this.loadService.property().subscribe((data: any) => {
            if (!!data) {
                this.propertyList = data;
                this.roomBook.room.property.id = data[0].val;
            } else {
                this.propertyList = [];
            }
        });
    }
    loadRoomTypes() {
        this.loadService.roomTypes().subscribe((data) => {
            if (data) {
                this.bookTypes = data;
            } else {
                this.bookTypes = [];
            }
            this.onChangeFilter(null);
        });
    }

    onChangeHour(event) {
        console.log("event", event);
        setTimeout(() => {
            if (event && !isNaN(event.hour)) {
                this.exportTime = event;
                this.onChangeFilter(null);
            }
        });
    }

    onChangeFilter(event: any) {
        setTimeout(() => {
            this.roomBook.fromDate.setHours(this.exportTime.hour);
            this.roomBook.fromDate.setMinutes(this.exportTime.minute);
            this.roomBook.fromDate.setSeconds(0);
            this.roomBook.toDate.setHours(this.exportTime.hour);
            this.roomBook.toDate.setMinutes(this.exportTime.minute);
            this.roomBook.toDate.setSeconds(0);
            if (Util.DaysDiff(this.roomBook.fromDate, this.roomBook.toDate) > 0) {
                this.outputPeriodOnChange.emit(this.roomBook);
            } else {
                this.loadService.getApp().showMessage("To Date should be greater then From Date!");
            }
        }, 100);
    }
}
