import { Component, OnInit, Input } from "@angular/core";
import { Props } from "../../constants/props";
import { Auth } from "../..//entities/Auth";
import { LoadService } from "../../constants/load.service";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
  selector: "app-auth",
  templateUrl: "./auth.component.html",
  styleUrls: ["./auth.component.scss"],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class AuthComponent implements OnInit {
  Props: Props = Props;
  hide: boolean = true;
  mobileErrMsg: string = "Mobile number required";
  emailErrMsg: string = "Email required";
  @Input()
  auth: Auth;

  @Input()
  type: string;

  constructor(private loadService: LoadService) {}

  ngOnInit() {}
}
