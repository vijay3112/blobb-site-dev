import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { ImagesMap } from '../../entities/ImagesMap';

@Component({
    selector: 'app-images_map',
    templateUrl: './images-map.component.html',
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class ImagesMapComponent implements OnInit, OnChanges{
    Props: Props = Props;
    @Input()
    imagesMap: ImagesMap = null;

    @Input()
    type: string = 'view';

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    

    constructor(private loadService: LoadService) {
        this.imagesMap = new ImagesMap();
    }

    ngOnInit() {
       
    }

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["imagesMap"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
          // TO-DO
        }
    }

    

}
