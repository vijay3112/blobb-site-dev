import { Component, OnInit, Input } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { Address } from "../../entities/Address";

@Component({
  selector: "app-address",
  templateUrl: "./address.component.html",
  styleUrls: ["./address.component.scss"],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class AddressComponent implements OnInit {
  Props: any = Props;
  @Input()
  address: Address = null;
  @Input()
  type: string;
  // email = new FormControl('', [Validators.required, Validators.email]);

  // getErrorMessage() {
  //   return this.email.hasError('required') ? 'You must enter a value' :
  //     this.email.hasError('email') ? 'Not a valid email' :
  //       '';
  // }

  constructor() { }


  ngOnInit() { }
}
