import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Img } from "../../../entities/Img";
import { Props } from "../../../constants/props";
import { Storage } from "../../../shared/utils/storage";
import { ImgSrc } from "../../../entities/ImgSrc";

@Component({
    selector: "app-image",
    templateUrl: "./image.component.html",
    styleUrls: ["./image.component.scss"],
})
export class ImageComponent implements OnInit {
    @Input()
    img: Img;

    imgSrc: any = {};

    @Input()
    isReadOnly: boolean = false;

    @Output()
    outputEmitter: EventEmitter<any> = new EventEmitter<any>();

    constructor() {}

    ngOnInit() {}

    selectedImg($event: string) {
        this.imgSrc = Object.assign({}, this.img);
        this.imgSrc.src = $event;
        this.imgload(JSON.stringify({ data: this.imgSrc }));
    }
    imgload(data) {
        let url = Props.API_END_POINT + "/img?" + new Date().toISOString();

        return new Promise((resolve, reject) => {
            var xhr = new XMLHttpRequest();
            xhr.open("PUT", url);
            xhr.setRequestHeader("Authorization", Storage.getJWT());
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = () => {
                if (xhr.readyState == 0 || xhr.readyState == 4) {
                    var data = xhr.response;
                    //resolve(data);
                    //   if (data.status == 1) {
                    //     resolve(data.data);
                    //   } else {
                    //     this.errorMessage(data.error);
                    //     reject(data);
                    //   }
                    delete data.src;
                    this.outputEmitter.emit(this.img);
                }
            };
            xhr.send(data);
        });
    }
}
