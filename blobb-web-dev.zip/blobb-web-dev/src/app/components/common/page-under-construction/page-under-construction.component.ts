import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-puc",
  templateUrl: "./page-under-construction.component.html",
  styleUrls: ["./page-under-construction.component.scss"]
})
export class PageUnderConstructionComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
