import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  SimpleChanges,
  SimpleChange
} from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import { Props } from "../../../constants/props";
import { MatDialog } from "@angular/material";

@Component({
  selector: "app-file",
  templateUrl: "./file.component.html",
  styleUrls: ["./file.component.scss"]
})
export class FileComponent implements OnInit {
  file: File;
  @Output()
  outputEmitter: EventEmitter<any> = new EventEmitter<any>();

  fileName: string;

  @Input()
  fileId: string;
  fileUrl: string;

  dataFile = "";
  @Input()
  type: string;

  constructor(public sanitizer: DomSanitizer, private dialog: MatDialog) {
    this.fileUrl = Props.API_END_POINT + "/filedata/";
  }

  ngOnInit() {}
  openInput() {
    // your can use ElementRef for this later
    document.getElementById("fileInput").click();
  }

  fileChange(files: File[]) {
    if (files) {
      this.file = files[0];
      this.fileName = files[0].name;
      this.upload(this.file);
    }
  }
  upload($event) {
    let _formData: FormData = new FormData();
    _formData.append("file", $event);
    _formData.append("id", this.fileId);
    this.outputEmitter.emit(_formData);
  }
  ngOnChanges(changes: SimpleChanges) {
    let changeFileUrl: SimpleChange = changes["fileId"];
    if (
      changeFileUrl &&
      changeFileUrl.previousValue != changeFileUrl.currentValue
    ) {
      this.dataFile = null;
      setTimeout(() => {
        if (this.type == "view") {
          this.dataFile = this.fileUrl + this.fileId;
        }
      }, 10);
    }
  }
  viewFile(template) {
    // this.fileId += "&datetime=" + new Date().toISOString();
    setTimeout(() => {
      this.dialog.open(template);
    }, 10);
    //this.getFile(this.profileDocs.id);
  }
}

// <iframe
//       [src]="sanitizer.bypassSecurityTrustResourceUrl(fileUrl)"
// height = "89vh"
// width = "100%"
//   > </iframe>

// <object
//       [data]="sanitizer.bypassSecurityTrustResourceUrl(fileUrl)"
// style = "width:100%;height:70vh"
//   >
//   <embed
//         [src]="sanitizer.bypassSecurityTrustResourceUrl(fileUrl)"
// style = "width:80vh;height:70vh"
//   />
//   </object>

// <img
//       [src]="sanitizer.bypassSecurityTrustResourceUrl(fileUrl)"
// width = "100%"
//   />

// <iframe [src]="sanitizer.bypassSecurityTrustResourceUrl(fileUrl)" style = "width: 100%;height: 100%;border: none;" > </iframe>
