import { ChangeDetectorRef, Component, OnDestroy, Input, Output, EventEmitter, HostListener } from "@angular/core";
import { MediaMatcher } from "@angular/cdk/layout";
import { Props } from "../../../constants/props";
import { Storage } from "../../../shared/utils/storage";
import { trigger, animate, style, group, query, transition } from "@angular/animations";
import { MatDialog } from "@angular/material";
// import { ChangepasswordComponent } from "../../auth/changepassword/changepassword.component";
import { AppService } from "../../../shared/service/app.service";
import { NavService } from "../../../constants/nav.service";
import { ApexService } from "../../../shared/service/apex.service";

const routerTransition = trigger("routerTransition", [
    transition("* <=> *", [
        query(":enter, :leave", style({ position: "fixed", width: "100%", height: "100%" }), {
            optional: true,
        }),
        group([
            query(":enter", [style({ transform: "translateX(100%)" }), animate("0.5s ease-in-out", style({ transform: "translateX(0%)" }))], { optional: true }),
            query(":leave", [style({ transform: "translateX(0%)" }), animate("0.5s ease-in-out", style({ transform: "translateX(-100%)" }))], { optional: true }),
        ]),
    ]),
]);

@Component({
    selector: "app-nav",
    templateUrl: "./nav.component.html",
    styleUrls: ["./nav.component.scss"],
    animations: [routerTransition],
})
export class NavComponent implements OnDestroy {
    mobileQuery: MediaQueryList;

    fillerNav = Array.from({ length: 50 }, (_, i) => `Nav Item ${i + 1}`);

    private _mobileQueryListener: () => void;

    private service: NavService;

    role: any;

    constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher, private dialog: MatDialog, private apexService: ApexService) {
        this.mobileQuery = media.matchMedia("(max-width: 600px)");
        this._mobileQueryListener = () => changeDetectorRef.detectChanges();
        this.mobileQuery.addListener(this._mobileQueryListener);

        this.acitveLink = Storage.getActiveLink();
        this.acitveLink = this.acitveLink ? this.acitveLink : "0";

        // this.role = Storage.getSessionUser().role;
        // console.log(this.role);

        this.apexService.dataEvent().subscribe(($event) => {
            if (this.sessionUser) {
                let id = this.sessionUser.id;
                this.sessionUser.id = 0;
                setTimeout(() => {
                    this.sessionUser.id = id;
                }, 10);
            }
        });
        this.apexService.getActiveURL().subscribe((data) => {
            console.log(data);
            this.getActiveLink(data);
        });
    }

    ngOnDestroy(): void {
        this.mobileQuery.removeListener(this._mobileQueryListener);
    }

    @Input()
    title: string;
    @Input()
    menuList: any[];
    @Input()
    sessionUser: any;
    @Output()
    outputEvent = new EventEmitter();
    acitveLink: string;

    redirect(link: any) {
        if (link == "welcome") {
            Storage.sessionClear();
            this.outputEvent.emit(null);
        } else if (typeof link == "string" && link.indexOf("/") > 0) {
            this.outputEvent.emit(link);
        } else {
            this.acitveLink = link.id;
            Storage.setActiveLink(this.acitveLink);
            this.outputEvent.emit(Props.MENU[link.menu.toUpperCase()].link);
        }
    }

    getActiveLink(activeUrl: string) {
        var url = activeUrl;
        console.log(this.menuList);
        if (this.menuList != null) {
            this.menuList.filter((data) => {
                if (url == Props.MENU[data.menu.toUpperCase()].link) {
                    console.log(data);
                    this.acitveLink = data.id;
                    Storage.setActiveLink(this.acitveLink);
                }
            });
        }
    }

    // logo() {
    //   if (this.role == "ADMIN" || this.role == "STAFF") {
    //     this.service.dashBoard(null);
    //   } else {
    //     this.service.home(null);
    //   }
    // }

    // @HostListener("window:scroll", [])
    // scrolling() {
    //   console.log("scrolling");
    // }
    // openDialog(): void {
    //   const dialogRef = this.dialog.open(ChangepasswordComponent, {
    //     width: "50%",
    //     height: "auto"
    //   });

    //   dialogRef.afterClosed().subscribe((result) => {
    //     console.log("The dialog was closed");
    //   });
    // }
    onLogo() {
        let role: string = Storage.getSessionUser() ? Storage.getSessionUser().role : null;
        if (role) {
            if (role == "USER") {
                this.outputEvent.emit("dashboard/home");
            } else {
                this.outputEvent.emit("dashboard/dashboard");
            }
        }
    }
}
