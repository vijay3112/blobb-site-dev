import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "../shared/shared.module";
import { PageUnderConstructionComponent } from "./common/page-under-construction/page-under-construction.component";
import { LogoComponent } from "./common/logo/logo.component";
import { WelcomeBannerComponent } from "./welcome/welcome-banner/welcome-banner.component";
import { WelcomeTitleComponent } from "./welcome/welcome-title/welcome-title.component";
import { WelcomeMapComponent } from "./welcome/welcome-map/welcome-map.component";
import { WelcomeContactComponent } from "./welcome/welcome-contact/welcome-contact.component";
import { AuthComponent } from "./auth/auth.component";
import { AppDataComponent } from "./app-data/app-data.component";
import { AccessMenuComponent } from "./access-menu/access-menu.component";
import { ProfileComponent } from "./profile/profile.component";
import { ProfileDocsComponent } from "./profile-docs/profile-docs.component";
import { AddressComponent } from "./address/address.component";
import { ImageComponent } from "./common/image/image.component";
import { FileComponent } from "./common/file/file.component";
import { AmenitiesComponent } from "./amenities/amenities.component";
import { PropertyComponent } from "./property/property.component";
import { FlatComponent } from "./flat/flat.component";
import { RoomComponent } from "./room/room.component";
import { WebMetadataComponent } from "./web-metadata/web-metadata.component";

import { OrdersComponent } from "./orders/orders.component";
import { PropertyAmenitiesComponent } from "./property-amenities/property-amenities.component";
import { RoomBookComponent } from "./room-book/room-book.component";
import { FeedbackComponent } from "./feedback/feedback.component";
import { ExpensesComponent } from "./expenses/expenses.component";
import { StarRatingComponent } from "./star-rating/star-rating.component";
import { PaymentComponent } from "./payment/payment.component";
import { PaymentTaxComponent } from "./payment-tax/payment-tax.component";
import { PaymentAddonComponent } from "./payment-addon/payment-addon.component";
import { RoomPersonsComponent } from "./room-persons/room-persons.component";
import { RoomOrdersComponent } from "./room-orders/room-orders.component";
import { RoomBookTrackComponent } from "./room-book-track/room-book-track.component";
import { ImagesMapComponent } from "./images-map/images-map.component";
import { CorporateBookingComponent } from "./corporate-booking/corporate-booking.component";
import { SubscribeComponent } from "./subscribe/subscribe.component";
import { ContactComponent } from "./contact/contact.component";

@NgModule({
    imports: [CommonModule, SharedModule.forRoot()],
    declarations: [
        PageUnderConstructionComponent,
        LogoComponent,
        WelcomeBannerComponent,
        WelcomeTitleComponent,
        WelcomeMapComponent,
        WelcomeContactComponent,
        AuthComponent,
        AppDataComponent,
        AccessMenuComponent,
        ProfileComponent,
        ProfileDocsComponent,
        AddressComponent,
        ImageComponent,
        FileComponent,
        AmenitiesComponent,
        PropertyComponent,
        FlatComponent,
        RoomComponent,
        WebMetadataComponent,
        PropertyAmenitiesComponent,
        OrdersComponent,
        RoomBookComponent,
        FeedbackComponent,
        ExpensesComponent,
        StarRatingComponent,
        PaymentComponent,
        PaymentAddonComponent,
        PaymentTaxComponent,
        RoomPersonsComponent,
        RoomOrdersComponent,
        RoomBookTrackComponent,
        ImagesMapComponent,
        CorporateBookingComponent,
        SubscribeComponent,
        ContactComponent,
    ],
    exports: [
        PageUnderConstructionComponent,
        LogoComponent,
        WelcomeBannerComponent,
        WelcomeTitleComponent,
        WelcomeMapComponent,
        WelcomeContactComponent,
        AuthComponent,
        AppDataComponent,
        AccessMenuComponent,
        ProfileComponent,
        ProfileDocsComponent,
        AddressComponent,
        ImageComponent,
        FileComponent,
        AmenitiesComponent,
        PropertyComponent,
        FlatComponent,
        RoomComponent,
        WebMetadataComponent,
        PropertyAmenitiesComponent,
        OrdersComponent,
        RoomBookComponent,
        FeedbackComponent,
        ExpensesComponent,
        StarRatingComponent,
        PaymentComponent,
        PaymentAddonComponent,
        PaymentTaxComponent,
        RoomPersonsComponent,
        RoomOrdersComponent,
        RoomBookTrackComponent,
        CorporateBookingComponent,
        SubscribeComponent,
        ContactComponent,
    ],
})
export class ComponentsModule {}
