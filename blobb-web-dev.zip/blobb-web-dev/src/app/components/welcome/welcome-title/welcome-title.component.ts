import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-title',
  templateUrl: './welcome-title.component.html',
  styleUrls: ['./welcome-title.component.scss']
})
export class WelcomeTitleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
