import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-map',
  templateUrl: './welcome-map.component.html',
  styleUrls: ['./welcome-map.component.scss']
})
export class WelcomeMapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
