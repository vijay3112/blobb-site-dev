import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-contact',
  templateUrl: './welcome-contact.component.html',
  styleUrls: ['./welcome-contact.component.scss']
})
export class WelcomeContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
