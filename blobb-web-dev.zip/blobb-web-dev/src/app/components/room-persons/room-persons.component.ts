import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { RoomPersons } from "../../entities/RoomPersons";

@Component({
    selector: "app-room-persons",
    templateUrl: "./room-persons.component.html",
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RoomPersonsComponent implements OnInit, OnChanges {
    Props: Props = Props;
    @Input()
    roomPersons: RoomPersons = new RoomPersons();

    @Input()
    type: string = "view";

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private loadService: LoadService) {}

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["roomPersons"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            console.log(this.roomPersons);
        }
    }
    delete($event) {
        this.outputEvent.emit($event);
    }
}
