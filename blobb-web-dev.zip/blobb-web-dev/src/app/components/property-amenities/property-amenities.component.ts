import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { PropertyAmenities } from "../../entities/PropertyAmenities";

@Component({
  selector: "app-property-amenities",
  templateUrl: "./property-amenities.component.html",
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class PropertyAmenitiesComponent implements OnInit, OnChanges {
  Props: Props = Props;
  // amenities = [];
  status: boolean = false;
  selectedPropertyAmenity: PropertyAmenities;
  @Input()
  propertyAmenitiesList: PropertyAmenities[] = null;

  @Input()
  type: string = "view";

  @Output()
  outputEvent: EventEmitter<any> = new EventEmitter<any>();

  constructor(private loadService: LoadService) {
    this.selectedPropertyAmenity = new PropertyAmenities();
  }

  ngOnInit() {}

  selectedItem(item: PropertyAmenities) {
    this.outputEvent.emit(item);
  }

  ngOnChanges(changes: SimpleChanges) {
    const changeValue: SimpleChange = changes["propertyAmenities"];
    if (changeValue && changeValue.previousValue != changeValue.currentValue) {
      // TO-DO
    }
  }
}
