import { Component, OnInit, Input } from "@angular/core";
import { AccessMenu } from "../../entities/AccessMenu";

@Component({
  selector: "app-access-menu",
  templateUrl: "./access-menu.component.html",
  styleUrls: ["./access-menu.component.scss"]
})
export class AccessMenuComponent implements OnInit {
  @Input()
  accessMenu: AccessMenu;
  constructor() {}

  ngOnInit() {}
}
