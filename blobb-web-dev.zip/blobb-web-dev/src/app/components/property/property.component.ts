import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";
import { Property } from "../../entities/Property";

@Component({
  selector: "app-property",
  templateUrl: "./property.component.html",
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class PropertyComponent implements OnInit, OnChanges {
  Props: Props = Props;
  @Input()
  property: Property = null;

  @Input()
  type: string = "view";

  @Output()
  outputEvent: EventEmitter<any> = new EventEmitter<any>();

  supervisorList: any[] = [];
  
  @Input()
  isReadOnly: boolean = false;

  constructor(private loadService: LoadService) {
    this.property = new Property();
  }

  ngOnInit() {
    this.loadSupervisor();
  }

  ngOnChanges(changes: SimpleChanges) {
    const changeValue: SimpleChange = changes["property"];
    if (changeValue && changeValue.previousValue != changeValue.currentValue) {
      // TO-DO
    }
  }
  onCodeChange(){
    if(this.isReadOnly == true){
      this.loadService.getApp().showMessage("Property Code cannot be edited!");
    }
  }
  private loadSupervisor() {
    this.loadService.supervisors().subscribe((data: any[]) => {
      if (data) {
        console.log(data)
        this.supervisorList = data;
      } else {
        this.supervisorList = [];
      }
    });
  }
}
