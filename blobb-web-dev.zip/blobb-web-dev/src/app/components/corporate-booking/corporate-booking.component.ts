import { Component, OnInit, Input, ViewChild } from "@angular/core";
import { Props } from "../../constants/props";
import { CorporateBooking } from "../../entities/CorporateBooking";
import { LoadService } from "../../constants/load.service";
import { NgForm, ControlContainer } from "@angular/forms";

@Component({
    selector: "app-corporate-booking",
    templateUrl: "./corporate-booking.component.html",
    styleUrls: ["./corporate-booking.component.scss"],
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class CorporateBookingComponent implements OnInit {
    Props: any = Props;

    @Input()
    corporateBooking: CorporateBooking = null;
    @Input()
    type: string;

    constructor(private loadService: LoadService) {
        this.corporateBooking = new CorporateBooking();
    }

    ngOnInit() {}
}
