import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { PaymentTax } from "../../entities/PaymentTax";

@Component({
    selector: "app-payment-tax",
    templateUrl: "./payment-tax.component.html",
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class PaymentTaxComponent implements OnInit, OnChanges {
    Props: Props = Props;
    @Input()
    paymentTax: PaymentTax = null;

    @Input()
    type: string = "view";

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private loadService: LoadService) {
        this.paymentTax = new PaymentTax();
    }

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["paymentTax"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            // TO-DO
        }
    }
}
