import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { RoomOrders } from "../../entities/RoomOrders";
import { Payment } from "../../entities/Payment";

@Component({
    selector: "app-room-orders",
    templateUrl: "./room-orders.component.html",
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RoomOrdersComponent implements OnInit, OnChanges {
    Props: Props = Props;
    @Input()
    roomOrders: RoomOrders;

    @Input()
    type: string = "view";
    @Input()
    ordersData: any = [];

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private loadService: LoadService) {}

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["roomOrders"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            // TO-DO
            //if(!this.roomOrders.payment ){
            // this.roomOrders.payment = new Payment();
            // this.roomOrders.payment.cost = this.roomOrders.paymentTax.cost;
            // this.roomOrders.payment.cgst = this.roomOrders.paymentTax.cgst;
            // this.roomOrders.payment.sgst = this.roomOrders.paymentTax.sgst;
            // this.roomOrders.payment.igst = this.roomOrders.paymentTax.igst;
            //           this.roomOrders.payment.price = this.roomOrders.payment.cost * this.roomOrders.payment.units;
            // this.roomOrders.payment.cgstPrice = (this.roomOrders.payment.price * this.roomOrders.payment.cgst)/100;
            // this.roomOrders.payment.sgstPrice = (this.roomOrders.payment.price * this.roomOrders.payment.sgst)/100;
            // this.roomOrders.payment.igstPrice = (this.roomOrders.payment.price * this.roomOrders.payment.igst)/100;
            // if(this.roomOrders.payment.isIgst){
            //     this.roomOrders.payment.amount = this.roomOrders.payment.price +  this.roomOrders.payment.igstPrice
            // }else{
            //     this.roomOrders.payment.amount = this.roomOrders.payment.price +  this.roomOrders.payment.sgstPrice + this.roomOrders.payment.cgstPrice
            // }
            // }
        }
        //console.log(this.ordersData)
    }
    // getOrders(){
    //     this.loadService
    // }

    // checkList(){
    //     this.selectedOrders = [];
    //     this.roomOrdersData.forEach(element => {
    //         if(element.status == true){
    //             this.selectedOrders.push(element)
    //         }
    //     });
    //     console.log(this.selectedOrders)
    // }
    callRate($event: any) {
        this.roomOrders.payment.units = $event == "+" ? this.roomOrders.payment.units + 1 : this.roomOrders.payment.units - 1;

        // this.roomOrders.payment.cost = this.roomOrders.paymentTax.cost;
        // this.roomOrders.payment.cgst = this.roomOrders.paymentTax.cgst;
        // this.roomOrders.payment.sgst = this.roomOrders.paymentTax.sgst;
        // this.roomOrders.payment.igst = this.roomOrders.paymentTax.igst;
        // this.roomOrders.payment.price = this.roomOrders.payment.cost * this.roomOrders.payment.units;
        // this.roomOrders.payment.cgstPrice = (this.roomOrders.payment.price * this.roomOrders.payment.cgst)/100;
        // this.roomOrders.payment.sgstPrice = (this.roomOrders.payment.price * this.roomOrders.payment.sgst)/100;
        // this.roomOrders.payment.igstPrice = (this.roomOrders.payment.price * this.roomOrders.payment.igst)/100;
        // if(this.roomOrders.payment.isIgst){
        //     this.roomOrders.payment.amount = this.roomOrders.payment.price +  this.roomOrders.payment.igstPrice
        // }else{
        //     this.roomOrders.payment.amount = this.roomOrders.payment.price +  this.roomOrders.payment.sgstPrice + this.roomOrders.payment.cgstPrice
        // }

        console.log(this.roomOrders.payment);
    }
}

// id: string;
// type: string;
// cost: number;
// units: number = 1;
// price: number;
// cgst: number;
// sgst: number;
// igst: number;
// discount: number;
// cgstPrice: number;
// sgstPrice: number;
// igstPrice: number;
// discountPrice: number;
// amount: number;
// isIgst: boolean = false;
// ref: string;
// refType: string;
// status: string;
