import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { RoomBookTrack } from "../../entities/RoomBookTrack";

@Component({
  selector: 'app-room-book-track',
  templateUrl: './room-book-track.component.html',
  styleUrls: ['./room-book-track.component.scss']
})
export class RoomBookTrackComponent implements OnInit {

  @Input()
  roomBookTrack: RoomBookTrack = null;

  @Input()
  type: string;

  @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }

}
