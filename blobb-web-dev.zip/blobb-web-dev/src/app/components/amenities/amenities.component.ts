import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { Amenities } from "../../entities/Amenities";

@Component({
    selector: "app-amenities",
    templateUrl: "./amenities.component.html",
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class AmenitiesComponent implements OnInit, OnChanges {
    Props: Props = Props;
    img = "https://cdn.pixabay.com/photo/2013/07/13/11/34/wifi-158401_960_720.png";

    @Input()
    amenities: Amenities;

    @Input()
    type: string = "edit";

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    svg: string;

    constructor(private loadService: LoadService) {
        this.amenities = new Amenities();
    }

    ngOnInit() {}
    selectedItem(event) {
        this.outputEvent.emit(event);
    }

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["amenities"];
        if (!!changeValue && changeValue.previousValue != changeValue.currentValue) {
            if (this.amenities.data) {
                this.svg = atob(this.amenities.data.replace(/data:image\/svg\+xml;base64,/, ""));
            }
        }
    }
}
