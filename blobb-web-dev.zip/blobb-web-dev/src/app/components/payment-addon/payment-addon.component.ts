import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { PaymentAddon } from "../../entities/PaymentAddon";

@Component({
    selector: "app-payment-addon",
    templateUrl: "./payment-addon.component.html",
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class PaymentAddonComponent implements OnInit, OnChanges {
    Props: Props = Props;
    @Input()
    paymentAddon: PaymentAddon = null;
    paymentModes:any=[];

    @Input()
    type: string = "view";

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private loadService: LoadService) {
        this.paymentAddon = new PaymentAddon();
        this.loadType();
    }

    ngOnInit() {}

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["paymentAddon"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            // TO-DO
        }
    }
    private loadType() {
        this.loadService.paymentModes().subscribe((results: any[]) => {
          if (results) {
            this.paymentModes = results;
          } else {
            this.paymentModes = [];
          }
        });
      }
}
