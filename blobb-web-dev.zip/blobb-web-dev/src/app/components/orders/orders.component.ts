import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { Orders } from "../../entities/Orders";

@Component({
  selector: "app-orders",
  templateUrl: "./orders.component.html",
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class OrdersComponent implements OnInit, OnChanges {
  Props: Props = Props;
  @Input()
  orders: Orders = null;

  @Input()
  type: string = "view";

  @Output()
  outputEvent: EventEmitter<any> = new EventEmitter<any>();

  constructor(private loadService: LoadService) {
    this.orders = new Orders();
  }

  ngOnInit() {}

  ngOnChanges(changes: SimpleChanges) {
    const changeValue: SimpleChange = changes["orders"];
    if (changeValue && changeValue.previousValue != changeValue.currentValue) {
      // TO-DO
    }
  }
}
