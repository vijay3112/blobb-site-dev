import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { Flat } from '../../entities/Flat';

@Component({
    selector: 'app-flat',
    templateUrl: './flat.component.html',
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class FlatComponent implements OnInit, OnChanges{
    Props: Props = Props;
    @Input()
    flat: Flat = null;

    @Input()
    type: string = 'view';

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    

    constructor(private loadService: LoadService) {
        this.flat = new Flat();
    }

    ngOnInit() {
       
    }

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["flat"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
          // TO-DO
        }
    }

    

}
