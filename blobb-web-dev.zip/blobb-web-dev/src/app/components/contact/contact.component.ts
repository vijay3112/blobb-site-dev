import { Component, OnInit, Input, Pipe } from "@angular/core";
import { Props } from "../../constants/props";
import { WebContactUs } from "../../entities/WebContactUs";
import { LoadService } from "../../constants/load.service";
import { NgForm, ControlContainer } from "@angular/forms";
import { BreakOnWordPipe } from "../../shared/utils/pipes";
@Component({
    selector: "app-contact",
    templateUrl: "./contact.component.html",
    styleUrls: ["./contact.component.scss"],
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class ContactComponent implements OnInit {
    Props: any = Props;

    @Input()
    contact: WebContactUs = null;
    @Input()
    type: string;

    constructor(private loadservice: LoadService) {
        this.contact = new WebContactUs();
    }

    ngOnInit() {}
}
