import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { Feedback } from "../../entities/Feedback";

@Component({
    selector: "app-feedback",
    templateUrl: "./feedback.component.html",
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class FeedbackComponent implements OnInit, OnChanges {
    Props: Props = Props;
    @Input()
    feedback: Feedback = null;
    profiles: any = [];
    @Input()
    type: string;
    branchesList:any[] =[];
    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private loadService: LoadService) {
        this.feedback = new Feedback();
    }

    ngOnInit() {
       
    }

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["feedback"];
        if (changes["type"]) {
            this.type = changes["type"].currentValue;
            if (this.type == "edit") {
                this.loadUsers();
                this.loadProperties()
            }
        }

        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            console.log(changeValue.currentValue);
            this.feedback = changeValue.currentValue;
        } else {
            this.feedback = new Feedback();
        }
    }

    loadUsers() {
        this.loadService.users().subscribe((data: any) => {
            this.profiles = data;
        });
    }
    private loadProperties(){
        this.loadService.propertyAll().subscribe((results: any[]) => {
            if (results) {
                this.branchesList = results;
            } else {
                this.branchesList = [];
            }
        });
    }

    callRate($event: any) {
        this.feedback.rateUs = $event == "+" ? this.feedback.rateUs + 1 : this.feedback.rateUs - 1;
    }
}
