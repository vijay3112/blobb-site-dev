import { Component, OnInit, Input } from "@angular/core";
import { AppSubscribe } from "../../entities/AppSubscribe";

@Component({
    selector: "app-subscribe",
    templateUrl: "./subscribe.component.html",
    styleUrls: ["./subscribe.component.scss"],
})
export class SubscribeComponent implements OnInit {
    @Input()
    subscribe: AppSubscribe;
    constructor() {}

    ngOnInit() {}
}
