import { Component, OnInit, Input, Output, OnChanges, SimpleChange, SimpleChanges, EventEmitter } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { Props } from "../../constants/props";
import { LoadService } from "../../constants/load.service";

import { WebMetadata } from '../../entities/WebMetadata';

@Component({
    selector: 'app-web_metadata',
    templateUrl: './web-metadata.component.html',
    viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class WebMetadataComponent implements OnInit, OnChanges {
    Props: Props = Props;
    @Input()
    webMetadata: WebMetadata = null;

    @Input()
    type: string = 'view';

    @Output()
    outputEvent: EventEmitter<any> = new EventEmitter<any>();



    constructor(private loadService: LoadService) {
        this.webMetadata = new WebMetadata();
    }

    ngOnInit() {

    }

    ngOnChanges(changes: SimpleChanges) {
        const changeValue: SimpleChange = changes["webMetadata"];
        if (changeValue && changeValue.previousValue != changeValue.currentValue) {
            // TO-DO
        }
    }



}