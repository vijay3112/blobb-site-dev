import { Component, Input, Output, EventEmitter, OnInit } from "@angular/core";
import { Feedback } from "../../entities/Feedback";

@Component({
    selector: "app-star-rating",
    templateUrl: "./star-rating.component.html",
    styleUrls: ["./star-rating.component.scss"],
})
export class StarRatingComponent implements OnInit {
    @Input()
    feedback: Feedback;
    @Input()
    rateUs: number;
    @Input() rating: number;
    @Input() itemId: number;
    @Output() ratingClick: EventEmitter<any> = new EventEmitter<any>();

    inputName: string;
    constructor() {}

    ngOnInit() {
        console.log(this.feedback);
        this.inputName = this.itemId + "_rating";
    }
    onClick(rating: number): void {
        this.rating = rating;
        this.ratingClick.emit({
            itemId: this.itemId,
            rating: rating,
        });
    }
}
