ALTER TABLE `blobb_db`.`property`
DROP FOREIGN KEY `property_fk_web_metadata_id`;
ALTER TABLE `blobb_db`.`property`
DROP COLUMN `web_metadata_id`,
DROP INDEX `property_fk_web_metadata_id` ;

DROP TABLE app_contact_us;
DROP TABLE app_subscribe;
DROP TABLE web_metadata;

create table seq_rec
(
    id varchar(127) not null primary key,
    format_code varchar(127) not null ,
    branch_code varchar(127) not null,
    fy int not null default '2020',
    type varchar(127) not null,
    next_rec varchar(127) not null default '0001',
    updated_by varchar(127) not null default 'system',
    updated_on timestamp not null default now()
);

alter table room_book change column invoice invoice_order varchar(128);

alter table room_book change column order_invoice invoice_service varchar(128);



insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '1', 'BBBBFYTY-XXXX', 'BRHS', '20', 'CD', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '2', 'BBBBFYTY-XXXX', 'BRHS', '20', 'CH', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '3', 'BBBBFYTY-XXXX', 'BRHS', '20', 'SR', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '4', 'BBBBFYTY-XXXX', 'BRHS', '20', 'DR', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'BRHS_CD', 'BBBBFYTY-XXXX', 'BRHS', '20', 'CD', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'BRHS_CH', 'BBBBFYTY-XXXX', 'BRHS', '20', 'CH', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'BRHS_SR', 'BBBBFYTY-XXXX', 'BRHS', '20', 'SR', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'BRHS_DN', 'BBBBFYTY-XXXX', 'BRHS', '20', 'DN', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'BRHS_CN', 'BBBBFYTY-XXXX', 'BRHS', '20', 'CN', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'BRHS_IN', 'BBBBFYTY-XXXX', 'BRHS', '20', 'IN', '0001');


insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'JBHS_CD', 'BBBBFYTY-XXXX', 'JBHS', '20', 'CD', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'JBHS_CH', 'BBBBFYTY-XXXX', 'JBHS', '20', 'CH', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'JBHS_SR', 'BBBBFYTY-XXXX', 'JBHS', '20', 'SR', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'JBHS_DN', 'BBBBFYTY-XXXX', 'JBHS', '20', 'DN', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'JBHS_CN', 'BBBBFYTY-XXXX', 'JBHS', '20', 'CN', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'JBHS_IN', 'BBBBFYTY-XXXX', 'JBHS', '20', 'IN', '0001');

insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'GAHB_CD', 'BBBBFYTY-XXXX', 'GAHB', '20', 'CD', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'GAHB_CH', 'BBBBFYTY-XXXX', 'GAHB', '20', 'CH', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'GAHB_SR', 'BBBBFYTY-XXXX', 'GAHB', '20', 'SR', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'GAHB_DN', 'BBBBFYTY-XXXX', 'GAHB', '20', 'DN', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'GAHB_CN', 'BBBBFYTY-XXXX', 'GAHB', '20', 'CN', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( 'GAHB_IN', 'BBBBFYTY-XXXX', 'GAHB', '20', 'IN', '0001');



insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '21', 'BBBBFYTY-XXXX', 'GAHB', '20', 'CD', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '22', 'BBBBFYTY-XXXX', 'GAHB', '20', 'CH', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '23', 'BBBBFYTY-XXXX', 'GAHB', '20', 'SR', '0001');
insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '24', 'BBBBFYTY-XXXX', 'GAHB', '20', 'DR', '0001');


create table web_contact_us
(
    id varchar(128) primary key,
    name varchar(128) not null,
    email varchar(128) not null,
    country_code varchar(8) not null default '91',
    mobile varchar(16) not null,
    message text,
    active boolean default true,
    subscribe boolean default true,
    vid varchar(128) not null default 'OWN',
    created_by varchar(128) not null default 'system',
    created_on timestamp not null default now(),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);


create table web_metadata
(
    id varchar(128) primary key,
    page varchar(255) not null,
    keywords text not null,
    summary text not null,
    updated_on timestamp not null default now(),
    updated_by varchar(255) not null default 'system'
);

UPDATE app_data SET id = 'ADJUST', name = 'ADJUST AMOUNT' WHERE (id = 'PAYMENT_MODE_UPI PAYMENTS_PAYTM_CHECK');
INSERT INTO app_data (id, name, code) VALUES ( 'UPI', 'UPI', 'PAYMENT_MODE');
