CALL ROLE_MENU ('Expenses', 'MENU', 'OWN');
create table expenses (
  id varchar(128) primary key,
  type_id varchar(128) not null,
  txn_date date not null,
  to_whom varchar(128),
  amount decimal(19,2) not null default 0,
  file_data_id varchar(128) not null,
  branch varchar(128) not null,
  updated_by varchar(128) not null default 'system',
  updated_on timestamp not null default now()
);
alter table expenses add constraint expenses_fk_type_id foreign key (type_id) references app_data(id);
alter table expenses add constraint expenses_fk_file_data_id foreign key (file_data_id) references file_data(id);



CALL ROLE_MENU ('Amenities', 'MENU', 'OWN');
CALL ROLE_MENU ('Property', 'MENU', 'OWN');
CALL ROLE_MENU ('Supervisor', 'ROLE', 'OWN');

create table amenities (
    id varchar(128) primary key,
    name varchar(128) not null,
    data longtext not null,
    active boolean not null default true,
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);

create table web_metadata (
    id varchar(128) primary key,
    name varchar(1024) not null,
    title varchar(1024) not null,
    summary varchar(4096) not null
);

create table property (
    id varchar(128) primary key,
    name varchar(128) not null,
    type varchar(128),
    location varchar(128) not null,
    address_id varchar(128),
    supervisor_id varchar(128),
    web_metadata_id varchar(128),
    summary varchar(4096) not null,
    map_location varchar(128),
    gst_no varchar(32),
    active boolean not null default true,
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table property add constraint property_fk_address_id foreign key (address_id) references address(id);
alter table property add constraint property_fk_supervisor_id foreign key (supervisor_id) references profile(id);
alter table property add constraint property_fk_web_metadata_id foreign key (web_metadata_id) references web_metadata(id);


create table property_amenities (
    id varchar(128) primary key,
    property_id varchar(128) not null,
    amenities_id varchar(128) not null,
    active boolean not null default true
);
alter table property_amenities add constraint property_amenities_fk_property_id foreign key (property_id) references property(id);
alter table property_amenities add constraint property_amenities_fk_amenities_id foreign key (amenities_id) references amenities(id);

create table orders (
    id varchar(128) primary key,
    name varchar(128) not null,
    type varchar(128) not null,
    property_id varchar(128) not null,
    payment_tax_id varchar(128) not null,
    active boolean not null default true,
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table orders add constraint orders_fk_property_id foreign key (property_id) references property(id);
alter table orders add constraint orders_fk_payment_tax_id foreign key (payment_tax_id) references payment_tax(id);

create table flat (
    id varchar(128) primary key,
    name varchar(128) not null,
    floor varchar(32) not null,
    property_id varchar(128) not null,
    active boolean not null default true,
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table flat add constraint flat_fk_property_id foreign key (property_id) references property(id);

create table room (
    id varchar(128) primary key,
    name varchar(128) not null,
    type varchar(128) not null,
    flat_id varchar(128) not null,
    property_id varchar(128) not null,
    ext_phone varchar(32) not null,
    channel_manger_active boolean not null default false,
    persons int not null default 2,
    addon_persons int not null default 0,
    addon_persons_cost int not null default 0,
    payment_tax_id varchar(128) not null,
    summary varchar(4096),
    active boolean not null default true,
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table room add constraint room_fk_flat_id foreign key (flat_id) references flat(id);
alter table room add constraint room_fk_property_id foreign key (property_id) references property(id);
alter table room add constraint room_fk_payment_tax_id foreign key (payment_tax_id) references payment_tax(id);

CALL ROLE_MENU ('Booking', 'MENU', 'OWN');

create table room_book(
  id varchar(128) primary key,
  invoice varchar(128),
  order_invoice varchar(128),
  profile_id varchar(128) not null,
  book_type varchar(128) not null,
  payment_id varchar(128) not null,
  room_id varchar(128) not null,
  from_date datetime not null,
  to_date datetime not null,
  advance decimal(19,2) not null default 0,
  balance decimal(19,2) not null default 0,
  price decimal(19,2) not null default 0,
  cgst_price decimal(19,2) not null default 0,
  sgst_price decimal(19,2) not null default 0,
  igst_price decimal(19,2) not null default 0,
  amount decimal(19,2) not null default 0,
  status varchar(128) not null default 'BOOKING',
  active boolean not null default false,
  show_gst boolean not null default true,
  created_by varchar(128) not null default 'system',
  created_on timestamp not null default now(),
  updated_by varchar(128) not null default 'system',
  updated_on timestamp not null default now()
);
alter table room_book add constraint room_book_fk_profile_id foreign key (profile_id) references profile(id);
alter table room_book add constraint room_book_fk_payment_id foreign key (payment_id) references payment(id);
alter table room_book add constraint room_book_fk_room_id foreign key (room_id) references room(id);


create table room_orders(
  id varchar(128) primary key,
  transaction_date timestamp not null default now(),
  orders_id varchar(128) not null,
  payment_id varchar(128) not null,
  room_book_id varchar(128) not null,
  summary varchar(4096),
  updated_by varchar(128) not null default 'system',
  updated_on timestamp not null default now()
);
alter table room_orders add constraint room_orders_fk_orders_id foreign key (orders_id) references orders(id);
alter table room_orders add constraint room_orders_fk_payment_id foreign key (payment_id) references payment(id);
alter table room_orders add constraint room_orders_fk_room_book_id foreign key (room_book_id) references room_book(id);


create table room_persons(
  id varchar(128) primary key,
  name varchar(128) ,
  email varchar(128) ,
  mobile varchar(128),
  room_book_id varchar(128) not null,
  file_data_id varchar(128) not null,
  img_id varchar(128) not null,
  doc varchar(64),
  updated_by varchar(128) not null default 'system',
  updated_on timestamp not null default now()
);
alter table room_persons add constraint room_persons_fk_img_id foreign key (img_id) references img(id);
alter table room_persons add constraint room_persons_fk_file_data_id foreign key (file_data_id) references file_data(id);
alter table room_persons add constraint room_persons_fk_room_book_id foreign key (room_book_id) references room_book(id);

create table room_book_track(
	  id varchar(128) primary key not null,
    room_book_id varchar(128) not null,
    status varchar(64) not null,
    updated_by varchar(128) default 'system',
    updated_on timestamp default now()
);

alter table room_book_track add constraint room_book_track_fk_room_book_id foreign key (room_book_id) references room_book(id);
