create database blobb_db;
CREATE USER 'blobb_user'@'%' IDENTIFIED BY 'blobb1234';
GRANT ALL PRIVILEGES ON  blobb_db.* TO   'blobb_user'@'%';
FLUSH PRIVILEGES;

use  blobb_db;


create table access_log_data
(
    data text,
    updated_on datetime default now()
);

create table access_data
(
    name varchar(32) not null,
    code varchar(32) not null,
    val varchar(32) not null,
    data varchar(128),
    status boolean not null default true
);
alter table access_data add constraint access_data_uq_name_code unique( val, code);




create table access_menu
(
    id varchar(128) primary key,
    name varchar(64) not null,
    menu varchar(64) not null,
    role varchar(32) not null,
    vid varchar(16) not null default 'own',
    active boolean default true not null,
    write_access boolean default false not null,
    priority int not null default 999,
    updated_by varchar(128) default 'system',
    updated_on timestamp default now()
);


create table app_data
(
    id varchar(128) primary key,
    name varchar(64) not null,
    code varchar(32) not null,
    data varchar(128),
    active boolean not null default true,
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table app_data add constraint app_data_uq_name_code_vid unique(name, code);

create table address
(
    id varchar(128) primary key,
    lane varchar(128),
    land_mark varchar(128),
    city varchar(32),
    state varchar(32),
    country varchar(32) default 'India',
    zipcode int(8)
);

create table img
(
    id varchar(128) primary key,
    name varchar(128) NOT NULL default 'Upload',
    src longtext,
    ref varchar(128) not null,
    ref_type varchar(128),
    is_secure boolean default false
);

CREATE TABLE file_data (
    id varchar(128) primary key,
    name VARCHAR(128) NOT NULL DEFAULT 'Upload',
    mimetype VARCHAR(64),
    data LONGBLOB,
    ref varchar(128) not null,
    ref_type varchar(128),
    is_secure boolean default false
);



create table profile
(
    id varchar(128) primary key,
    name varchar(64) not null,
    mobile varchar(15) not null,
    email varchar(64),
    password varchar(512) not null default '1234',
    token varchar(32),
    role varchar(32) not null default 'USER',
    status varchar(32) not null default 'NA',
    active boolean not null default true,
    created_by varchar(128) not null default 'system',
    created_on timestamp not null default now(),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);

create table profile_docs (
    id varchar(128) primary key,
    gender varchar(32),
    dob datetime,
    profile_id varchar(128) not null,
    address_id varchar(128) not null,
    img_id varchar(128) not null,
    file_data_id varchar(128) not null,
    doc_number varchar(64),
    exp_date datetime,
    bank_name varchar(64),
    bank_branch varchar(64),
    account_number varchar(32),
    swift_code varchar(64),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table profile_docs add constraint profile_docs_fk_address_id foreign key (address_id) references address(id);
alter table profile_docs add constraint profile_docs_fk_img_id foreign key (img_id) references img(id);
alter table profile_docs add constraint profile_docs_fk_profile_id foreign key (profile_id) references profile(id);
alter table profile_docs add constraint profile_docs_fk_file_data_id foreign key (file_data_id) references file_data(id);
alter table profile_docs add constraint profile_docs_uq_profile_id UNIQUE (profile_id);






insert into access_data (code, name, val) values ('MENU', 'Dashboard'	, 'DASHBOARD');
insert into access_data (code, name, val) values ('MENU', 'App Data'	, 'APP_DATA');
insert into access_data (code, name, val) values ('MENU', 'Profiles'	, 'PROFILES');
insert into access_data (code, name, val) values ('MENU', 'Access Menu', 'ACCESS_MENU');
insert into access_data (code, name, val) values ('MENU', 'Home', 'HOME');

insert into access_data (val, name, code) values('CONSUMER_CONSUMER', 'consumer', 'REPORT_CONSUMER');
insert into access_data (val, name, code) values('CONSUMER_FROMDATE', 'fromDate', 'REPORT_CONSUMER');
insert into access_data (val, name, code) values('CONSUMER_TODATE', 'toDate', 'REPORT_CONSUMER');

INSERT INTO access_data (code, name, val) VALUES ('CODE', 'PAYMENT_MODE', 'PAYMENT_MODE');
INSERT INTO access_data (code, name, val) VALUES ('CODE', 'EXPENSES_TYPE', 'EXPENSES_TYPE');
INSERT INTO access_data (code, name, val) VALUES ('CODE', 'SERVICE_TYPE', 'SERVICE_TYPE');

INSERT INTO access_data (code, name, val) VALUES ('ROOM_TYPE', 'CORPORATE', 'CORPORATE');
INSERT INTO access_data (code, name, val) VALUES ('ROOM_TYPE', 'BOOKING', 'BOOKING');
INSERT INTO access_data (code, name, val) VALUES ('ROOM_TYPE', 'RESERVATION', 'RESERVATION');



INSERT INTO profile (id, name, email, mobile, password, role) VALUES ('ADMIN', 'Support User', 'admin@dfftech.com', '123456789', 'Test!234', 'ADMIN');
INSERT INTO profile (id, name, email, mobile, password, role) VALUES ('SUPER_ADMIN', 'SUPER_ADMIN', 'super@admin.com', '0022448899', '80086699', 'SUPER_ADMIN');
INSERT INTO profile (id, name, email, mobile, password, role) VALUES ('APP_USER', 'App User', 'user@dfftech.com', '999999999', 'USER', 'USER');

INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_ADVERTISEMENT','Advertisement', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_AUDIT_FEES','Audit fees', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_BAD_DEBTS','Bad debts', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_BANK_CHARGES','Bank charges', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_BOXES_AND_LABELS','Boxes and labels', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_BROKERAGE','Brokerage', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_CARRIAGE_ON_SALE','Carriage on sale', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_CARRIAGE_OUTWARD_E_INSURANCE','Carriage outward e Insurance', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_COMMISSION','Commission', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_CONVEYANCE','Conveyance', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_DEPRECIATION','Depreciation', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_DISCOUNT','Discount', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_DISCOUNT_OF_DEBTORS','Discount of debtors', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_DISTRIBUTIVE','Distributive', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_ELECTRIC_BILLS','Electric Bills', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_ENTERTAINMENT','Entertainment', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_ESTABLISHMENT','Establishment', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_EXPORT_DUTY','Export duty', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_FOOD','Food', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_FREIGHT_OUTWARD','Freight outward', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_FUEL','Fuel', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_GENERAL','General', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_HOSPITAL_CHARGES','Hospital charges', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_INTEREST_ON_CAPITAL','Interest on capital', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_INTEREST','Interest', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_KEEP_CAR_AND_VANS','Keep car and vans', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_LEGAL_CHARGES_AND_LAW_FESS','Legal charges and law fess', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_LICENSE_FESS','License fess', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_LOSS_THEFT_BY_FIRE','Loss theft by fire', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_OCTROI','Octroi', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_OFFICE','Office', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_OFFICE_LIGHTING','Office lighting', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_PACKING','Packing', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_POSTAGE_AND_TELEGRAM','Postage and telegram', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_PROVISION_FOR_BAD_DEBTS','Provision for bad debts', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_RENT','Rent', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_REPAIR_AND_RENEWALS','Repair and renewals', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_SALARY','Salary', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_STABLE','Stable', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_STATIONARY','Stationary', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_STOCK','Stock', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_TELEPHONE','Telephone', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_TRADE_EXP','Trade exp', 'EXPENSES_TYPE');
INSERT INTO app_data (id, name, code) VALUES ('EXPENSES_TYPE_TRAVELING','Traveling', 'EXPENSES_TYPE');

INSERT INTO app_data (id, name, code) VALUES ( 'CASH', 'Cash', 'PAYMENT_MODE');
INSERT INTO app_data (id, name, code) VALUES ( 'CARD', 'Card', 'PAYMENT_MODE');
INSERT INTO app_data (id, name, code) VALUES ( 'ONLINE', 'Online', 'PAYMENT_MODE');


create table feedback (
    id varchar(128) primary key,
    profile_id varchar(128) not null,
    rate_us int not null default 5,
    summary varchar(4096),
    active boolean not null default true,
    branch varchar(128) no null,
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table feedback add constraint feedback_fk_profile_id foreign key (profile_id) references profile(id);

create table payment (
    id varchar(128) primary key,
    type varchar(128) not null default '',
    cost decimal(19,2) not null default 0,
    units int not null default 1,
    price decimal(19,2) not null default 0,
    cgst decimal(4,2) not null default 0.00,
    sgst decimal(4,2) not null default 0.00,
    igst decimal(4,2) not null default 0.00,
    discount decimal(4,2) not null default 0.00,
    cgst_price decimal(19,2) not null default 0,
    sgst_price decimal(19,2) not null default 0,
    igst_price decimal(19,2) not null default 0,
    discount_price decimal(19,2) not null default 0,
    amount decimal(19,2) not null default 0,
    is_igst boolean not null default false,
    ref varchar(128) not null,
    ref_type varchar(128),
    status varchar(32) not null default 'due or done',
    created_by varchar(128) not null default 'system',
    created_on timestamp not null default now(),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);

create table payment_addon (
    id varchar(128) primary key,
    type varchar(128) not null default 'card or cash or adjust or advance',
    amount decimal(19,2) not null default 0,
    payment_id varchar(128) not null,
    summary varchar(4096),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
alter table payment_addon add constraint payment_line_fk_payment_id foreign key (payment_id) references payment(id);

create table payment_tax (
    id varchar(128) primary key,
    cost decimal(19,2) not null default 0,
    cgst decimal(4,2) not null default 0.00,
    sgst decimal(4,2) not null default 0.00,
    igst decimal(4,2) not null default 0.00,
    ref_type varchar(128) not null default ''
);


create table app_report (
    id varchar(128) primary key,
    name varchar(128) not null,
    report_url varchar(128) not null
);
create table app_report_param (
    id varchar(128) primary key,
    name varchar(128) not null,
    status boolean not null default true,
    apex_report_id varchar(128) not null
);


insert into app_report( id, name, report_url) values ('USERS', 'Users', '/users');
insert into app_report_param(id, name, apex_report_id) values ('USERS-1', 'fromDate', 'USERS');
insert into app_report_param(id, name, apex_report_id) values ('USERS-2', 'toDate', 'USERS');




DELIMITER ;;
CREATE  PROCEDURE `ROLE_MENU`(IN RM_NAME VARCHAR(64),IN RM_CODE VARCHAR(20), IN VID VARCHAR(9))
BEGIN

    DECLARE ID_NEW VARCHAR(128);
    DECLARE NAME_NEW VARCHAR(64);
    DECLARE KEY_NEW VARCHAR(64);
    DECLARE MENU_NEW VARCHAR(64);
    DECLARE ROLE_NEW VARCHAR(32);
    DECLARE ACTIVE_NEW BOOLEAN;
    DECLARE ACCESS_MENU_NAME VARCHAR(64);
    DECLARE MENU_COUNT INT(128);
    DECLARE VID_NEW VARCHAR(64);

    DECLARE V_FINISHED INTEGER DEFAULT 0;
    DECLARE V_CODE VARCHAR(128);

    DECLARE ROLE_MENU_CUR CURSOR FOR (SELECT name FROM access_data WHERE code = (CASE RM_CODE WHEN 'MENU' THEN 'ROLE' ELSE 'MENU' END )) ;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET V_FINISHED = 1;
    SET V_CODE = (CASE RM_CODE WHEN 'MENU' THEN 'ROLE' ELSE 'MENU' END );

    INSERT INTO access_log_data ( data ) VALUES( CONCAT('PASS_CODE: ', RM_CODE ));
    INSERT INTO access_log_data  ( data ) VALUES( CONCAT('ACCESS_DATA_CODE: ', V_CODE) );
    INSERT INTO access_log_data  ( data ) VALUES( CONCAT('COUNT OF DATA: ', (SELECT COUNT(1) FROM access_data WHERE code= V_CODE )) );

    OPEN ROLE_MENU_CUR;

        IF RM_CODE = 'MENU' THEN
            I_LOOP:LOOP
                FETCH ROLE_MENU_CUR INTO ACCESS_MENU_NAME;
                    IF V_FINISHED = 1 THEN
                        LEAVE  I_LOOP;
                    END IF;
    		INSERT INTO access_log_data  ( data ) VALUES( '——————— start menu ------------------');
                    SET NAME_NEW =  RM_NAME;
                    SET MENU_NEW = LOWER( REPLACE(NAME_NEW, ' ','_' ) );
                    SET ROLE_NEW = UPPER( REPLACE(ACCESS_MENU_NAME, ' ','_' )) ;
                    SET VID_NEW = UPPER( REPLACE(VID, ' ','_' ));
                    SET ID_NEW = CONCAT( VID_NEW,'_',UPPER(ROLE_NEW), '_', UPPER(MENU_NEW) );
                    IF ROLE_NEW = 'SUPER_ADMIN' THEN
                        SET ACTIVE_NEW = TRUE;
                     ELSEIF ROLE_NEW = 'ADMIN' THEN
                        SET ACTIVE_NEW = TRUE;
                     ELSE
                        SET ACTIVE_NEW = FALSE;
                    END IF;
                    SELECT COUNT(1) INTO MENU_COUNT FROM access_menu WHERE id=ID_NEW;
                    IF MENU_COUNT = 0 THEN
                        INSERT INTO access_log_data  ( data ) VALUES( CONCAT( "INSERT INTO access_menu(id, name, menu, role, active, vid) VALUES (", "'", ID_NEW, "','", NAME_NEW, "','", MENU_NEW ,"','", ROLE_NEW, "','", ACTIVE_NEW, "','", VID, "'", ");") );
                        INSERT INTO access_menu(id, name, menu, role, active, write_access, vid) VALUES (ID_NEW, NAME_NEW, MENU_NEW, ROLE_NEW, ACTIVE_NEW, ACTIVE_NEW, VID);
                    END IF;
    		INSERT INTO access_log_data  ( data ) VALUES( '——————— end menu ------------------');
                END LOOP I_LOOP;
        END IF;

        IF RM_CODE='ROLE' THEN
                I_LOOP:LOOP
                    FETCH ROLE_MENU_CUR INTO ACCESS_MENU_NAME;
                        IF V_FINISHED = 1 THEN
                            LEAVE  I_LOOP;
                        END IF;
    			INSERT INTO access_log_data  ( data ) VALUES( '——————— start role ------------------');
                        SET MENU_NEW = LOWER(REPLACE(ACCESS_MENU_NAME, ' ','_' ));
                        SET NAME_NEW =  ACCESS_MENU_NAME;
                        SET ROLE_NEW = UPPER(REPLACE(RM_NAME, ' ', '_' ));
                        SET VID_NEW=UPPER(REPLACE(VID, ' ','_' ));
                        SET ID_NEW = CONCAT(VID_NEW,'_',UPPER(ROLE_NEW), '_', UPPER(MENU_NEW));
                        IF ROLE_NEW = 'SUPER_ADMIN' THEN
                            SET ACTIVE_NEW = TRUE;
                         ELSEIF ROLE_NEW = 'ADMIN' THEN
                            SET ACTIVE_NEW = TRUE;
                        ELSE
                            SET ACTIVE_NEW = FALSE;
                        END IF;
                        SELECT COUNT(1) INTO MENU_COUNT FROM access_menu WHERE id=ID_NEW;
                        IF MENU_COUNT = 0 THEN
                            INSERT INTO access_log_data  ( data ) VALUES( CONCAT( "INSERT INTO access_menu(id, name, menu, role, active, vid) VALUES (", "'", ID_NEW, "','", NAME_NEW, "','", MENU_NEW ,"','", ROLE_NEW, "','", ACTIVE_NEW, "','", VID, "'", ");") );
                            INSERT INTO access_menu(id, name, menu, role, active,  write_access, vid) VALUES (ID_NEW, NAME_NEW, MENU_NEW, ROLE_NEW, ACTIVE_NEW, ACTIVE_NEW, VID);
                        END IF;
    			INSERT INTO access_log_data  ( data ) VALUES( '——————— end role ------------------');
                    END LOOP I_LOOP;
            END IF;
            SELECT COUNT(1) INTO MENU_COUNT FROM access_data WHERE name=RM_NAME AND code=RM_CODE;
            IF MENU_COUNT = 0 THEN
                INSERT INTO access_data(name, code, val) VALUES (RM_NAME, RM_CODE, UPPER(REPLACE(RM_NAME, ' ', '_' )) );
            END IF;
            INSERT INTO access_log_data  ( data ) VALUES ('DONE');

    CLOSE ROLE_MENU_CUR;
    END ;;
DELIMITER ;;

CALL ROLE_MENU ('Super Admin', 'ROLE', 'OWN');
CALL ROLE_MENU ('Admin', 'ROLE', 'OWN');
CALL ROLE_MENU ('User', 'ROLE', 'OWN');
CALL ROLE_MENU ('Staff', 'ROLE', 'OWN');
CALL ROLE_MENU ('Feedback', 'MENU', 'OWN');
CALL ROLE_MENU ('Contact Us', 'MENU', 'OWN');
CALL ROLE_MENU ('Subscribe', 'MENU', 'OWN');
CALL ROLE_MENU ('Corporate Booking', 'MENU', 'OWN');

create table corporate_booking (
    id varchar(45) primary key,
    name varchar(45) not null,
    email varchar(45) not null,
    mobile varchar(16) not null,
    company_name varchar(45),
    message text,
    active boolean default true,
    created_by varchar(128) not null default 'system',
    created_on timestamp not null default now(),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);

create table app_subscribe (
    id varchar(45) primary key,
    name varchar(45) not null,
    email varchar(45) not null,
    mobile varchar(16),
    active boolean default true,
    created_by varchar(128) not null default 'system',
    created_on timestamp not null default now(),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);

create table app_contact_us (
    id varchar(45) primary key,
    name varchar(45) not null,
    email varchar(45) not null,
    mobile varchar(16) not null,
    message text,
    active boolean default true,
    created_by varchar(128) not null default 'system',
    created_on timestamp not null default now(),
    updated_by varchar(128) not null default 'system',
    updated_on timestamp not null default now()
);
