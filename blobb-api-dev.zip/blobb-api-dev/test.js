// const NodeCache = require("node-cache");
// const myCache = new NodeCache({ stdTTL: 25 });

// obj = { my: "Special", variable: 42 };
// success = myCache.set("myKey", obj);

// setInterval(() => {
//     myCache.get("myKey", function(err, value) {
//         if (!err) {
//             if (value == undefined) {
//                 console.log("no key founc");
//             } else {
//                 console.log(value);
//                 //{ my: "Special", variable: 42 }
//                 // ... do something ...
//             }
//         }
//     });
// }, 1000);

// function shortestSubstring(s) {
//     if (s == null) return "";
//     let returnValue = "";
//     for (let i of s) {
//         if (returnValue.indexOf(i) == -1) {
//             returnValue = returnValue + i;
//         }
//     }
//     console.log("" + returnValue);
//     let uq = returnValue;
//     let uqLength = returnValue.length;
//     returnValue = recursiveSubtring(s, uq, 0, uqLength);
//     console.log(returnValue);
//     //return returnValue.length;
// }
// function recursiveSubtring(s, uq, index, size) {
//     if (s.length < index + size) {
//         size = size + 1;
//         index = 0;
//     }
//     let retrunValue = s.substring(index, index + size);
//     //console.log(retrunValue + " -> size, index: " + index + ", " + size);
//     let notFound = false;
//     for (let i of uq) {
//         if (retrunValue.indexOf(i) == -1) {
//             notFound = true;
//         }
//         if (notFound) {
//             break;
//         }
//     }
//     if (notFound) {
//         index = index + 1;
//         if (index <= uq.length) {
//             return recursiveSubtring(s, uq, index, size);
//         }
//     } else {
//         return retrunValue;
//     }
//     return retrunValue;
// }
// shortestSubstring("aabcce");
// function abcd(value) {
//     // s = "" + s;
//     let dataArray = Array.from(value.toString()).map(Number);
//     console.log(dataArray);
//     // for (let i of s) {
//     //     console.log(i);
//     // }
// }
// abcd("1234");

// function substringCalculator(s) {
//     if (!s) return 0;
//     length = s.length;
//     let dataArray = Array.from(s);
//     let duplicateCount = 0;
//     dataArray.map(ele => {
//         if (checkDuplicate(s, ele)) {
//             duplicateCount = duplicateCount + 1;
//         }
//     });
//     val = (length * (length + 1)) / 2;
//     val = Math.round(val) - duplicateCount / 2;
//     return val;
// }
// function checkDuplicate(s, data) {
//     let arr = Array.from(s).filter(ele => ele == data);
//     return arr.length > 1 ? true : false;
// }
// console.log(
//     substringCalculator(
//         "ghaqjdrmnegmrlrlfpjmnnngpwalzknsencuzwsnhfltwohdgbmvfuwtquosrnyerucntxxkfqehjqygcarxogvcfkljzbzutxphpyykapncjfclnhndzxghelyvzpylazhuutmcquusexzbhsfsmbnlvnlemzvfqbfzwquairhpylnbvyhiyamztlhfchhbwrqddmuzsprfdwuqqchcpeakkexackwwzihkfenwzwckynymgqydvjtovaoezkjjurylqcuonsujycziobnfnmuwnoxcdtahpituykvgpyyshvukrstcbmnsqtjseflwywnslmvnqrtnzkyaddkjamrezprqgoenzsdryygbkeahfiduozpwkrgmatszaxmwodsqiocvagbvxyqotpaujnqvqgjmfxnxhfbwqjpgodlxdrxpjpmzeabpgqrzpxomniknjkdiwtfgyvwvekrnoupwkcbtmpcfamzrghgrznuedkybmfwctdghcfawajlxfkzhdamuygjbcwnyglkjlfmpxfdtovkqbshhrfrnyjrgxgiozsuuncnwofkqzsypwgeikpfbhryhpszegdfajzvqlwwqlnvdtdiuckcvvosrdweohnmawqonjbxyjjhlccuteeshfrxxdhzgakwjqbymnaeudcmibsytyajsgdpfvrutcpglzxdevenevmkgalcrpknuvcrnkuboennhyzirfwvtozzijujsckbxqpocakzrbwgpqgjjmsrtwmvhwyraukbuxfvebeylfpipzwjdzlmgslbtwzataxgqpasrssnfwndldwkdutdqcmcpyanrbdsxrvcvpsywjambtbzlcrvzesuhvyvwwuwwdznigxjxknfajpknqutfvvqynkpvkzgypasevrpxofbymdzcitoqolwqegocuyqsexhumzmckzuuwkamolbltlifongpvkcnrnnuplftqbxpdnegdqlymftqyrxcnzmu"
//     )
// );
// function braces(values) {
//     let returnValue = "";
//     if (!values) return "NO";
//     values.map(ele => {
//         returnValue = returnValue + validBraces(ele);
//     });
//     return returnValue;
// }
// function validBraces(data) {
//     let openBraces = ["{", "[", "("];
//     let closeBraces = ["}", "]", ")"];

//     let orders = [];
//     if (!data) return "NO";
//     for (let i = 0; i < data.length; i++) {
//         if (openBraces.includes(data[i])) {
//             orders.push(data[i]);
//         } else if (closeBraces.includes(data[i])) {
//             //let index = closeBraces.indexOf( ele => ele == data[i]);
//             let closeOne = check(data[i]);
//             if (closeOne === orders[orders.length - 1]) {
//                 orders = orders.splice(orders.length, 1);
//             } else {
//                 orders.push(data[i]);
//                 break;
//             }
//         }
//     }
//     console.log(orders);
//     return orders.length == 0 ? "YES" : "NO";
// }
// function check(inputData) {
//     switch (inputData) {
//         case "}":
//             return "{";
//         case "]":
//             return "[";
//         case ")":
//             return "(";
//         default:
//             return "";
//     }
// }
// console.log(braces(["{}[]()", "{[}]}"]));

// for (var i = 0; i < 3; i++) {
//     (function(i) {
//         setTimeout(function() {
//             console.log(i);
//         }, 1000 + i);
//     })(i);
// }

// let counter = function() {
//     let k = 0;
//     return () => k++;
// };

// console.log(counter()());
// console.log(counter()());
// console.log(counter()());
// console.log("helloello".includes("ell", 1));
// var list = [1, 2, 3];
// var [a, , b] = list;
// var { op: a } = { op: 10 };
// console.log(a);

const arr = [10, 12, 15, 21];
for (var i = 0; i < arr.length; i++) {
    // using the ES6 let syntax, it creates a new binding
    // every single time the function is called
    // read more here: http://exploringjs.com/es6/ch_variables.html#sec_let-const-loop-heads
    setTimeout(function() {
        console.log("The index of this number is: " + i);
    }, 3000);
}
