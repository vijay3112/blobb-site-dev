import "reflect-metadata";
import AppExpress from "./apex/AppExpress";
import { createConnection } from "typeorm";
import * as Config from "./utils/Config";
import { log } from "./utils/Log";

const port = 5000;
Config.setEnvConfig();
let run = async () => {
    try {
        log.log(Config.dbOptions);
        const conn = await createConnection(Config.dbOptions);
        log.debug(" ************************************** " + conn.isConnected);
        if (conn.isConnected) {
            let express = new AppExpress().express;
            express.listen(port, async (err: any) => {
                if (err) {
                    return log.error(err);
                }

                return log.log(
                    "info",
                    `
                    ***********************************************
                    server is listening on http://127.0.0.1:${port}
                    
                    swagger is on http://127.0.0.1:${port}/apidocs
                    ***********************************************
         
                `
                );
            });
        }
    } catch (error) {
        log.error(error);
    }
};
run();

process.on("uncaughtException", function(err) {
    log.error("Caught exception: " + err);
});
