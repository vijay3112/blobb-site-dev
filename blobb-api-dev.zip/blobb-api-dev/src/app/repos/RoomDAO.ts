import { getRepository, Repository, In } from "typeorm";
import { Room } from "../../entities/Room";

export class RoomDAO {
    private dao: Repository<Room>;

    constructor() {
        this.dao = getRepository(Room);
    }

    async search(data: any) {
        console.log(data);

        let query: any = {};
        if (data.propertyIds) {
            if (data.propertyIds.indexOf(",") > 0) {
                query.property = In(data.propertyIds.split(","));
            } else {
                query.property = data.propertyIds;
            }
        }
        if (data.flat) {
            query.flat = data.flat;
        }
        if (data.name) {
            query.name = data.name;
        }
        // if (data) {
        //     if (data.param == "all") {
        //     } else if (data.param == "active") {
        //         query.active = true;
        //     } else if (data.param) {
        //         query.active = false;
        //     }
        // }

        console.log(query);
        return await this.dao
            .createQueryBuilder("room")
            .innerJoinAndSelect("room.flat", "flat")
            .innerJoinAndSelect("room.property", "property")
            .innerJoinAndSelect("room.paymentTax", "paymentTax")
            .where(query)
            .getMany();
    }

    async save(data: Room) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "room",
                innerJoinAndSelect: {
                    flat: "room.flat",
                    property: "room.property",
                    paymentTax: "room.paymentTax"
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "room",
                innerJoinAndSelect: {
                    flat: "room.flat",
                    property: "room.property",
                    paymentTax: "room.paymentTax"
                }
            }
        });
    }
}

Object.seal(RoomDAO);
