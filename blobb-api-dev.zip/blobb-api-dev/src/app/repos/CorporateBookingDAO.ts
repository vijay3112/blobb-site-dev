import { getRepository, Repository } from "typeorm";
import { CorporateBooking } from "../../entities/CorporateBooking";

export class CorporateBookingDAO {
    private dao: Repository<CorporateBooking>;

    constructor() {
        this.dao = getRepository(CorporateBooking);
    }

    async save(data: CorporateBooking) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return this.dao.findOne(id);
    }

    async delete(data: any) {
        return await this.dao.delete(data);
    }

    async search(data: any) {
        let filter:any = {}
        if (data) {
            if (data.param == "all") {
            } else if (data.param == "active") {
                filter.active = true;
            } else if (data.param == "de-active") {
                filter.active = false;
            }
        }
        console.log(filter);
        return await this.dao
            .createQueryBuilder("corporate_booking")
            .where(filter)
            .getMany();
    }
}


Object.seal(CorporateBookingDAO);
