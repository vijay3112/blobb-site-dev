import { getRepository, Repository } from "typeorm";
import { Orders } from "../../entities/Orders";

export class OrdersDAO {
    private dao: Repository<Orders>;

    constructor() {
        this.dao = getRepository(Orders);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("orders")
            .innerJoin("orders.property", "property")
            .innerJoinAndSelect("orders.paymentTax", "paymentTax")
            .addSelect(["property.id"])
            .where(data)
            .getMany();
    }

    async save(data: Orders) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "orders",
                innerJoinAndSelect: {
                    property: "orders.property",
                    paymentTax: "orders.paymentTax"
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "orders",
                innerJoinAndSelect: {
                    property: "orders.property",
                    paymentTax: "orders.paymentTax"
                }
            }
        });
    }
}

Object.seal(OrdersDAO);
