import { getRepository, Repository } from "typeorm";
import { PropertyAmenities } from "../../entities/PropertyAmenities";

export class PropertyAmenitiesDAO {

    private dao: Repository<PropertyAmenities>;

    constructor() {
        this.dao = getRepository(PropertyAmenities);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("propertyAmenities")
            .innerJoinAndSelect("propertyAmenities.property", "property")
            .innerJoinAndSelect("propertyAmenities.amenities", "amenities") 
            .where(data)
            .getMany();
    }

    async save(data: PropertyAmenities) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "propertyAmenities",
                innerJoinAndSelect: { 
                    "property": "propertyAmenities.property",
                    "amenities": "propertyAmenities.amenities", 
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "propertyAmenities",
                innerJoinAndSelect: { 
                    "property": "propertyAmenities.property",
                    "amenities": "propertyAmenities.amenities", 
                }
            }

        });
    }

}

Object.seal(PropertyAmenitiesDAO);
