import { getRepository, Repository } from "typeorm";
import { AccessMenu } from "../../entities/AccessMenu";

export class AccessMenuDAO {
  private dao: Repository<AccessMenu>;

  constructor() {
    this.dao = getRepository(AccessMenu);
  }

  async search(data: any) {
    return await this.dao
      .createQueryBuilder("menu")
      .orderBy("menu.priority", "ASC")
      .where(data)
      .getMany();
  }

  async save(data: AccessMenu) {
    return await this.dao.update({ id: data.id }, data);
  }

  async entity(id: string) {
    return this.dao.findOne(id);
  }

  async delete(data: AccessMenu) {
    return this.dao.remove([data]);
  }

  async findOne(data: any) {
    return this.dao.findOne(data);
  }
}

Object.seal(AccessMenuDAO);
