import { getRepository, Repository } from "typeorm";
import { RoomPersons } from "../../entities/RoomPersons";

export class RoomPersonsDAO {
    private dao: Repository<RoomPersons>;

    constructor() {
        this.dao = getRepository(RoomPersons);
    }

    async search(data: any) {
        let query: any = {};
        if (data.roomBookId) {
            query.roomBook = data.roomBookId;
        }
        return await this.dao
            .createQueryBuilder("roomPersons")
            .innerJoinAndSelect("roomPersons.roomBook", "roomBook")
            .where(query)
            .getMany();
    }

    async save(data: RoomPersons) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "roomPersons",
                innerJoinAndSelect: {
                    roomBook: "roomPersons.roomBook"
                }
            }
        });
    }

    async delete(data: any) {
        //data.active = !data.active;
        return await this.dao.delete(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "roomPersons",
                innerJoinAndSelect: {
                    roomBook: "roomPersons.roomBook"
                }
            }
        });
    }
}

Object.seal(RoomPersonsDAO);
