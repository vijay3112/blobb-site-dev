import { getRepository, Repository } from "typeorm";
import { RoomOrders } from "../../entities/RoomOrders";

export class RoomOrdersDAO {
    private dao: Repository<RoomOrders>;

    constructor() {
        this.dao = getRepository(RoomOrders);
    }

    async search(data: any) {
        let query: any = {};
        if (data.roomBookId) {
            query.roomBook = data.roomBookId;
        }
        return await this.dao
            .createQueryBuilder("roomOrders")
            .innerJoinAndSelect("roomOrders.orders", "orders")
            .innerJoinAndSelect("roomOrders.payment", "payment")
            .innerJoin("roomOrders.roomBook", "roomBook")
            .addSelect(["roomBook.id"])
            .where(query)
            .getMany();
    }

    async save(data: RoomOrders) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "roomOrders",
                innerJoinAndSelect: {
                    orders: "roomOrders.orders",
                    payment: "roomOrders.payment",
                    roomBook: "roomOrders.roomBook"
                }
            }
        });
    }

    async delete(data: string) {
        // data.active = !data.active;
        return await this.dao.delete({ id: data });
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "roomOrders",
                innerJoinAndSelect: {
                    orders: "roomOrders.orders",
                    payment: "roomOrders.payment",
                    roomBook: "roomOrders.roomBook"
                }
            }
        });
    }
}

Object.seal(RoomOrdersDAO);
