import { getRepository, Repository } from "typeorm";
import { PaymentAddon } from "../../entities/PaymentAddon";

export class PaymentAddonDAO {
    private dao: Repository<PaymentAddon>;

    constructor() {
        this.dao = getRepository(PaymentAddon);
    }

    async search(data: any) {
        let query: any = {};
        if (data.paymentId) {
            query.payment = data.paymentId;
        }
        return await this.dao
            .createQueryBuilder("paymentAddon")
            .innerJoin("paymentAddon.payment", "payment")
            .addSelect(["payment.id"])
            .where(query)
            .getMany();
    }

    async save(data: PaymentAddon) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "paymentAddon",
                innerJoinAndSelect: {
                    payment: "paymentAddon.payment"
                }
            }
        });
    }

    async delete(data: any) {
        return await this.dao.delete(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "paymentAddon",
                innerJoinAndSelect: {
                    payment: "paymentAddon.payment"
                }
            }
        });
    }
}

Object.seal(PaymentAddonDAO);
