import { getRepository, Repository } from "typeorm";
import { WebMetadata } from "../../entities/WebMetadata";

export class WebMetadataDAO {
    private dao: Repository<WebMetadata>;

    constructor() {
        this.dao = getRepository(WebMetadata);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("webMetadata")
            .where(data)
            .getMany();
    }

    async save(data: WebMetadata) {
        return await this.dao.save(data);
    }

    async entity(id: any) {
        return await this.dao.findOne(id, {
            join: {
                alias: "webMetadata",
                innerJoinAndSelect: {}
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "webMetadata",
                innerJoinAndSelect: {}
            }
        });
    }
}

Object.seal(WebMetadataDAO);
