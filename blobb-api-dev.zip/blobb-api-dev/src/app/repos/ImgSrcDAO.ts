import { getRepository, Repository } from "typeorm";
import { ImgSrc } from "../../entities/ImgSrc";

export class ImgSrcDAO {
    private dao: Repository<ImgSrc>;

    constructor() {
        this.dao = getRepository(ImgSrc);
    }

    async search(data: any) {
        return await this.dao.find(data);
    }

    async save(data: ImgSrc) {
        if (!data.ref) data.ref = data.id;
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id);
    }

    async delete(data: ImgSrc) {
        return await this.dao.remove([data]);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data);
    }
}

Object.seal(ImgSrcDAO);
