import { getRepository, Repository } from "typeorm";
import { ProfileDocs } from "../../entities/ProfileDocs";

export class ProfileDocsDAO {
    private dao: Repository<ProfileDocs>;

    constructor() {
        this.dao = getRepository(ProfileDocs);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("profileDocs")
            .innerJoinAndSelect("profileDocs.profile", "profile")
            .where(data)
            .getMany();
    }

    async save(data: ProfileDocs) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "profileDocs",
                innerJoinAndSelect: {
                    profile: "profileDocs.profile",
                    fileData: "profileDocs.fileData",
                    img: "profileDocs.img",
                    address: "profileDocs.address"
                }
            }
        });
    }

    async delete(data: any) {
        return await this.dao.remove([data]);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "profileDocs",
                innerJoinAndSelect: {
                    profile: "profileDocs.profile",
                    img: "profileDocs.img",
                    address: "profileDocs.address",
                    fileData: "profileDocs.fileData"
                }
            }
        });
    }
}

Object.seal(ProfileDocsDAO);
