import { getRepository, Repository } from "typeorm";
import { Address } from "../../entities/Address";

export class AddressDAO {
    private dao: Repository<Address>;

    constructor() {
        this.dao = getRepository(Address);
    }

    async search(data: any) {
        return await this.dao.find(data);
    }

    async save(data: Address) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id);
    }

    async delete(data: Address) {
        return await this.dao.remove([data]);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data);
    }
}

Object.seal(AddressDAO);
