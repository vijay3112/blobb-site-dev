import { getRepository, Repository, LessThanOrEqual, MoreThanOrEqual, In, LessThan, Between, Brackets } from "typeorm";
import { RoomBook } from "../../entities/RoomBook";
import { App } from "../../utils/App";

export class RoomBookDAO {
    private dao: Repository<RoomBook>;

    constructor() {
        this.dao = getRepository(RoomBook);
    }

    async search(data: any) {
        console.log(data);
        let cond: any = [];
        let query: any = {};
        if (data) {
            if (data.roomIds) {
                if (data.roomIds && data.roomIds.indexOf(",") > 0) {
                    query.room = In(data.roomIds.split(","));
                } else {
                    query.room = data.roomIds;
                }
            }
            if (data.ids) {
                if (data.ids && data.ids.indexOf(",") > 0) {
                    query.id = In(data.ids.split(","));
                } else {
                    query.id = data.ids;
                }
            }

            query.active = data.isActive == "true" ? true : false;
            //cond.push(query);
            if (data.fromDate && data.toDate) {
                data.fromDate = new Date(data.fromDate);
                data.toDate = new Date(data.toDate);
                //cond.push({ fromDate: Between(data.fromDate, data.toDate) });
                // cond.push({ toDate: Between(data.fromDate, data.toDate) });
                // query.fromDate = Between(data.fromDate, App.DaysBack(data.toDate, -1));
                // query.toDate = Between(data.fromDate, App.DaysBack(data.toDate, -1));
            }
        }
        console.log(query);
        console.log(".................................");
        return await this.dao
            .createQueryBuilder("roomBook")
            .innerJoinAndSelect("roomBook.profile", "profile")
            .innerJoinAndSelect("roomBook.payment", "payment")
            .innerJoinAndSelect("roomBook.room", "room")
            .innerJoinAndSelect("room.property", "property")
            .where(query)
            .andWhere(
                new Brackets(qb => {
                    if (data.fromDate && data.toDate) {
                        qb.where(":fromDate  between roomBook.from_date and roomBook.to_date", { fromDate: data.fromDate });
                        qb.orWhere(" :toDate  between roomBook.from_date and roomBook.to_date", { toDate: data.toDate });
                        qb.orWhere(" roomBook.from_date between :fromDate  and :toDate", { fromDate: data.fromDate, toDate: data.toDate });
                        qb.orWhere(" roomBook.to_date  between :fromDate  and :toDate", { fromDate: data.fromDate, toDate: data.toDate });
                    } else {
                        qb.where("1=1");
                    }
                })
            )
            .getMany();
    }

    async save(data: RoomBook) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "roomBook",
                innerJoinAndSelect: {
                    profile: "roomBook.profile",
                    payment: "roomBook.payment",
                    room: "roomBook.room",
                    property: "room.property"
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        console.log(data);
        return await this.dao.findOne(data, {
            join: {
                alias: "roomBook",
                innerJoinAndSelect: {
                    profile: "roomBook.profile",
                    payment: "roomBook.payment",
                    room: "roomBook.room",
                    property: "room.property"
                }
            }
        });
    }
}

Object.seal(RoomBookDAO);
