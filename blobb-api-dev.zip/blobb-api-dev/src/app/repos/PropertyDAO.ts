import { getRepository, Repository } from "typeorm";
import { Property } from "../../entities/Property";

export class PropertyDAO {

    private dao: Repository<Property>;

    constructor() {
        this.dao = getRepository(Property);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("property")
            .innerJoinAndSelect("property.supervisor", "supervisor")
        
            .innerJoinAndSelect("property.address", "address")
            .where(data)
            .getMany();
    }

    async save(data: Property) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "property",
                innerJoinAndSelect: { 
                    "supervisor": "property.supervisor",
                 
                    "address": "property.address",
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "property",
                innerJoinAndSelect: { 
                    "supervisor": "property.supervisor",
 
                    "address": "property.address",
                }
            }

        });
    }

}

Object.seal(PropertyDAO);
