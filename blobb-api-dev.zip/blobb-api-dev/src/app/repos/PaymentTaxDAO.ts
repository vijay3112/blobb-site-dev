import { getRepository, Repository } from "typeorm";
import { PaymentTax } from "../../entities/PaymentTax";

export class PaymentTaxDAO {

    private dao: Repository<PaymentTax>;

    constructor() {
        this.dao = getRepository(PaymentTax);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("paymentTax") 
            .where(data)
            .getMany();
    }

    async save(data: PaymentTax) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "paymentTax",
                innerJoinAndSelect: {  
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "paymentTax",
                innerJoinAndSelect: {  
                }
            }

        });
    }

}

Object.seal(PaymentTaxDAO);
