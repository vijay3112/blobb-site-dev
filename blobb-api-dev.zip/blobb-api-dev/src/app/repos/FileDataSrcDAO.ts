import { getRepository, Repository } from "typeorm";
import { FileDataSrc } from "../../entities/FileDataSrc";

export class FileDataSrcDAO {
    private dao: Repository<FileDataSrc>;

    constructor() {
        this.dao = getRepository(FileDataSrc);
    }

    async search(data: any) {
        return await this.dao.find(data);
    }

    async save(data: FileDataSrc) {
        if (!data.ref) data.ref = data.id;
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id);
    }

    async delete(data: FileDataSrc) {
        return await this.dao.remove([data]);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data);
    }
}

Object.seal(FileDataSrcDAO);
