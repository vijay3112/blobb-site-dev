import { getRepository, Repository } from "typeorm";
import { Payment } from "../../entities/Payment";

export class PaymentDAO {
    private dao: Repository<Payment>;

    constructor() {
        this.dao = getRepository(Payment);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("payment")
            .where(data)
            .getMany();
    }

    async save(data: Payment) {
        if (!data.ref) data.ref = data.id;
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "payment",
                innerJoinAndSelect: {}
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "payment",
                innerJoinAndSelect: {}
            }
        });
    }
}

Object.seal(PaymentDAO);
