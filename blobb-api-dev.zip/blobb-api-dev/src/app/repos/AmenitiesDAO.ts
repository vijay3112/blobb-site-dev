import { getRepository, Repository } from "typeorm";
import { Amenities } from "../../entities/Amenities";

export class AmenitiesDAO {
  private dao: Repository<Amenities>;

  constructor() {
    this.dao = getRepository(Amenities);
  }

  async search(data: any) {
    return await this.dao
      .createQueryBuilder("amenities")
      .where(data)
      .getMany();
  }

  async save(data: Amenities) {
    return await this.dao.save(data);
  }

  async entity(id: string) {
    return await this.dao.findOne(id, {
      join: {
        alias: "amenities",
        innerJoinAndSelect: {}
      }
    });
  }

  async delete(data: Amenities) {
    data.active = !data.active;
    return await this.dao.save(data);
  }

  async findOne(data: any) {
    return await this.dao.findOne(data, {
      join: {
        alias: "amenities",
        innerJoinAndSelect: {}
      }
    });
  }
}

Object.seal(AmenitiesDAO);
