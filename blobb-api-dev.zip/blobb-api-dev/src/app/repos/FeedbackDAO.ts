import { getRepository, Repository } from "typeorm";
import { Feedback } from "../../entities/Feedback";

export class FeedbackDAO {
    private dao: Repository<Feedback>;

    constructor() {
        this.dao = getRepository(Feedback);
    }

    async search(data: any) {
        let filter: any = {};
        if (data) {
            if (data.param == "all") {
            } else if (data.param == "active") {
                filter.active = true;
            } else if (data.param == "de-active") {
                filter.active = false;
            } else if (data.param) {
                filter.rateUs = data.param;
            }
        }
        console.log(filter);
        return await this.dao
            .createQueryBuilder("feedback")
            .innerJoin("feedback.profile", "profile")
            .where(filter)
            .addSelect(["profile.name", "profile.id"])
            .getMany();
    }

    async save(data: Feedback) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "feedback",
                innerJoinAndSelect: {
                    profile: "feedback.profile"
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "feedback",
                innerJoinAndSelect: {
                    profile: "feedback.profile"
                }
            }
        });
    }
}

Object.seal(FeedbackDAO);
