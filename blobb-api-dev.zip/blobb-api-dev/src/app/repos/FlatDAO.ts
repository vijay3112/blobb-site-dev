import { getRepository, Repository } from "typeorm";
import { Flat } from "../../entities/Flat";

export class FlatDAO {
  private dao: Repository<Flat>;

  constructor() {
    this.dao = getRepository(Flat);
  }

  async search(data: any) {
    return await this.dao
      .createQueryBuilder("flat")
      .innerJoinAndSelect("flat.property", "property")
      .where(data)
      .getMany();
  }

  async save(data: Flat) {
    return await this.dao.save(data);
  }

  async entity(id: string) {
    return await this.dao.findOne(id, {
      join: {
        alias: "flat",
        innerJoinAndSelect: {
          property: "flat.property"
        }
      }
    });
  }

  async delete(data: any) {
    data.active = !data.active;
    return await this.dao.save(data);
  }

  async findOne(data: any) {
    return await this.dao.findOne(data, {
      join: {
        alias: "flat",
        innerJoinAndSelect: {
          property: "flat.property"
        }
      }
    });
  }
}

Object.seal(FlatDAO);
