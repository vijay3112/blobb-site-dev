import { getRepository, Repository } from "typeorm";
import { Img } from "../../entities/Img";

export class ImgDAO {
    private dao: Repository<Img>;

    constructor() {
        this.dao = getRepository(Img);
    }

    async search(data: any) {
        return await this.dao.find(data);
    }

    async save(data: Img) {
        if (!data.ref) data.ref = data.id;
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id);
    }

    async delete(data: Img) {
        return await this.dao.remove([data]);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data);
    }
}

Object.seal(ImgDAO);
