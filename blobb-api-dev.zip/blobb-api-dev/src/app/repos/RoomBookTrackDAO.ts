import { getRepository, Repository, LessThanOrEqual, MoreThanOrEqual, In } from "typeorm";
import { RoomBookTrack } from "../../entities/RoomBookTrack";

export class RoomBookTrackDAO {
    private dao: Repository<RoomBookTrack>;

    constructor() {
        this.dao = getRepository(RoomBookTrack);
    }

    async search(data: any) {
        let query: any = {};
        if (data.roomBookId) {
            query.roomBook = { id: data.roomBookId };
        }

        return await this.dao
            .createQueryBuilder("roomBookTrack")
            .innerJoin("roomBookTrack.roomBook", "roomBook")
            .addSelect(["roomBook.id"])
            .where(query)
            .orderBy("roomBookTrack.updatedOn", "DESC")
            .getMany();
    }

    async save(data: RoomBookTrack) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "roomBook",
                innerJoinAndSelect: {
                    roomBook: "roomBookTrack.roomBook"
                }
            }
        });
    }
}

Object.seal(RoomBookTrack);
