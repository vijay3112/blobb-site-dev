import { getRepository, Repository } from "typeorm";
import { User } from "../../entities/User";

export class UserDAO {
    private dao: Repository<User>;

    constructor() {
        this.run();
    }

    async run() {
        this.dao = await getRepository(User);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("profile")
            .orderBy("profile.updatedOn", "DESC")
            .where(data)
            .andWhere("profile.role != 'SUPER_ADMIN'")
            .getMany();
    }

    async save(data: any) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id);
    }

    async delete(data: User) {
        return await this.dao.remove([data]);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data);
    }
}

Object.seal(UserDAO);
