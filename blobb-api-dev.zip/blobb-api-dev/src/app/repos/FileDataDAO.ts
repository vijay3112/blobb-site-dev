import { getRepository, Repository, In } from "typeorm";
import { FileData } from "../../entities/FileData";

export class FileDataDAO {
    private dao: Repository<FileData>;

    constructor() {
        this.dao = getRepository(FileData);
    }

    async search(data: any) {
        let query: any = {};
        if (data.ref) {
            query.ref = In(data.ref.split(","));
        }
        return await this.dao.find(query);
    }

    async save(data: FileData) {
        if (!data.ref) data.ref = data.id;
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id);
    }

    async delete(data: FileData) {
        return await this.dao.remove([data]);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data);
    }
}

Object.seal(FileDataDAO);
