import { getRepository, Repository, MoreThanOrEqual, LessThanOrEqual, In } from "typeorm";
import { Expenses } from "../../entities/Expenses";

export class ExpensesDAO {
    private dao: Repository<Expenses>;

    constructor() {
        this.dao = getRepository(Expenses);
    }

    async search(data: any) {
        console.log(data);
        let filter: any = {};
        var cond: any = {};
        if (data) {
            if (data.fromDate && data.toDate) {
                cond = `expenses.txn_date >= '${new Date(data.fromDate).toISOString()}'
                    and expenses.txn_date <= '${new Date(data.toDate).toISOString()}'`;
            }
            if (data.selectedBranches) {
                cond = `expenses.txn_date >= '${new Date(data.fromDate).toISOString()}'
                    and expenses.txn_date <= '${new Date(data.toDate).toISOString()}'
                    and expenses.branch in '${data.selectedBranches.split(",")}'`;
            }

            if (data.fromDate) {
                filter.txnDate = MoreThanOrEqual(data.fromDate);
            }
            if (data.toDate) {
                filter.txnDate = LessThanOrEqual(data.toDate);
            }
            if (data.selectedTypes) {
                filter.type = In(data.selectedTypes.split(","));
            }
            if (data.selectedBranches) {
                filter.branch = In(data.selectedBranches.split(","));
            }
        }
        console.log(filter);
        return await this.dao
            .createQueryBuilder("expenses")
            .innerJoinAndSelect("expenses.type", "type")
            .where(cond)
            .getMany();
    }

    async save(data: Expenses) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "expenses",
                innerJoinAndSelect: {
                    type: "expenses.type",
                    fileData: "expenses.fileData"
                }
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "expenses",
                innerJoinAndSelect: {
                    type: "expenses.type",
                    fileData: "expenses.fileData"
                }
            }
        });
    }
}

Object.seal(ExpensesDAO);
