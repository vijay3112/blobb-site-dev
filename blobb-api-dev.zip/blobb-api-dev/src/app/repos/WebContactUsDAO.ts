import { getRepository, Repository } from "typeorm";
import { WebContactUs } from "../../entities/WebContactUs";

export class WebContactUsDAO {
    private dao: Repository<WebContactUs>;

    constructor() {
        this.dao = getRepository(WebContactUs);
    }

    async search(data: any) {
        return await this.dao
            .createQueryBuilder("webContactUs")
            .where(data)
            .orderBy("active", "DESC")
            //.addOrderBy("updatedOn", "DESC")
            .getMany();
    }

    async save(data: WebContactUs) {
        return await this.dao.save(data);
    }

    async entity(id: string) {
        return await this.dao.findOne(id, {
            join: {
                alias: "webContactUs",
                innerJoinAndSelect: {}
            }
        });
    }

    async delete(data: any) {
        data.active = !data.active;
        return await this.dao.save(data);
    }

    async findOne(data: any) {
        return await this.dao.findOne(data, {
            join: {
                alias: "webContactUs",
                innerJoinAndSelect: {}
            }
        });
    }
}

Object.seal(WebContactUsDAO);
