import { App } from "../../utils/App";
import { Img } from "../../entities/Img";
import { ImgSrcDAO } from "../repos/ImgSrcDAO";
import { Props } from "../../constants/Props";
import { ImgSrc } from "../../entities/ImgSrc";

export class ImgService {
    public sessionInfo: any;
    private imgSrcDao: ImgSrcDAO;

    constructor() {
        this.imgSrcDao = new ImgSrcDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.imgSrcDao.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: ImgSrc) {
        try {
            if (await this.validate(item)) {
                let imgData: any = await this.imgSrcDao.save(item);
                let returnData = {
                    id: item.id,
                    message: Props.SAVED_SUCCESSFULLY
                };
                return returnData;
            } else {
                let returnData = { message: Props.INVALID_DATA };
                throw returnData;
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: ImgSrc = await this.imgSrcDao.entity(id);
            let result: any = await this.imgSrcDao.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return Promise.resolve(returnData);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async validate(item: Img) {
        if (!item.id || item.id == "" || item.id == "0") {
            let uid = App.UniqueNumber();
            item.id = uid;
        }
        return true;
    }
}
