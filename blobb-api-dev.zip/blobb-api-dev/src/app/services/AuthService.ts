import { UserDAO } from "../repos/UserDAO";
import { AccessMenuDAO } from "../repos/AccessMenuDAO";
import { ProfileService } from "./ProfileService";

import { generate } from "randomstring";

import { App } from "../..//utils/App";
import { Props } from "../../constants/Props";
import * as Config from "../../utils/Config";
import { User } from "../../entities/User";

export class AuthService {
    public sessionInfo: any;
    private userDAO: UserDAO;
    private accessMenuDAO: AccessMenuDAO;
    private profileService: ProfileService;
    private providers: any;


    constructor() {
        this.userDAO = new UserDAO();
        this.accessMenuDAO = new AccessMenuDAO();
        this.profileService = new ProfileService();
        this.providers = {
            email: "email",
            facebook: "facebook",
            google: "google",
            linkedin: "linkedin"
        };
       
    }

    retrieve(reqData: any): any {
        console.log(reqData.provider);
        switch (reqData.provider) {
            case "email": {
                return this.sendEmailResponse(reqData);
            }
            case "facebook": {
                return this.sendSocailResponse(reqData);
            }
            case "google": {
                return this.sendSocailResponse(reqData);
            }
            case "linkedin": {
                return this.sendSocailResponse(reqData);
            }
            default: {
                return this.sendEmailResponse(reqData);
            }
        }
    }

    async signup(reqData: any) {
        this.profileService.sessionInfo = { id: "system" };
        const newAccount: User = new User();
        newAccount.id = null;
        newAccount.role = "USER";
        newAccount.password = "0";
        newAccount.mobile = reqData.mobile ? reqData.mobile : App.UniqueNumber();
        // newAccount.address = new Address();
        // newAccount.img = new Img();
        if (reqData.email) {
            newAccount.email = reqData.email;
        } else {
            reqData.email = reqData.userid;
            newAccount.email = reqData.userid;
        }

        if (reqData.password) {
            newAccount.password = reqData.password;
        }
        if (reqData.name) {
            newAccount.name = reqData.name;
        } else {
            newAccount.name = reqData.email.substring(0, reqData.email.indexOf("@"));
        }
        try {
            let data = await this.profileService.saveUser(newAccount, true);
            if (reqData.provider == "facebook" || reqData.provider == "google") {
                data = await this.reteriveProfileDetails(data.id);
            }

            return Promise.resolve(data);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async reteriveProfileDetails(userid: any) {
        try {
            var responseData: any = {};
            let query = { id: userid };

            var accountObj: User = await this.userDAO.findOne(query);
            if (accountObj != null) {
                responseData.user = {};
                responseData.user.id = accountObj.id;
                responseData.user.role = accountObj.role;
                responseData.user.name = accountObj.name;
                responseData.user.email = accountObj.email;
                responseData.user.mobile = accountObj.mobile;
                responseData.user.active = accountObj.active;
                responseData.user.status = accountObj.status;
                responseData.identity = {};
                responseData.identity = responseData.user;
                delete responseData.user;

                responseData.access_token = App.EncodeJWT(responseData);
                responseData.refresh_token = App.RefreshJWT(responseData);
            } else {
                return Promise.reject({
                    message: "Didn't find any profile with the provided email "
                });
            }
            return Promise.resolve(responseData);
        } catch (error) {
            return Promise.reject(error);
        }
    }
    async refreshToken(inputData: any) {
        try {
            if (!inputData) throw { message: "Invalid Data" };
            var responseData: any = {};
            let jwtData: any = App.DecodeJWT(inputData.jwt);
            if (!jwtData) throw { message: "Invalid JWT" };
            responseData.identity = jwtData.identity;
            responseData.access_token = App.EncodeJWT(responseData);
            return Promise.resolve(responseData);
        } catch (error) {
            throw error;
        }
    }
    async sendEmailResponse(reqData: any) {
        let isVid: boolean = true;
        if (reqData.username) {
            let dataList = reqData.username.split("-");
            if (dataList.length > 1) {
                reqData.vid = dataList[0];
                reqData.userid = dataList[1];
            } else {
                isVid = false;
                reqData.userid = reqData.username ? reqData.username : reqData.userid;
            }
        }

        var responseData: any = {};
        let query: any = {};
        if (!isNaN(reqData.userid) && reqData.userid > 9) {
            query = { mobile: reqData.userid };
        } else {
            query = { email: reqData.userid };
        }
        if (isVid) {
            query["vid"] = reqData.vid;
        }

        console.log("---------query------------");
        console.log(query);
        var profileObj: User = await this.userDAO.findOne(query);
        if (profileObj == null) {
            return Promise.reject({ message: "Invalid Credientials" });
        } else {
            if (profileObj.id == "SUPER_ADMIN") {
                profileObj.password = App.HashSync(profileObj.password);
            }
            console.log(profileObj);
            console.log(reqData);
            let auth = false;
            if (reqData.provider == "email") {
                auth = App.HashCompareSync(reqData.password, profileObj.password);
            }
            console.log("Auth: " + auth);
            if (auth == true) {
                if (profileObj.active == true) {
                    return this.reteriveProfileDetails(profileObj.id);
                } else {
                    return Promise.reject({
                        message: "Account De-activated Contact Admin"
                    });
                }
            } else {
                return Promise.reject({ message: "Invalid Username/Password" });
            }
        }
    }

    async VerifyEmail(reqData: any) {
        try {
            var responseData: any = {};
            var profileObjList: User[] = await this.userDAO.search({
                email: reqData.userid
            });
            let profileObj: User = profileObjList[0];
            console.log(profileObj);
            if (profileObj != null) {
                return Promise.resolve(profileObj);
            } else {
                return Promise.resolve(null);
            }
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async sendSocailResponse(reqData: any) {
        try {
            var responseData: any = {};
            var profileObj: any = await this.userDAO.search({
                email: reqData.username
            });
            profileObj = profileObj[0];
            if (profileObj != null) {
                return this.reteriveProfileDetails(profileObj.id);
            }

            // else {
            //   return this.signup(reqData);
            // }
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async forgotPassword(reqData: any) {
        try {
            let query: any = {};
            if (!isNaN(reqData.userid) && reqData.userid > 9) {
                query = { mobile: reqData.userid };
            } else {
                query = { email: reqData.userid };
            }
            if (reqData.vid) {
                query.vid = reqData.vid;
            }
            console.log(query);
            const uname = await this.userDAO.findOne(query);
            //Generating Random Token
            if (uname == null || uname == undefined) {
                return Promise.reject("Please enter a valid/registered mail ID");
            }
            if (!uname.active) {
                return Promise.reject("Your account has been deactivated , Contact support for further Assistence");
            }
            console.log(uname);
            const tok = generate({ length: 4, charset: "numeric" });
            console.log(tok);
            uname.token = tok;
            let data: any = await this.userDAO.save(uname);
            let rednderData = { name: uname.name, token: uname.token };
            if(data){
                let mailConfim = await App.SendMail(uname.email, "Password Reset Link", "OtpSend", rednderData);
                console.log(mailConfim);
                return Promise.resolve(mailConfim);
           
            // const mailOptions = {
            //     from: Config.mailOptions.user,
            //     to: uname.email,
            //     subject: "Password Reset Link",
            //     html: App.HtmlRender("OtpSend", {
            //         data: { name: uname.name, token: uname.token }
            //     })
            // };
            // if (data) {
            //     this.transporter.sendMail(mailOptions, (err: any, info: any) => {
            //         if (err) {
            //             return Promise.reject(err);
            //         }
            //         console.log(info);
            //     });

            //     return Promise.resolve({
            //         message: "Code has been sent successfully"
            //     });
                
            } else {
                return Promise.reject({
                    message: "Technical issue in sending reset link, Sorry for Inconvience"
                });
            }
        } catch (error) {
            return Promise.reject({
                message: "Technical issue in sending reset link, Sorry for Inconvience"
            });
        }
    }

    async resetPassword(reqData: any) {
        try {
            let query: any = {};
            if (!isNaN(reqData.userid) && reqData.userid > 9) {
                query = { mobile: reqData.userid, token: reqData.token };
            } else {
                query = { email: reqData.userid, token: reqData.token };
            }
            if (reqData.vid) {
                query.vid = reqData.vid;
            }
            let data: any = await this.userDAO.findOne(query);
            if (data) {
                data.token = null;
                data.password = App.HashSync(reqData.password);
                let newData: any = await this.userDAO.save(data);
                return Promise.resolve({
                    message: "New Password Set Successfully"
                });
            } else {
                return Promise.reject({ message: "Invalid Token" });
            }
        } catch (error) {
            return Promise.reject({
                message: "Technical issue in Resetting Password, Sorry for Inconvience"
            });
        }
    }
}
