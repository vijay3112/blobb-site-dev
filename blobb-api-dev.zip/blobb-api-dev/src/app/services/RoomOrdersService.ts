import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { RoomOrders } from "../../entities/RoomOrders";
import { RoomOrdersDAO } from "./../repos/RoomOrdersDAO";
import { Payment } from "../../entities/Payment";
import { PaymentDAO } from "../repos/PaymentDAO";

export class RoomOrdersService {
    public sessionInfo: any;
    private roomOrdersDAO: RoomOrdersDAO;
    private paymentDAO: PaymentDAO;

    constructor() {
        this.roomOrdersDAO = new RoomOrdersDAO();
        this.paymentDAO = new PaymentDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.roomOrdersDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        try {
            let data: any = await this.roomOrdersDAO.search(item);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: RoomOrders) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                await this.paymentDAO.save(item.payment);
                let roomOrdersData: any = await this.roomOrdersDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            }
            if (cond == "name") {
                throw { message: Props.RECORD_EXISTS };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            // let data: RoomOrders = await this.roomOrdersDAO.entity(id);
            // data.updatedBy = this.sessionInfo.id;
            let result: any = await this.roomOrdersDAO.delete(id);

            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: RoomOrders) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.roomOrdersDAO.entity(item.id);
        }
        //  let condData = await this.roomOrdersDAO.search({ name: item.name });
        if (!item.id) {
            // if (condData.length > 0) {
            //     return "name";
            // } else {
            let uid = App.UniqueNumber();
            item.id = uid;
            if (!item.payment) {
                item.payment = new Payment();
            }
            item.payment.id = uid;
            item.payment.refType = "OrderService";
            //
        } else {
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            // if(oldItem.name != item.name){
            //     if (condData.length > 0) {
            //         return "name";
            //     }
            // }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
