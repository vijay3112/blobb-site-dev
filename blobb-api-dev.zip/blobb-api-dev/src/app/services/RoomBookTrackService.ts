import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { RoomBookTrack } from "../../entities/RoomBookTrack";
import { RoomBookTrackDAO } from "./../repos/RoomBookTrackDAO";

export class RoomBookTrackService {
    public sessionInfo: any;
    private roomBookTrackDAO: RoomBookTrackDAO;

    constructor() {
        this.roomBookTrackDAO = new RoomBookTrackDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.roomBookTrackDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(params: any) {
        try {
            let data: any = await this.roomBookTrackDAO.search(params);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: RoomBookTrack) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                await this.roomBookTrackDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
        } catch (error) {
            throw error;
        }
    }

    async validate(item: RoomBookTrack) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.roomBookTrackDAO.entity(item.id);
        }
        if (!item.id) {
            let uid = App.UniqueNumber();
            item.id = uid;
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
