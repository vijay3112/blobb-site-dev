import { App } from "../../utils/App";
import { FileData } from "../../entities/FileData";
import { FileDataSrcDAO } from "../repos/FileDataSrcDAO";
import { Props } from "../../constants/Props";
import { FileDataSrc } from "../../entities/FileDataSrc";
import { FileDataDAO } from "../repos/FileDataDAO";

export class FileDataService {
    public sessionInfo: any;
    private fileDataSrcDao: FileDataSrcDAO;
    private fileDataDAO: FileDataDAO;

    constructor() {
        this.fileDataSrcDao = new FileDataSrcDAO();
        this.fileDataDAO = new FileDataDAO();
    }
    async search(filter: string) {
        try {
            let data: any = await this.fileDataDAO.search(filter);
            return data;
        } catch (error) {
            throw error;
        }
    }
    async entity(id: string) {
        try {
            let data: any = await this.fileDataSrcDao.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: FileDataSrc) {
        try {
            if (await this.validate(item)) {
                let fileDataData: any = await this.fileDataSrcDao.save(item);
                let returnData = {
                    id: item.id,
                    message: Props.SAVED_SUCCESSFULLY
                };
                return returnData;
            } else {
                let returnData = { message: Props.INVALID_DATA };
                throw returnData;
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: FileDataSrc = await this.fileDataSrcDao.entity(id);
            let result: any = await this.fileDataSrcDao.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return Promise.resolve(returnData);
        } catch (error) {
            return Promise.reject(error);
        }
    }

    async validate(item: FileData) {
        if (!item.id || item.id == "" || item.id == "0") {
            let uid = App.UniqueNumber();
            item.id = uid;
        }
        return true;
    }
}
