import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { WebContactUs } from "../../entities/WebContactUs";
import { WebContactUsDAO } from "../repos/WebContactUsDAO";

export class WebContactUsService {
    public sessionInfo: any;
    private WebContactUsDAO: WebContactUsDAO;

    constructor() {
        this.WebContactUsDAO = new WebContactUsDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.WebContactUsDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        let query: any = {};
        if (item.active) {
            query.active = item.active == "true" || item.active == true ? true : false;
        }

        try {
            let data: any = await this.WebContactUsDAO.search(query);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: WebContactUs) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                let webContactUsData: any = await this.WebContactUsDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            } else if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            } else if (cond == "name") {
                throw { message: Props.RECORD_EXISTS };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: WebContactUs = await this.WebContactUsDAO.entity(id);
            if (!data) throw { message: Props.RECORD_NOT_EXISTS };
            data.updatedBy = this.sessionInfo.id;
            let result: any = await this.WebContactUsDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: WebContactUs) {
        let previousItem: any = null;
        if (!item.id || item.id.toString() == "" || item.id.toString() == "0") {
            item.id = null;
        } else {
            previousItem = await this.WebContactUsDAO.entity(item.id);
        }
        // let condData = await this.WebContactUsDAO.search({ name: item.name });
        if (!item.id) {
            // if (condData.length > 0) {
            //     return "name";
            // } else {
            let uid = App.UniqueCode();
            item.id = uid;
            // item.createdBy = this.sessionInfo.id;
            // item.createdOn = new Date(App.DateNow());
            // }
        } else {
            if (item.updatedOn && previousItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            // if(oldItem.name != item.name) {
            //    if (condData.length > 0) {
            //        return "name";
            //    }
            // }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date(App.dateNow());
        return true;
    }
}
