import { App } from "../../utils/App";
import { Profile } from "../../entities/Profile";
import { ProfileDAO } from "../repos/ProfileDAO";

import { Props } from "../../constants/Props";

import { User } from "../../entities/User";
import { UserDAO } from "../repos/UserDAO";

export class ProfileService {
    public sessionInfo: any;
    private profileDao: ProfileDAO;

    private userDAO: UserDAO;

    constructor() {
        this.profileDao = new ProfileDAO();
        this.userDAO = new UserDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.profileDao.entity(id);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(reqData: any) {
        try {
            let data: any = await this.profileDao.search(reqData);
            return data;
        } catch (error) {
            return error;
        }
    }

    async save(item: Profile, isInsert: boolean) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                let profileData: any = await this.profileDao.save(item);
                let returnData = {
                    id: item.id,
                    message: Props.SAVED_SUCCESSFULLY
                };
                return returnData;
            } else if (cond == "Email") {
                let returnData = { message: Props.EMAIL_EXISTS };
                throw returnData;
            } else if (cond == "Mobile") {
                let returnData = { message: Props.MOBILE_EXISTS };
                throw returnData;
            }
        } catch (error) {
            throw error;
        }
    }

    async saveUser(item: User, isInsert: boolean) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                if (item.password && isInsert) {
                    item.password = App.HashSync(item.password);
                } else if (isInsert) {
                    item.password = "00000000";
                }

                let profileData: any = await this.userDAO.save(item);
                let returnData = {
                    id: item.id,
                    message: Props.SAVED_SUCCESSFULLY
                };
                return returnData;
            } else if (cond == "Email") {
                let returnData = { message: Props.EMAIL_EXISTS };
                throw returnData;
            } else if (cond == "Mobile") {
                let returnData = { message: Props.MOBILE_EXISTS };
                throw returnData;
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: Profile = await this.profileDao.entity(id);
            let result: any = await this.profileDao.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            return error;
        }
    }

    async changePassword(reqData: any) {
        try {
            console.log(reqData);
            let data: any = await this.userDAO.entity(reqData.id);
            console.log(data);
            if (data) {
                let check = App.HashCompareSync(reqData.oldPassword, data.password);
                console.log(check);
                if (check) {
                    let pwd = App.HashSync(reqData.newPassword);
                    let newPassword = { id: reqData.id, password: pwd };
                    console.log(newPassword);
                    let newData: any = await this.userDAO.save(newPassword);
                    return Promise.resolve("New Password Set Successfully");
                } else {
                    return Promise.reject("Invalid Password");
                }
            } else {
                return Promise.reject("Invalid User");
            }
        } catch (error) {
            return Promise.reject("Technical issue in Resetting Password, Sorry for Inconvience");
        }
    }

    async validate(item: any) {
        let previousData = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            previousData = await this.profileDao.findOne(item.id);
        }
        item.updatedBy = this.sessionInfo.id;
        let data = await this.profileDao.search({ email: item.email });
        let mdata = await this.profileDao.search({ mobile: item.mobile });
        if (!item.id) {
            if (data.length > 0) {
                return "Email";
            } else if (mdata.length > 0) {
                return "Mobile";
            } else {
                let uid = App.UniqueID(item.name, null);
                item.id = uid;
            }
        } else {
            if (item.email != previousData.email) {
                if (data.length > 0) {
                    return "Email";
                }
            }
            if (item.mobile != previousData.mobile) {
                if (mdata.length > 0) {
                    return "Mobile";
                }
            }
        }

        return true;
    }
}
