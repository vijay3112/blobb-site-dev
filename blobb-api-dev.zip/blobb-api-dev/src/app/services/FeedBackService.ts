import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { Feedback } from "../../entities/Feedback";
import { FeedbackDAO } from "./../repos/FeedbackDAO";

export class FeedbackService {
    public sessionInfo: any;
    private feedbackDAO: FeedbackDAO;

    constructor() {
        this.feedbackDAO = new FeedbackDAO();
    }
    async entity(id: string) {
        try {
            let data: any = await this.feedbackDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(filters: any) {
        try {
            let data: any = await this.feedbackDAO.search(filters);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: Feedback) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                let feedbackData: any = await this.feedbackDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            }
            if (cond == "name") {
                throw { message: Props.RECORD_EXISTS };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: Feedback = await this.feedbackDAO.entity(id);
            data.updatedBy = this.sessionInfo.id;
            let result: any = await this.feedbackDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: Feedback) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.feedbackDAO.entity(item.id);
        }
        //let condData = await this.rateDAO.search({ name: item.name });
        if (!item.id) {
            // if (condData.length > 0) {
            //     return "name";
            // } else {
            let uid = App.UniqueNumber();
            item.id = uid;
            // }
        } else {
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            // if(oldItem.name != item.name){
            //     if (condData.length > 0) {
            //         return "name";
            //     }
            // }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
