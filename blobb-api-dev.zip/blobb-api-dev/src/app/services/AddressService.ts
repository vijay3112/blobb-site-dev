import { App } from "../../utils/App";
import { Address } from "../../entities/Address";
import { AddressDAO } from "../repos/AddressDAO";
import { Props } from "../../constants/Props";

export class AddressService {
    public sessionInfo: any;
    private addressDao: AddressDAO;

    constructor() {
        this.addressDao = new AddressDAO();
    }

    async save(item: Address) {
        try {
            if ((await this.validate(item)) == true) {
                let addressDao: any = await this.addressDao.save(item);
                let returnData = {
                    id: item.id,
                    message: Props.SAVED_SUCCESSFULLY
                };
                return returnData;
            } else {
                let returnData = {
                    message: Props.INVALID_DATA
                };
                throw returnData;
            }
        } catch (error) {
            throw error;
        }
    }

    async validate(item: Address) {
        let previousData = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        }
        if (item.id == null) {
            return false;
        }

        return true;
    }
}
