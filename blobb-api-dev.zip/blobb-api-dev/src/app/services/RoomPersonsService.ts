import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { RoomPersons } from "../../entities/RoomPersons";
import { RoomPersonsDAO } from "./../repos/RoomPersonsDAO";
import { FileDataDAO } from "../repos/FileDataDAO";
import { ImgDAO } from "../repos/ImgDAO";
import { FileData } from "../../entities/FileData";
import { Img } from "../../entities/Img";

export class RoomPersonsService {
    public sessionInfo: any;
    private roomPersonsDAO: RoomPersonsDAO;
    private fileDataDAO: FileDataDAO;
    private imgDAO: ImgDAO;

    constructor() {
        this.roomPersonsDAO = new RoomPersonsDAO();
        this.fileDataDAO = new FileDataDAO();
        this.imgDAO = new ImgDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.roomPersonsDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        try {
            let data: any = await this.roomPersonsDAO.search(item);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: RoomPersons) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                await this.imgDAO.save(item.img);
                await this.fileDataDAO.save(item.fileData);
                let roomPersonsData: any = await this.roomPersonsDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            }
            if (cond == "name") {
                throw { message: Props.RECORD_EXISTS };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let result: any = await this.roomPersonsDAO.delete(id);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: RoomPersons) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.roomPersonsDAO.entity(item.id);
        }
        //  let condData = await this.roomPersonsDAO.search({ name: item.name });
        if (!item.id) {
            // if (condData.length > 0) {
            //     return "name";
            // } else {
            let uid = App.UniqueNumber();
            item.id = uid;
            if (!item.fileData) {
                item.fileData = new FileData();
            }
            item.fileData.id = uid;

            if (!item.img) {
                item.img = new Img();
            }
            item.img.id = uid;
            // }
        } else {
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            // if(oldItem.name != item.name){
            //     if (condData.length > 0) {
            //         return "name";
            //     }
            // }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
