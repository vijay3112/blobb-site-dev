import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { Property } from "../../entities/Property";
import { PropertyDAO } from "./../repos/PropertyDAO";
import { Address } from "../../entities/Address";
import { AddressDAO } from "./../repos/AddressDAO";
import { RawQuery } from "../common/RawQuery";

export class PropertyService {
    public sessionInfo: any;
    private propertyDAO: PropertyDAO;
    private addressDAO: AddressDAO;

    constructor() {
        this.propertyDAO = new PropertyDAO();
        this.addressDAO = new AddressDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.propertyDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        try {
            item.vid = this.sessionInfo.vid;
            let data: any = await this.propertyDAO.search(item);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: Property) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                let addressData = await this.addressDAO.save(item.address);

                await RawQuery.SeqNew(item.type);
                let propertyData: any = await this.propertyDAO.save(item);

                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: Property = await this.propertyDAO.entity(id);
            data.updatedBy = this.sessionInfo.id;
            let result: any = await this.propertyDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: Property) {
        let oldItem: any = null;

        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.propertyDAO.entity(item.id);
        }
        if (!item.id) {
            let uid = App.UniqueNumber();
            item.id = uid;
            if (!item.address) {
                item.address = new Address();
            }
            item.address.id = uid;
        } else {
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            if (oldItem.type == item.type) {
                console.log(item.type);
                return "The Property CODE Cannot be changed.";
            }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
