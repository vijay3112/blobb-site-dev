import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { CorporateBooking } from "../../entities/CorporateBooking";
import { CorporateBookingDAO } from "../repos/CorporateBookingDAO";

export class CorporateBookingService {
    public sessionInfo: any;
    private CorporateBookingDAO: CorporateBookingDAO;

    constructor() {
        this.CorporateBookingDAO = new CorporateBookingDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.CorporateBookingDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        try {
            let data: any = await this.CorporateBookingDAO.search(item);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: CorporateBooking) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                let data: any = await this.CorporateBookingDAO.save(item);
                let returnData = {
                    id: item.id,
                    message: Props.SAVED_SUCCESSFULLY
                };
                return returnData;
            } else if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
      
            }
        } catch (error) {
            throw error;
        }

       
    }

    async delete(id: any) {
        try {
            let data: any = await this.CorporateBookingDAO.entity(id);
            data.updatedBy = this.sessionInfo.id;
            let result: any = await this.CorporateBookingDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: CorporateBooking) {
        let previousData = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            previousData = await this.CorporateBookingDAO.entity(item.id);
        }

        if (!item.id) {
            let uid = App.UniqueNumber();
            item.id = uid;
            item.createdBy = this.sessionInfo.id;
            item.createdOn = new Date();
        } else {
            if (item.updatedOn && previousData.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
