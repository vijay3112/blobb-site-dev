import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { RoomBook } from "../../entities/RoomBook";
import { RoomBookDAO } from "./../repos/RoomBookDAO";
import { PaymentDAO } from "./../repos/PaymentDAO";
import { Payment } from "../../entities/Payment";
import { Room } from "../../entities/Room";
import { RoomDAO } from "../repos/RoomDAO";
import { RoomBookTrackDAO } from "../repos/RoomBookTrackDAO";
import { RoomBookTrack } from "../../entities/RoomBookTrack";
import { Flat } from "../../entities/Flat";
import { PaymentAddonDAO } from "../repos/PaymentAddonDAO";
import { RawQuery } from "../common/RawQuery";

export class RoomBookService {
    public sessionInfo: any;
    private roomBookDAO: RoomBookDAO;
    private paymentDAO: PaymentDAO;
    private roomDAO: RoomDAO;
    private roomBookTrackDAO: RoomBookTrackDAO;
    private paymentAddonDAO: PaymentAddonDAO;

    constructor() {
        this.roomBookDAO = new RoomBookDAO();
        this.paymentDAO = new PaymentDAO();
        this.roomDAO = new RoomDAO();
        this.roomBookTrackDAO = new RoomBookTrackDAO();
        this.paymentAddonDAO = new PaymentAddonDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.roomBookDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(params: any) {
        try {
            let roomData: Room[] = await this.roomDAO.search({ propertyIds: params.propertyIds });
            if (params.propertyIds) {
                params.roomIds = App.ArrayJoin(roomData, "id");
                console.log(params);
                if (params.roomIds == "") {
                    return [];
                }
            }
            let data: any = await this.roomBookDAO.search(params);
            // let data: any = await this.roomBookDAO.search(item);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async avalibleRooms(filter: any) {
        try {
            let data: any = [];
            let index = -1;
            if (!filter.fromDate || !filter.toDate) {
                throw { message: "From Date and To Date is required" };
            }
            let roomList: Room[] = await this.roomDAO.search({ propertyIds: filter.propertyIds });
            /** geting unique flats */
            let flats: any[] = [];
            roomList.forEach(element => {
                index = flats.findIndex(item => item.id == element.flat.id);
                if (index < 0) {
                    flats.push(Object.assign({}, element.flat));
                }
            });
            filter.roomIds = App.ArrayJoin(roomList, "id");
            filter.isActive = "true";
            /** list of rooms booked  */
            let bookedRoomList: RoomBook[] = await this.roomBookDAO.search(filter);

            bookedRoomList.forEach((item: RoomBook) => {
                index = roomList.findIndex(obj => obj.id == item.room.id);
                if (index > -1) {
                    roomList[index].isLock = true;
                }
            });
            flats.forEach((item: Flat) => {
                item.rooms = roomList.filter((room: Room) => room.flat.id == item.id);
                if (item.rooms[0]) {
                    item.property = item.rooms[0].property;
                }
            });
            // TO-DO locks room remove
            //data = roomList.filter((value: Room) => !bookedRoomList.find((item: RoomBook) => value.id == item.room.id));
            return flats;
        } catch (error) {
            throw error;
        }
    }

    async save(item: RoomBook) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                if ([Props.TRACK_STATUS_BOOKING].includes(item.status)) {
                    await this.paymentDAO.save(item.payment);
                    await item.payment.paymentAddonList.forEach(async element => {
                        await this.paymentAddonDAO.save(element);
                    });
                }
                if (item.status == Props.TRACK_STATUS_COMPLETE || item.status == Props.TRACK_STATUS_REFUND) {
                    item.active = false;
                    if (item.status == Props.TRACK_STATUS_COMPLETE) {
                        item.invoiceOrder = await RawQuery.SeqRec(item.room.property.type, item.showGst ? "IN" : "CH");
                        //if(item.)
                        item.invoiceService = await RawQuery.SeqRec(item.room.property.type, "SR");
                    } else if (item.status == Props.TRACK_STATUS_REFUND) {
                        item.invoiceOrder = await RawQuery.SeqRec(item.room.property.type, "DN");
                    }
                }
                let roomBookData: any = await this.roomBookDAO.save(item);
                await this.roomBookTrackDAO.save(this.roomBookTrackEntity(item));
                let returnData = { entity: await this.roomBookDAO.entity(item.id), message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            }
            if (cond == "name") {
                throw { message: Props.RECORD_EXISTS };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async bookRooms(items: RoomBook[]) {
        try {
            //await items.forEach(async (item: RoomBook) => {
            let listOfRoomsIds: string[] = [];
            let data: any = {
                bookingDate: new Date().toISOString(),
                bookingRef: items[0].id,
                name: items[0].profile.name,
                email: items[0].profile.email,
                mobile: items[0].profile.mobile,
                flatNo: items[0].room.flat.name,
                roomNo: items[0].room.name,
                roomPersons: items[0].room.persons,
                propertyName: items[0].room.property.name,
                paymentMode: "ONLINE",
                paymentAmount: 0,
                cgstPrice: items[0].cgstPrice,
                sgstPrice: items[0].sgstPrice,
                cgstPercent: items[0].payment.cgst,
                sgstPercent: items[0].payment.sgst,
                totalAmount: items[0].payment.amount,
                price: items[0].payment.price,
                units: items[0].payment.units,
                cost: items[0].payment.cost,
                advanceAmount: items[0].advance,
                checkIn: items[0].fromDate.toLocaleString(),
                checkOut: items[0].toDate.toLocaleString()
            };
            console.table(data);
            console.table(listOfRoomsIds);

            for (let item of items) {
                await this.save(item);
                listOfRoomsIds.push(item.id);
                data.bookingRef = data.bookingRef ? data.bookingRef + "," + item.id : item.id;
                data.paymentAmount = data.paymentAmount + item.payment.amount;
            }
            data.list = [...items];
            console.table(data.list);
            if (data) {
                console.table(data);
                data.bookingDate = data.bookingDate.slice(0, 10);

                let mailConfimation = await App.SendMail(data.email, `Blobb Booking confirmation id: ${data.bookingRef}`, "EmailConfirm", data);
                console.log(mailConfimation);
            }
            // });
            console.log("**************** BookRoomIds ******************");
            console.log(listOfRoomsIds.join(","));
            return { data: data, message: Props.SAVED_SUCCESSFULLY };
        } catch (error) {
            throw error;
        }
    }

    async invoiceRooms(param: any) {
        param.isActive = "true";
        let data: RoomBook[] = await this.roomBookDAO.search(param);
        console.log(data);
        return data;
    }

    async delete(id: any) {
        try {
            let data: RoomBook = await this.roomBookDAO.entity(id);
            data.updatedBy = this.sessionInfo.id;
            let result: any = await this.roomBookDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: RoomBook) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.roomBookDAO.entity(item.id);
        }
        if (!item.id) {
            let uid = App.UniqueNumber();
            item.id = uid;
            if (!item.payment) {
                item.payment = new Payment();
            }
            item.payment.id = uid;
            item.payment.refType = "RoomBook";
            item.payment.ref = uid;
            item.createdBy = this.sessionInfo.id;
            item.createdOn = new Date();
            if (item.payment.paymentAddonList && item.payment.paymentAddonList.length > 0) {
                item.payment.paymentAddonList.forEach(element => {
                    if (!element.payment) {
                        element.payment = new Payment();
                    }
                    element.id = item.payment.id + "_" + App.UniqueNumber();
                    element.payment.id = item.payment.id;
                    element.summary = "init";
                    element.updatedBy = this.sessionInfo.id;
                    element.updatedOn = new Date();
                });
            }
        } else {
            console.log(oldItem.updatedOn.toISOString() + " == " + item.updatedOn);
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }

    roomBookTrackEntity(item: RoomBook) {
        let roomBookTrack: RoomBookTrack = new RoomBookTrack();
        roomBookTrack.status = item.status;
        roomBookTrack.updatedBy = item.updatedBy;
        roomBookTrack.updatedOn = item.updatedOn;
        if (!roomBookTrack.roomBook) {
            roomBookTrack.roomBook = new RoomBook();
        }
        roomBookTrack.roomBook.id = item.id;
        roomBookTrack.id = item.id + "_" + App.UniqueNumber();
        return roomBookTrack;
    }
}
