import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { Orders } from "../../entities/Orders";
import { OrdersDAO } from "./../repos/OrdersDAO";
import { PaymentTax } from "../../entities/PaymentTax";
import { PaymentTaxDAO } from "../repos/PaymentTaxDAO";

export class OrdersService {
    public sessionInfo: any;
    private ordersDAO: OrdersDAO;
    private paymentTaxDAO: PaymentTaxDAO;
    constructor() {
        this.paymentTaxDAO = new PaymentTaxDAO();
        this.ordersDAO = new OrdersDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.ordersDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        try {
            let query: any = {};
            if (item.propertyId) {
                query.property = { id: item.propertyId };
            }
            let data: any = await this.ordersDAO.search(query);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: Orders) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                await this.paymentTaxDAO.save(item.paymentTax);
                let ordersData: any = await this.ordersDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: Orders = await this.ordersDAO.entity(id);
            data.updatedBy = this.sessionInfo.id;
            let result: any = await this.ordersDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: Orders) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.ordersDAO.entity(item.id);
        }
        if (!item.id) {
            if (false) {
            } else {
                let uid = App.UniqueNumber();
                item.id = uid;
                if (!item.paymentTax) {
                    item.paymentTax = new PaymentTax();
                }
                item.paymentTax.id = uid;
            }
        } else {
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            if (oldItem.id != item.id) {
            } else {
            }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
