import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { ProfileDocs } from "../../entities/ProfileDocs";
import { ProfileDocsDAO } from "./../repos/ProfileDocsDAO";
import { Img } from "../../entities/Img";
import { FileDataDAO } from "./../repos/FileDataDAO";
import { ProfileDAO } from "../repos/ProfileDAO";
import { AddressDAO } from "../repos/AddressDAO";
import { ImgDAO } from "../repos/ImgDAO";
import { FileData } from "../../entities/FileData";
import { Address } from "../../entities/Address";

export class ProfileDocsService {
    public sessionInfo: any;
    private profileDocsDao: ProfileDocsDAO;
    private fileDataDAO: FileDataDAO;
    private profileDao: ProfileDAO;
    private addressDao: AddressDAO;
    private imgDao: ImgDAO;

    constructor() {
        this.profileDocsDao = new ProfileDocsDAO();
        this.profileDao = new ProfileDAO();
        this.fileDataDAO = new FileDataDAO();
        this.addressDao = new AddressDAO();
        this.imgDao = new ImgDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.profileDocsDao.findOne({
                profile: { id: id }
            });
            if (!data) {
                data = {};
                data.profile = await this.profileDao.entity(id);
                if (!data.profile) {
                    throw {
                        massage: Props.INVALID_DATA
                    };
                }
                data.docNumber = "";
                await this.save(data);
                data = await this.profileDocsDao.findOne({
                    profile: { id: id }
                });
            }

            return data;
        } catch (error) {
            throw error;
        }
    }
    async profileExist(element: any) {}

    async search(item: any) {
        try {
            //item.vid = this.sessionInfo.vid;
            let data: any = await this.profileDocsDao.search(item);
            let cond: any = {};
            let profileData = await this.profileDao.search(cond);
            profileData.forEach(element => {
                const index = data.findIndex((item: any) => item.profile.id == element.id);
                if (index < 0) {
                    data.push({ profile: element });
                }
            });
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: ProfileDocs) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                await this.addressDao.save(item.address);
                await this.imgDao.save(item.img);
                await this.fileDataDAO.save(item.fileData);
                let profileDocsData: any = await this.profileDocsDao.save(item);
                if (item.profile && item.profile.status) {
                    await this.profileDao.save({
                        id: item.profile.id,
                        status: item.profile.status
                    });
                }

                let returnData = {
                    id: item.id,
                    message: Props.SAVED_SUCCESSFULLY
                };
                return returnData;
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: ProfileDocs = await this.profileDocsDao.entity(id);
            let result: any = await this.profileDocsDao.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: ProfileDocs) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.profileDocsDao.entity(item.id);
        }
        if (!item.id) {
            if (false) {
            } else {
                let uid = item.profile.id;
                item.id = uid;
                if (!item.fileData) {
                    item.fileData = new FileData();
                }
                item.fileData.id = uid;
                if (!item.address) {
                    item.address = new Address();
                }
                item.address.id = uid;
                if (!item.img) {
                    item.img = new Img();
                }
                item.img.id = uid;
                item.img.refType = "profile";
            }
        } else {
            if (oldItem.id != item.id) {
            } else {
            }
        }
        item.updatedBy = this.sessionInfo.id;
        return true;
    }
}
