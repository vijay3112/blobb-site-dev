import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { PaymentAddon } from "../../entities/PaymentAddon";
import { PaymentAddonDAO } from "./../repos/PaymentAddonDAO";

export class PaymentAddonService {
    public sessionInfo: any;
    private paymentAddonDAO: PaymentAddonDAO;

    constructor() {
        this.paymentAddonDAO = new PaymentAddonDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.paymentAddonDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        if (!item.paymentId) {
            throw { message: "PaymentId is required" };
        }
        try {
            let data: any = await this.paymentAddonDAO.search(item);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: PaymentAddon) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                let paymentAddonData: any = await this.paymentAddonDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            }
            if (cond == "name") {
                throw { message: Props.RECORD_EXISTS };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            //let data: PaymentAddon = await this.paymentAddonDAO.entity(id);
            // data.updatedBy = this.sessionInfo.id;
            let result: any = await this.paymentAddonDAO.delete(id);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: PaymentAddon) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.paymentAddonDAO.entity(item.id);
        }
        //let condData = await this.paymentAddonDAO.search({ name: item.name });
        if (!item.id) {
            // if (condData.length > 0) {
            //     return "name";
            // } else {
            let uid = App.UniqueNumber();
            item.id = uid;
            // }
        } else {
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            // if(oldItem.name != item.name){
            //     if (condData.length > 0) {
            //         return "name";
            //     }
            // }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
