import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { Expenses } from "../../entities/Expenses";
import { ExpensesDAO } from "./../repos/ExpensesDAO";
import { FileDataDAO } from "../repos/FileDataDAO";
import { FileData } from "../../entities/FileData";

export class ExpensesService {
    public sessionInfo: any;
    private expensesDAO: ExpensesDAO;
    private fileDataDAO: FileDataDAO;

    constructor() {
        this.expensesDAO = new ExpensesDAO();
        this.fileDataDAO = new FileDataDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.expensesDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(item: any) {
        console.log("DFFTECH");
        console.log(item);
        try {
            let data: any = await this.expensesDAO.search(item);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: Expenses) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                if (item.fileData) {
                    let fileData: any = await this.fileDataDAO.save(item.fileData);
                }
                let expensesData: any = await this.expensesDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            }
            if (cond == "updated") {
                throw { message: Props.MISS_MATCH_MESSAGE };
            }
            if (cond == "name") {
                throw { message: Props.RECORD_EXISTS };
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: Expenses = await this.expensesDAO.entity(id);
            data.updatedBy = this.sessionInfo.id;
            let result: any = await this.expensesDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: Expenses) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.expensesDAO.entity(item.id);
        }
        //let condData = await this.expensesDAO.search({ name: item.name });
        if (!item.id) {
            // if (condData.length > 0) {
            //     return "name";
            // } else {
            let uid = App.UniqueNumber();
            item.id = uid;
            if (!item.fileData) {
                item.fileData = new FileData();
            }
            item.fileData.id = uid;
            item.fileData.refType = "Expenses";
            //}
        } else {
            if (item.updatedOn && oldItem.updatedOn.toISOString() != new Date(item.updatedOn).toISOString()) {
                return "updated";
            }
            // if(oldItem.name != item.name){
            //     if (condData.length > 0) {
            //         return "name";
            //     }
            // }
        }
        item.updatedBy = this.sessionInfo.id;
        item.updatedOn = new Date();
        return true;
    }
}
