import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { PropertyAmenities } from "../../entities/PropertyAmenities";
import { PropertyAmenitiesDAO } from "./../repos/PropertyAmenitiesDAO";
import { AmenitiesDAO } from "./../repos/AmenitiesDAO";

export class PropertyAmenitiesService {
    public sessionInfo: any;
    private propertyAmenitiesDAO: PropertyAmenitiesDAO;
    private amenitiesDAO: AmenitiesDAO;

    constructor() {
        this.propertyAmenitiesDAO = new PropertyAmenitiesDAO();
        this.amenitiesDAO = new AmenitiesDAO();
    }

    async entity(id: string) {
        try {
            let data: any = await this.propertyAmenitiesDAO.entity(id);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async search(params: any) {
        try {
            let query: any = {};
            if (params) {
                if (params.propertyId) {
                    query.property = { id: params.propertyId };
                }
            }
            let data: any = await this.propertyAmenitiesDAO.search(query);
            //let data: any = await this.propertyAmenitiesDAO.search(item);
            let cond: any = {};
            let amenitiesData = await this.amenitiesDAO.search(cond);
            amenitiesData.forEach(element => {
                const index = data.findIndex((item: any) => item.amenities.id == element.id);
                if (index < 0) {
                    data.push({ amenities: element });
                }
            });
            //let data: any = await this.propertyAmenitiesDAO.search(item);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async save(item: PropertyAmenities) {
        try {
            let cond = await this.validate(item);
            if (cond == true) {
                let propertyAmenitiesData: any = await this.propertyAmenitiesDAO.save(item);
                let returnData = { id: item.id, message: Props.SAVED_SUCCESSFULLY };
                return returnData;
            } else {
                throw { message: Props.INVALID_DATA };
            }
        } catch (error) {
            throw error;
        }
    }

    async delete(id: any) {
        try {
            let data: PropertyAmenities = await this.propertyAmenitiesDAO.entity(id);
            let result: any = await this.propertyAmenitiesDAO.delete(data);
            let returnData = { id: id, message: Props.REMOVED_SUCCESSFULLY };
            return returnData;
        } catch (error) {
            throw error;
        }
    }

    async validate(item: PropertyAmenities) {
        let oldItem: any = null;
        if (!item.id || item.id == "" || item.id == "0") {
            item.id = null;
        } else {
            oldItem = await this.propertyAmenitiesDAO.entity(item.id);
        }
        if (!item.id) {
            if (false) {
            } else {
                let uid = App.UniqueNumber();
                item.id = uid;
            }
        } else {
            if (oldItem.id != item.id) {
            } else {
            }
        }

        return true;
    }
}
