import { getManager, Any } from "typeorm";

export class RawQuery {
    static async SeqRec(code: string, type: string) {
        const query = `
          select id, replace(replace(replace(replace(format_code, 'BBBB', branch_code), 'FY', fy), 'TY', type),'XXXX', next_rec) as next_invoice
          from seq_rec where branch_code='${code}' and type='${type}';
        `;
        let data: any = await getManager().query(query);
        if (data && data[0]) {
            let id = data[0].id;
            const update_quary = `
              update seq_rec set next_rec = lpad((CONVERT(next_rec, UNSIGNED INTEGER) + 1) , 4, '0') where id = '${id}';
            `;
            await getManager().query(update_quary);
            return data[0].next_invoice;
        }
        return null;
    }

    static async SeqFY(code: string) {
        let fy = RawQuery.Fy();
        const update_quary = `
          update seq_rec set fy ='${fy}' , next_rec='0001'  where branch_code = '${code}';
        `;
        let data: any = await getManager().query(update_quary);
        return data;
    }

    static async SeqNew(code: string) {
        let fy = RawQuery.Fy();
        const querys = [
            `insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '${code}_CD', 'BBBBFYTY-XXXX', '${code}', '${fy}', 'CD', '0001')`,
            `insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '${code}_CH', 'BBBBFYTY-XXXX', '${code}', '${fy}', 'CH', '0001')`,
            `insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '${code}_SR', 'BBBBFYTY-XXXX', '${code}', '${fy}', 'SR', '0001')`,
            `insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '${code}_DN', 'BBBBFYTY-XXXX', '${code}', '${fy}', 'DN', '0001')`,
            `insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '${code}_CN', 'BBBBFYTY-XXXX', '${code}', '${fy}', 'CN', '0001')`,
            `insert into seq_rec(id, format_code, branch_code,  fy, type,  next_rec) values( '${code}_IN', 'BBBBFYTY-XXXX', '${code}', '${fy}', 'IN', '0001')`
        ];
        let data: any = null;
        for await (let query of querys) {
            data = await getManager().query(query);
        }
        return data;
    }

    static Fy() {
        var today = new Date();
        var curMonth = today.getMonth();
        // let fiscalYr: string = "";
        let fiscalYr = curMonth > 3 ? (today.getFullYear() + 1).toString() : today.getFullYear().toString();
        fiscalYr = fiscalYr.charAt(2) + fiscalYr.charAt(3);
        return fiscalYr;
    }
}

Object.seal(RawQuery);
