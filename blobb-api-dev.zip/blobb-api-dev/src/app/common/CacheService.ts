import { getManager } from "typeorm";
import NodeCache from "node-cache";
import { log } from "../../utils/Log";
import { WebMetadataDAO } from "../repos/WebMetadataDAO";
export class CacheService {
    private db: any;
    private static nodeCache: NodeCache;
    private webMetadataDAO: WebMetadataDAO;

    constructor() {
        this.db = getManager();
        this.webMetadataDAO = new WebMetadataDAO();

        this.init();
    }

    public static async Cache(key: any, value?: any) {
        if (!this.nodeCache) {
            this.nodeCache = new NodeCache({ stdTTL: 300, checkperiod: 120 });
        }
        if (value && value != null) {
            await this.nodeCache.set(key, value, 120);
            return null;
        } else {
            return await this.nodeCache.get(key);
        }
    }

    public static async UnSet(key: string) {
        if (!this.nodeCache) {
            this.nodeCache = new NodeCache({ stdTTL: 300, checkperiod: 120 });
        }
        if (key && key != null) {
            await this.nodeCache.del(key);
            return Promise.resolve(key);
        }
    }

    private async init() {
        let data = await CacheService.Cache("roomlock");
        if (!data) {
            await CacheService.Cache("roomlock", []);
        }
    }

    async web_metadata(param: any) {
        try {
            let cacheData: any = await CacheService.Cache("web_metaddata");
            let length = cacheData ? cacheData.length : -1;
            if (param == "Reload") {
                CacheService.Cache("web_metaddata", []);
                length = -1;
            }
            if (length == -1) {
                this.webMetadataDAO.search({}).then(data => {
                    CacheService.Cache("web_metaddata", data);
                });
            }
            return CacheService.Cache("web_metaddata");
        } catch (error) {
            throw error;
        }
    }

    // async roles(param: any) {
    //     try {
    //         console.log(param);
    //         const query = `select val, name from access_data where code='ROLE' and val != 'SUPER_ADMIN'`;
    //         let data: any = await this.db.query(query);
    //         console.log(data);
    //         return data;
    //     } catch (error) {
    //         throw error;
    //     }
    // }

    async lockroom(param: any) {
        let data = param.roomId;
        log.info("lockroom roomid: " + data);
        try {
            let roomId: any = await CacheService.Cache(data);
            if (roomId && roomId != null) {
                return { proceed: false };
            } else {
                CacheService.Cache(data, data);
                return { proceed: true };
            }
        } catch (error) {
            throw error;
        }

        //return { proceed: true };
    }
    async unlockroom(param: any) {
        let data = param.roomId;
        log.info("un lockroom roomid: " + data);
        try {
            let roomId: any = await CacheService.UnSet(data);
        } catch (error) {
            throw error;
        }
        // try {
        //     let lockIds: any = await CacheService.Cache("roomlock");
        //     log.info("cache lockIDS: " + lockIds);
        //     let index = lockIds.indexOf(data);
        //     if (index > -1) {
        //         console.log("unlock index: " + index);
        //         lockIds.splice(index, 1);
        //         await CacheService.Cache("roomlock", lockIds);
        //     }
        //     return { messsage: "" };
        // } catch (error) {
        //     throw error;
        // }
        return { proceed: true };
    }
}
