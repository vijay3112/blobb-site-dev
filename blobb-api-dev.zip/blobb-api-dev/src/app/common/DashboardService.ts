import { getManager, Any } from "typeorm";

export class DashboardService {
    public sessionInfo: any;
    private db: any;

    constructor() {
        this.db = getManager();
    }

    async byproperty() {
        let data: any = {};
        data.xAxis = ["Gachibowli", "JubliHills", "BanjaraHills"];
        data.series = ["200", "300", "100"];
        return Promise.resolve(data);
    }
    async series() {
        let data: any = {};
        data.xAxis = ["jan", "feb", "mar", "apr"];
        data.series = ["200", "300", "100", "500"];
        return Promise.resolve(data);
    }


    async expenses() {
        let expensesData: any = {};
        expensesData.legend = [ 'rose1', 'rose2', 'rose3', 'rose4' ];
        expensesData.series = ["200", "300", "100", "500"];
        return Promise.resolve(expensesData);
    }
}
