import { getManager } from "typeorm";

export class LoadService {
    public sessionInfo: any;

    private db: any;

    constructor() {
        this.db = getManager();
    }

    async roles(param: any) {
        try {
            console.log(param);
            const query = `select val, name from access_data where code='ROLE' and val != 'SUPER_ADMIN'`;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async codes(param: any) {
        try {
            const query = ` select val, name from access_data where code='CODE' and status=true `;
            let data: any = await this.db.query(query);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async country_codes(param: any) {
        try {
            console.log(param);
            const query = ` select id as val, name from app_data where code='COUNTRY_CODE' and active=true order by name ASC`;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async expenses_types(param: any) {
        try {
            console.log(param);
            const query = ` select id as val, name from app_data where code='EXPENSES_TYPE' and active=true order by name ASC `;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async verification_status(param: any) {
        try {
            console.log(param);
            const query = `  select val, name from access_data where code='VERIFICATION_STATUS' and status=true `;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async users(param: any) {
        try {
            console.log(param);
            const query = ` select id as val, name from profile where active=true and role='USER' `;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async profiles(param: any) {
        try {
            const query = ` select id, name, email, mobile, role, active from profile where role not in ('SUPER_ADMIN'); `;
            let data: any = await this.db.query(query);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async payment_modes(param: any) {
        try {
            const query = ` select id as val, name from app_data where code='PAYMENT_MODE' and active=true order by name ASC`;
            let data: any = await this.db.query(query);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async services_types(param: any) {
        try {
            console.log(param);
            const query = ` select id as val, name from app_data where code='SERVICE_TYPE' and active=true `;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async property_all(param: any) {
        try {
            console.log(param);
            const query = ` select id as val, name from property `;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }
    async property(param: any) {
        try {
            console.log(param);
            const query = ` select id as val, name from property where active=true `;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async supervisors(param: any) {
        try {
            console.log(param);
            const query = ` select id as val, name from profile where active=true and role='SUPERVISOR'`;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }

    async room_types(param: any) {
        try {
            console.log(param);
            const query = ` select val, name from access_data where code='ROOM_TYPE' and status=true `;
            let data: any = await this.db.query(query);
            console.log(data);
            return data;
        } catch (error) {
            throw error;
        }
    }
}
