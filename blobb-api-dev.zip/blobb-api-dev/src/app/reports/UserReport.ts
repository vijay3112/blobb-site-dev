import { getManager } from "typeorm";
import { log } from "../../utils/Log";
export class UserReport {
    public sessionInfo: any;
    private db: any;

    constructor() {
        this.db = getManager();
    }

    async execute(type: string, params: any) {
        try {
            console.log(params);
            const query = `select val, name from access_data where code='ROLE' and val != 'SUPER_ADMIN'`;
            let data: any = await this.db.query(query);
            return data;
        } catch (error) {
            throw error;
        }
    }
}
