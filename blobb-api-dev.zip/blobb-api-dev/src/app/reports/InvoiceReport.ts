import { getManager } from "typeorm";
import { log } from "../../utils/Log";
import { compareSync } from "bcryptjs";
import { App } from "../../utils/App";
import { RoomBookDAO } from "../repos/RoomBookDAO";
import { RoomOrdersDAO } from "../repos/RoomOrdersDAO";
import { RoomPersonsDAO } from "../repos/RoomPersonsDAO";

export class InvoiceReport {
    public sessionInfo: any;
    private db: any;
    // private roomBookDAO:any
    // private roomOrdersDAO:any
    // private roomPersonsDAO:any
    constructor() {
        this.db = getManager();
        // this.roomBookDAO = new RoomBookDAO()
        // this.roomOrdersDAO = new RoomOrdersDAO()
        // this.roomPersonsDAO = new RoomPersonsDAO()
    }

    async execute(params: any) {
        // try {
        //     let roomBookData = await this.roomBookDAO.findOne({id: params.id})
        //     roomBookData.fromDate = roomBookData.fromDate.toLocaleDateString()
        //     roomBookData.toDate = roomBookData.toDate.toLocaleDateString()
        //     let roomBookOrders = await this.roomOrdersDAO.search({roomBookId: params.id})
        //     let total:number = 0
        //     roomBookOrders.forEach((element:any) => {
        //         element.transactionDate = element.transactionDate.toLocaleDateString()
        //         total+=element.payment.amount
        //     });
        //     roomBookData.orders = roomBookOrders
        //     return roomBookData;
        // } catch (error) {
        //     throw error;
        // }

        try {

            let result: any = {};
            console.log(params);

            // roombook orders 
            let query = `SELECT p.name as profileName, pr.name as propertyName, DATE_FORMAT(rb.from_date,  
            '%d-%m-%Y') as fromDate, DATE_FORMAT(rb.to_date , '%d-%m-%Y')as toDate, rb.invoice_order as invoiceOrder, 
            rb.invoice_service as invoiceService, rb.show_gst as showGst , rb.amount as roomBookAmount,
            r.name as roomName, 
            py.units as units, py.cost as cost, py.price as price, py.cgst_price as cgstPrice, py.sgst_price as sgstPrice,
            py.amount as amount , py.discount_price as discountPrice, py.is_igst as isIgst
            FROM room_book rb 
            inner join profile p on p.id = rb.profile_id
            inner join room r on r.id = rb.room_id
            inner join property pr on pr.id = r.property_id
            inner join payment py on py.id = rb.payment_id
            where rb.id = '${params.id}'`;

            result.room = await this.db.query(query);

            console.table(result.room);

            if (result.room) {
                result.room = result.room[0];
                if (result.room.showGst != true) {
                    result.room.roomBookAmount = result.room.price - result.room.discountPrice;
                    result.room.cgstPrice = "0";
                    result.room.sgstPrice = "0";
                }
            }

            // room service orders 
            query = `SELECT 
            DATE_FORMAT(ro.transaction_date, '%d-%m-%Y') as transactionDate, o.name as orderName, 
            py.units as units,  py.cost as cost, py.price as price, py.cgst_price as cgstPrice, 
            py.sgst_price as sgstPrice, py.amount as amount , py.discount_price as discountPrice, 
            py.is_igst as isIgst
            FROM blobb_db.room_orders ro 
            inner join orders o on o.id = ro.orders_id
            inner join payment py on py.id = ro.payment_id
            where ro.room_book_id  = '${params.id}'`;

            result.orders = await this.db.query(query);

            result.showOrders = result.orders.length == 0 ? false : true;
            result.orderTotal = 0;
            result.orderTotalAlt = 0;
            result.orders.map((item: any) => {
                result.orderTotal = result.orderTotal + Number(item.amount);
             
                result.orderTotalAlt = result.orderTotalAlt + Number(item.price); // alternate for orderTotal if else in html
            });

            return result;

        } catch (error) {

            throw error;
        }

    }

    async report(result: any, params: any) {
        result.blobDetails = {
            accountName: "Blobb Spaces & Hospitality Services",
            bankName: "ICICI Bank",
            accountNumber: 111305500426,
            branch: "Ameerpet, Hyderabad",
            ifsc: "ICICI0001113",
            gstNo: "36AATFB6563E1Z5"
        };

        try {

            return App.HtmlRender("invoice", result);

        } catch (error) {
            throw error;
        }
    }
}
