import { Router, Request, Response } from "express";
import { App } from "../../utils/App";
import { Props } from "../../constants/Props";
import { FileDataService } from "../services/FileDataService";
import { FileData } from "../../entities/FileData";
import { FileDataSrc } from "../../entities/FileDataSrc";

export class FileDataController {
    private componentName: String = "FileData";
    private router: Router = Router();
    private service = new FileDataService();

    getRouter(): Router {
        this.router.get("/", async (request: Request, response: Response) => {
            try {
                let reqData: any;
                this.service.sessionInfo = request.body.sessionInfo;
                reqData = request.query ? request.query : {};
                let result: FileDataSrc = null;
                App.PrintLog(this.constructor.name, "Entity", this.service.sessionInfo);
                //  if (App.ValildateUserAccess(this.service.sessionInfo, this.componentName, Props.ACCESS_READ)) {
                result = await this.service.search(reqData);
                response.send({ status: 1, data: result });
            } catch (error) {
                console.log(error);
                response.send({ status: 0, error: error });
            }
        });

        this.router.get("/:id", async (request: Request, response: Response) => {
            try {
                const id: any = request.params.id;
                this.service.sessionInfo = request.body.sessionInfo;
                let result: FileDataSrc = null;
                App.PrintLog(this.constructor.name, "Entity", this.service.sessionInfo);
                //  if (App.ValildateUserAccess(this.service.sessionInfo, this.componentName, Props.ACCESS_READ)) {
                result = await this.service.entity(id);
                if (result && result.data) {
                    response.setHeader("Content-Type", result.mimetype);
                    response.setHeader("Content-Disposition", "inline; filename=%" + result.name);

                    response.send(result.data);
                } else {
                    throw result;
                }
                //  } else {
                //   throw this.service.sessionInfo ? this.service.sessionInfo : { message: Props.TOKEN_MESSAGE };
                // }
            } catch (error) {
                console.log(error);
                response.send(
                    "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIwIiBoZWlnaHQ9IjEyMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KCiA8Zz4KICA8dGl0bGU+YmFja2dyb3VuZDwvdGl0bGU+CiAgPHJlY3QgZmlsbD0ibm9uZSIgaWQ9ImNhbnZhc19iYWNrZ3JvdW5kIiBoZWlnaHQ9IjEyMiIgd2lkdGg9IjEyMiIgeT0iLTEiIHg9Ii0xIi8+CiA8L2c+CiA8Zz4KICA8dGl0bGU+TGF5ZXIgMTwvdGl0bGU+CiAgPHBhdGggc3Ryb2tlPSJudWxsIiB0cmFuc2Zvcm09InJvdGF0ZSgwLjk0NzE1MTQyMjUwMDYxMDQgNTkuNTU1ODczODcwODQ3OCw1OC44Mzk1NDIzODg5MTU4NCkgIiBpZD0ic3ZnXzEiIGZpbGw9IiMzQjk3RDMiIGQ9Im01OS41NTU4NzQsNi44Mzk1NDFjLTI4LjcsMCAtNTIsMjMuMyAtNTIsNTJzMjMuMyw1MiA1Miw1MnM1MiwtMjMuMyA1MiwtNTJzLTIzLjMsLTUyIC01MiwtNTJ6bTAsMTAwYy0yNi41LDAgLTQ4LC0yMS41IC00OCwtNDhzMjEuNSwtNDggNDgsLTQ4czQ4LDIxLjUgNDgsNDhzLTIxLjUsNDggLTQ4LDQ4eiIvPgogIDxwYXRoIGlkPSJzdmdfMiIgZmlsbD0iIzJDM0U1MCIgZD0ibTU5LjY5OTE0LDc0LjY4MjgwOGMtMC40LDAgLTAuNywtMC4yIC0wLjksLTAuNmMtMC40LC0wLjkgLTEwLjMsLTIyLjcgLTEwLjMsLTQwLjVjMCwtNi4yIDUsLTExLjIgMTEuMiwtMTEuMnMxMS4yLDUgMTEuMiwxMS4yYzAsMTcuOCAtOS45LDM5LjYgLTEwLjMsNDAuNWMtMC4yLDAuNCAtMC41LDAuNiAtMC45LDAuNnptMCwtNTAuMmMtNS4xLDAgLTkuMiw0LjEgLTkuMiw5LjJjMCwxNC4yIDYuNywzMS42IDkuMiwzNy41YzIuNSwtNS45IDkuMiwtMjMuMyA5LjIsLTM3LjVjMCwtNS4xIC00LjEsLTkuMiAtOS4yLC05LjJ6Ii8+CiAgPHBhdGggaWQ9InN2Z18zIiBmaWxsPSIjMkMzRTUwIiBkPSJtNTkuNjk5MTQsOTUuNDgyODA4Yy00LjQsMCAtOC4xLC0zLjYgLTguMSwtOC4xczMuNiwtOC4xIDguMSwtOC4xczguMSwzLjYgOC4xLDguMXMtMy43LDguMSAtOC4xLDguMXptMCwtMTQuMWMtMy4zLDAgLTYuMSwyLjcgLTYuMSw2LjFjMCwzLjMgMi43LDYuMSA2LjEsNi4xYzMuMywwIDYuMSwtMi43IDYuMSwtNi4xYzAsLTMuNCAtMi44LC02LjEgLTYuMSwtNi4xeiIvPgogPC9nPgo8L3N2Zz4="
                );
            }
        });
        this.router.post("/", async (request: Request, response: Response) => {
            try {
                let reqData: any = {};
                console.log("------------fileupload start------------------");
                if (request.body.fileData) {
                    request.body.fileData = JSON.parse(request.body.fileData);
                } else {
                    throw { message: "Data not found." };
                }
                console.log(request.body.fileData);
                if (request.files && request.files.file) {
                    let file: any = request.files.file;
                    reqData.name = file.name;
                    reqData.mimetype = file.mimetype;
                    reqData.data = file.data;
                    reqData.id = request.body.fileData.id;
                    reqData.ref = request.body.fileData.ref;
                    reqData.refType = request.body.fileData.refType;
                } else {
                    throw { message: "File not found." };
                }
                this.service.sessionInfo = request.body.sessionInfo;
                App.PrintLog(this.constructor.name, "SAVE", this.service.sessionInfo);
                let result = null;
                if (App.ValildateUserAccess(this.service.sessionInfo, this.componentName, Props.ACCESS_WRITE)) {
                    result = await this.service.save(reqData);
                } else {
                    throw this.service.sessionInfo ? this.service.sessionInfo : { message: Props.TOKEN_MESSAGE };
                }
                response.send({ status: 1, data: result });
            } catch (error) {
                console.log(error);
                response.send({ status: 0, error: error });
            }
        });

        return this.router;
    }
}
