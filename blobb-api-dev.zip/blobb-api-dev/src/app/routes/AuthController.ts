import { Router, Request, Response } from "express";
import { App } from "../..//utils/App";
import { AuthService } from "../services/AuthService";

export class AuthController {
    private router: Router = Router();
    private authService: AuthService;
    constructor() {
        this.authService = new AuthService();
    }
    checkProceed(request: Request) {}
    getRouter(): Router {
        this.router.post("/signup", async (request: Request, response: Response) => {
            let reqData: any = request.body;
            let sessionInfo: any = {};
            let result: any = null;
            console.log(reqData);
            if (reqData) {
                this.authService.sessionInfo = { id: "system" };
                result = this.authService.signup(reqData.data);
            } else {
                result = { message: "Invalid Data" };
            }
            //App.Send(request, response, result);
            result.then((data: any) => {
                response.send(data);
            });
            result.catch((error: any) => {
                response.send({ status: 0, error: error });
            });
        });

        this.router.post("/verifyemail", async (request: Request, response: Response) => {
            let reqData: any = request.body;
            let sessionInfo: any = {};
            let result: any = null;
            if (reqData) {
                this.authService.sessionInfo = sessionInfo;
                result = this.authService.VerifyEmail(reqData.data);
            } else {
                result = { message: "Invalid Data" };
            }
            //App.Send(request, response, result);
            result.then((data: any) => {
                console.log(data);
                response.send(data);
            });
            result.catch((error: any) => {
                response.send({ status: 0, error: error });
            });
        });
        this.router.post("/token", async (request: Request, response: Response) => {
            try {
                let reqData: any = request.body;
                let result: any = null;
                if (reqData) {
                    result = await this.authService.refreshToken(reqData);
                } else {
                    throw { message: "Invalid Data" };
                }
                response.send({ status: 1, data: result });
            } catch (error) {
                response.send({ status: 0, error: error });
            }
        });

        this.router.post("/", async (request: Request, response: Response) => {
            let reqData: any = request.body;
            let sessionInfo: any = {};
            let result: any = null;
            if (reqData) {
                this.authService.sessionInfo = sessionInfo;
                result = this.authService.retrieve(reqData);
            } else {
                result = { message: "Invalid Data" };
            }
            //App.Send(request, response, result);
            result.then((data: any) => {
                response.send(data);
            });
            result.catch((error: any) => {
                response.send({ status: 0, error: error });
            });
        });

        //Forgot Password Controller
        this.router.get("/", async (request: Request, response: Response) => {
            let reqData: any = request.query;

            // let sessionInfo: any = {};
            let result: any = null;
            // console.log(reqData.data);
            if (reqData) {
                result = this.authService.forgotPassword(reqData);
            } else {
                result = { message: "Invalid Data" };
            }
            console.log(result);
            App.Send(request, response, result);
        });

        //Reset Password
        this.router.put("/", async (request: Request, response: Response) => {
            let reqData: any = request.body;
            let result: any = null;
            console.log(reqData.data);
            if (reqData.data) {
                result = this.authService.resetPassword(reqData.data);
            } else {
                result = { message: "Invalid Data" };
            }
            App.Send(request, response, result);
        });
        return this.router;
    }
}
