import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { RoomBook } from "./RoomBook";
import { FileData } from "./FileData";
import { Img } from "./Img";

@Entity("room_persons")
export class RoomPersons {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "name" })
    name: string;

    @Column({ name: "email" })
    email: string;

    @Column({ name: "mobile" })
    mobile: string;

    @Column({ name: "doc" })
    doc: string;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "room_book_id" })
    @ManyToOne(type => RoomBook)
    roomBook: RoomBook;

    @JoinColumn({ name: "file_data_id" })
    @ManyToOne(type => FileData, {
        onDelete: "CASCADE"
    })
    fileData: FileData;

    @JoinColumn({ name: "img_id" })
    @ManyToOne(type => Img, {
        onDelete: "CASCADE"
    })
    img: Img;
}
