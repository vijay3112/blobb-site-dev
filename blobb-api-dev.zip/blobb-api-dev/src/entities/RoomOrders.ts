import {Entity, PrimaryColumn, Column, ManyToOne, JoinColumn} from "typeorm";

import { Orders } from "./Orders";
import { Payment } from "./Payment";
import { RoomBook } from "./RoomBook";  

@Entity("room_orders")
export class RoomOrders { 
    @PrimaryColumn({name: "id"}) 
    id: string;

    @Column({name: "transaction_date"}) 
    transactionDate: Date;

    @Column({name: "summary"}) 
    summary: string;

    @Column({name: "updated_by"}) 
    updatedBy: string;

    @Column({name: "updated_on"}) 
    updatedOn: Date;
 
    @JoinColumn({name: "orders_id"})
    @ManyToOne(type => Orders)
    orders: Orders;

    @JoinColumn({name: "payment_id"})
    @ManyToOne(type => Payment)
    payment: Payment;

    @JoinColumn({name: "room_book_id"})
    @ManyToOne(type => RoomBook)
    roomBook: RoomBook;
  
}

