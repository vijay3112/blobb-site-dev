import {Entity, PrimaryColumn, Column, ManyToOne, JoinColumn} from "typeorm";

@Entity("web_metadata")
export class WebMetadata {
@PrimaryColumn({name: "id"})
id: string;

    @Column({name: "page"})
    page: string;

    @Column({name: "keywords"})
    keywords: string;

    @Column({name: "summary"})
    summary: string;

    @Column({name: "updated_on"})
    updatedOn: Date;

    @Column({name: "updated_by"})
    updatedBy: string;

}