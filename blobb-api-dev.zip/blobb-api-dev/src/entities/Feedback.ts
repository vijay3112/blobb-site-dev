import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { Profile } from "./Profile";

@Entity("feedback")
export class Feedback {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "rate_us" })
    rateUs: number;

    @Column({ name: "summary" })
    summary: string;

    @Column({ name: "branch" })
    branch: string;

    @Column({ name: "active" })
    active: boolean;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "profile_id" })
    @ManyToOne(type => Profile)
    profile: Profile;

}

