import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { Profile } from "./Profile";
import { WebMetadata } from "./WebMetadata";
import { Address } from "./Address";

@Entity("property")
export class Property {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "name" })
    name: string;

    @Column({ name: "type" })
    type: string;

    @Column({ name: "location" })
    location: string;

    @Column({ name: "summary" })
    summary: string;

    @Column({ name: "map_location" })
    mapLocation: string;

    @Column({ name: "gst_no" })
    gstNo: string;

    @Column({ name: "active" })
    active: boolean;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "supervisor_id" })
    @ManyToOne(type => Profile)
    supervisor: Profile;

    @JoinColumn({ name: "address_id" })
    @ManyToOne(type => Address)
    address: Address;
}
