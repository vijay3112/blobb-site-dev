import {Entity, PrimaryColumn, Column, ManyToOne, JoinColumn} from "typeorm";
  

@Entity("payment_tax")
export class PaymentTax { 
    @PrimaryColumn({name: "id"}) 
    id: string;

    @Column({name: "cost"}) 
    cost: number;

    @Column({name: "cgst"}) 
    cgst: number;

    @Column({name: "sgst"}) 
    sgst: number;

    @Column({name: "igst"}) 
    igst: number;

    @Column({name: "ref_type"}) 
    refType: string;
   
}

