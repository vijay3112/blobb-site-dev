import {Entity, PrimaryColumn, Column, ManyToOne, JoinColumn} from "typeorm";

import { Property } from "./Property";
import { Amenities } from "./Amenities";  

@Entity("property_amenities")
export class PropertyAmenities { 
    @PrimaryColumn({name: "id"}) 
    id: string;

    @Column({name: "active"}) 
    active: boolean;
 
    @JoinColumn({name: "property_id"})
    @ManyToOne(type => Property)
    property: Property;

    @JoinColumn({name: "amenities_id"})
    @ManyToOne(type => Amenities)
    amenities: Amenities;
  
}

