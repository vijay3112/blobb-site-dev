import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";
import { PaymentAddon } from "./PaymentAddon";

@Entity("payment")
export class Payment {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "type" })
    type: string;

    @Column({ name: "cost" })
    cost: number;

    @Column({ name: "units" })
    units: number;

    @Column({ name: "price" })
    price: number;

    @Column({ name: "cgst" })
    cgst: number;

    @Column({ name: "sgst" })
    sgst: number;

    @Column({ name: "igst" })
    igst: number;
    
    @Column({ name: "discount" })
    discount: string;

    @Column({ name: "cgst_price" })
    cgstPrice: number;

    @Column({ name: "sgst_price" })
    sgstPrice: number;

    @Column({ name: "igst_price" })
    igstPrice: number;

    @Column({ name: "discount_price" })
    discountPrice: string;

    @Column({ name: "amount" })
    amount: number;

    @Column({ name: "is_igst" })
    isIgst: boolean;

    @Column({ name: "ref" })
    ref: string;

    @Column({ name: "ref_type" })
    refType: string;

    @Column({ name: "status" })
    status: string;

    @Column({ name: "created_by" })
    createdBy: string;

    @Column({ name: "created_on" })
    createdOn: Date;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    paymentAddonList: PaymentAddon[] = [];
}
