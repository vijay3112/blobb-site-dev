import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { AppData } from "./AppData";
import { FileData } from "./FileData";

@Entity("expenses")
export class Expenses {
  @PrimaryColumn({ name: "id" })
  id: string;

  @Column({ name: "txn_date" })
  txnDate: Date;

  @Column({ name: "to_whom" })
  toWhom: string;

  @Column({ name: "amount" })
  amount: number;
  
  @Column({ name: "branch" })
  branch: string;

  @Column({ name: "updated_by" })
  updatedBy: string;

  @Column({ name: "updated_on" })
  updatedOn: Date;
  @JoinColumn({ name: "type_id" })
  @ManyToOne(type => AppData)
  type: AppData;

  @JoinColumn({ name: "file_data_id" })
  @ManyToOne(type => FileData)
  fileData: FileData;
}
