import {Entity, PrimaryColumn, Column, ManyToOne, JoinColumn} from "typeorm";

import { Payment } from "./Payment";  

@Entity("payment_addon")
export class PaymentAddon { 
    @PrimaryColumn({name: "id"}) 
    id: string;

    @Column({name: "type"}) 
    type: string;

    @Column({name: "amount"}) 
    amount: number;

    @Column({name: "summary"}) 
    summary: string;

    @Column({name: "updated_by"}) 
    updatedBy: string;

    @Column({name: "updated_on"}) 
    updatedOn: Date;
 
    @JoinColumn({name: "payment_id"})
    @ManyToOne(type => Payment)
    payment: Payment;
  
}

