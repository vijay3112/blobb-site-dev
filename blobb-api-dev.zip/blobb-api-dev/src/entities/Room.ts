import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { Flat } from "./Flat";
import { Property } from "./Property";
import { PaymentTax } from "./PaymentTax";

@Entity("room")
export class Room {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "name" })
    name: string;

    @Column({ name: "type" })
    type: string;

    @Column({ name: "ext_phone" })
    extPhone: string;

    @Column({ name: "channel_manger_active" })
    channelMangerActive: boolean;

    @Column({ name: "persons" })
    persons: number;

    @Column({ name: "addon_persons" })
    addonPersons: number;

    @Column({ name: "addon_persons_cost" })
    addonPersonsCost: number;

    @Column({ name: "summary" })
    summary: string;

    @Column({ name: "active" })
    active: boolean;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "flat_id" })
    @ManyToOne(type => Flat)
    flat: Flat;

    @JoinColumn({ name: "property_id" })
    @ManyToOne(type => Property)
    property: Property;

    @JoinColumn({ name: "payment_tax_id" })
    @ManyToOne(type => PaymentTax)
    paymentTax: PaymentTax;

    isLock: boolean = false;
}
