import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { Property } from "./Property";
import { PaymentTax } from "./PaymentTax";

@Entity("orders")
export class Orders {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "name" })
    name: string;

    @Column({ name: "type" })
    type: string;

    @Column({ name: "active" })
    active: boolean;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "property_id" })
    @ManyToOne(type => Property)
    property: Property;

    @JoinColumn({ name: "payment_tax_id" })
    @ManyToOne(type => PaymentTax)
    paymentTax: PaymentTax;
}
