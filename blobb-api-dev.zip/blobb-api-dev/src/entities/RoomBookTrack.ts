import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { RoomBook } from "./RoomBook";

@Entity("room_book_track")
export class RoomBookTrack {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "status" })
    status: string;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({name: "room_book_id"})
    @ManyToOne(type => RoomBook)
    roomBook: RoomBook;
}
