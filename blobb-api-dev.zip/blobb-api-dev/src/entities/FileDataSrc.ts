import { Entity, PrimaryColumn, Column } from "typeorm";

@Entity("file_data")
export class FileDataSrc {
  @PrimaryColumn({ name: "id" })
  id: string;

  @Column({ name: "name" })
  name: string;

  @Column({ name: "mimetype" })
  mimetype: string;

  @Column({ name: "is_secure" })
  isSecure: boolean = false;

  @Column({ name: "data" })
  data: BinaryType;

  @Column({ name: "ref" })
  ref: string;

  @Column({ name: "ref_type" })
  refType: string;
}
