import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { Profile } from "./Profile";
import { Payment } from "./Payment";
import { Room } from "./Room";

@Entity("room_book")
export class RoomBook {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "invoice_order" })
    invoiceOrder: string;

    @Column({ name: "invoice_service" })
    invoiceService: string;

    @Column({ name: "book_type" })
    bookType: string;

    @Column({ name: "from_date" })
    fromDate: Date;

    @Column({ name: "to_date" })
    toDate: Date;

    @Column({ name: "advance" })
    advance: number;

    @Column({ name: "balance" })
    balance: number;

    @Column({ name: "price" })
    price: number;

    @Column({ name: "cgst_price" })
    cgstPrice: number;

    @Column({ name: "sgst_price" })
    sgstPrice: number;

    @Column({ name: "igst_price" })
    igstPrice: number;

    @Column({ name: "amount" })
    amount: number;

    @Column({ name: "status" })
    status: string;

    @Column({ name: "active" })
    active: boolean;

    @Column({ name: "show_gst" })
    showGst: boolean;

    @Column({ name: "created_by" })
    createdBy: string;

    @Column({ name: "created_on" })
    createdOn: Date;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "profile_id" })
    @ManyToOne(type => Profile)
    profile: Profile;

    @JoinColumn({ name: "payment_id" })
    @ManyToOne(type => Payment)
    payment: Payment;

    @JoinColumn({ name: "room_id" })
    @ManyToOne(type => Room)
    room: Room;
}
