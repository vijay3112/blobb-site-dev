import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { Profile } from "./Profile";
import { FileData } from "./FileData";
import { Address } from "./Address";
import { Img } from "./Img";

@Entity("profile_docs")
export class ProfileDocs {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "doc_number" })
    docNumber: string;

    @Column({ name: "exp_date" })
    expDate: Date;

    @Column({ name: "dob" })
    dob: Date;

    @Column({ name: "gender" })
    gender: string;

    @Column({ name: "account_number" })
    accountNumber: string;

    @Column({ name: "bank_name" })
    bankName: string;

    @Column({ name: "bank_branch" })
    bankBranch: string;

    @Column({ name: "swift_code" })
    swiftCode: string;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "profile_id" })
    @ManyToOne(type => Profile)
    profile: Profile;

    @JoinColumn({ name: "file_data_id" })
    @ManyToOne(type => FileData)
    fileData: FileData;

    @JoinColumn({ name: "address_id" })
    @ManyToOne(type => Address)
    address: Address;

    @JoinColumn({ name: "img_id" })
    @ManyToOne(type => Img)
    img: Img;
}
