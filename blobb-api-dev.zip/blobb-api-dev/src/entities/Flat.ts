import { Entity, PrimaryColumn, Column, ManyToOne, JoinColumn } from "typeorm";

import { Property } from "./Property";
import { Room } from "./Room";

@Entity("flat")
export class Flat {
    @PrimaryColumn({ name: "id" })
    id: string;

    @Column({ name: "name" })
    name: string;

    @Column({ name: "floor" })
    floor: string;

    @Column({ name: "active" })
    active: boolean;

    @Column({ name: "updated_by" })
    updatedBy: string;

    @Column({ name: "updated_on" })
    updatedOn: Date;

    @JoinColumn({ name: "property_id" })
    @ManyToOne(type => Property)
    property: Property;

    rooms: Room[] = [];
}
