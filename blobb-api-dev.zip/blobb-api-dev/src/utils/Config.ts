import "reflect-metadata";

// setx/export ENV_BLOBB = { "dbHost": "localhost", "dbPort": "3306", "dbUser": "blobb_user", "dbPassword": "blobb!234"}
export let dbOptions: any = {
    name: "default",
    type: "mysql",
    host: "prd.dfftech.com",
    port: 3306,
    username: "blobb_user",
    password: "Blobb!234",
    database: "blobb_db",
    logging: true,
    synchronize: false,
    entities: [__dirname + "/../entities/**/*{.ts,.js}"]
};

export let mailOptions: any = {
    host: "smtp.zoho.com",
    port: 465,
    user: "noreply@dfftech.com",
    pass: "Tech!234" 
};

export var logOptions = {
    file: {
        level: "debug",
        filename: "/tmp/blobb-app.log",
        handleExceptions: true,
        json: false,
        maxsize: 10485760,
        maxfiles: 5000
    },
    console: {
        level: "debug",
        handleExceptions: true,
        json: false,
        colorize: true
    }
};

export let setEnvConfig = () => {
    let envData: any = process.env.ENV_BLOBB;
    console.log("-------------------------------------------------");
    console.log("ENV_DATA: "+ envData);
    if (envData) {
        envData = JSON.parse(envData);
        if (envData.dbHost) {
            dbOptions.host = envData.dbHost;
            dbOptions.port = envData.dbPort;
            dbOptions.username = envData.dbUser;
            dbOptions.password = envData.dbPassword;
        }

        if (envData.mailHost) {
            mailOptions.host = envData.mailHost;
            mailOptions.port = envData.mailPort;
            mailOptions.user = envData.mailUser;
            mailOptions.pass = envData.mailPassword;
        }
    }
    console.log(dbOptions);
    console.log("-------------------------------------------------");
};
