import { createLogger, format, transports } from "winston";

import { logOptions } from "./Config";
export const log = createLogger({
    exitOnError: false,
    format: format.combine(
        format.timestamp({
            format: "YYYY-MM-DDTHH:mm:ss"
        }),
        format.simple()
    ),
    transports: [
        new transports.File(logOptions.file),
        new transports.Console(logOptions.console)
    ]
});
