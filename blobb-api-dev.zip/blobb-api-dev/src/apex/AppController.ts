import { Router } from "express";
import { LoadController } from "./LoadController";
import { CacheController } from "./CacheController";
import { AppReport } from "./AppReport";
import { WebController } from "./WebController";
import * as fs from "fs";
import { log } from "../utils/Log";
import { DashboardController } from "./DashboardController";

export class AppController {
    private router: Router = Router();
    routes = fs.readdirSync(`${__dirname}/../app/routes`);

    async getRouter() {
        this.router.use("/load", await new LoadController().getRouter());
        this.router.use("/report", await new AppReport().getRouter());
        this.router.use("/cache", await new CacheController().getRouter());
        this.router.use("/web", await new WebController().getRouter());
        this.router.use("/dashboard", await new DashboardController().getRouter());
        let route: any;
        for (route of this.routes) {
            route = route.slice(0, -3);
            let path = `/${route.replace("Controller", "").toLowerCase()}`;
            let action = `../app/routes/${route}`;
            var ns = await import(action);
            log.info(path);
            this.router.use(path, new ns[route]().getRouter());
        }
        return this.router;
    }
}
