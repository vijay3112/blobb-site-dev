import JsReport from "jsreport-core";
import { Router, Request, Response } from "express";
import * as fs from "fs";
import { log } from "../utils/Log";

export class AppReport {
    private router: Router = Router();
    private service: any = null;
    private jsreport = JsReport();
    private report: Promise<JsReport.Reporter> = null;

    private reports = fs.readdirSync(`${__dirname}/../app/reports`);
    constructor() {
        log.info("AppReport constructor");
        this.jsreport.use(require("jsreport-chrome-pdf")());
        this.report = this.jsreport.init();
    }
    getRouter(): Router {
        this.router.get("/:code/:type", async (request: Request, response: Response) => {
            try {
                let code = request.params.code;
                let type = request.params.type;
                let reqData = request.query ? request.query : {};
                let resData: any = null;
                log.info("report: " + code + " --> type: " + type);
                let report: any;
                let dataFound: boolean = false;
                for (report of this.reports) {
                    report = report.slice(0, -3);
                    if (report.toLowerCase() == code + "report") {
                        dataFound = true;
                        let action = `../app/reports/${report}`;
                        var ns = await import(action);
                        resData = await new ns[report]().execute(reqData);
                        if (type != "data") {
                            resData = await new ns[report]().report(resData, reqData);
                        }
                        break;
                    }
                }
                if (dataFound == true) {
                    if (type == "data") {
                        response.send({ status: 1, data: resData });
                    } else if (type == "pdf") {
                        this.report
                            .then(() => {
                                return this.jsreport
                                    .render({
                                        template: {
                                            content: resData,
                                            engine: "none",
                                            recipe: "chrome-pdf"
                                        }
                                    })
                                    .then(out => {
                                        out.stream.pipe(response);
                                    })
                                    .catch(err => {
                                        log.error(err);
                                        throw err;
                                    });
                            })
                            .catch(err => {
                                log.error(err);
                                throw err;
                            });
                    } else if (type == "html") {
                        this.report
                            .then(() => {
                                return this.jsreport
                                    .render({
                                        template: {
                                            content: resData,
                                            engine: "none",
                                            recipe: "html"
                                        }
                                    })
                                    .then(out => {
                                        out.stream.pipe(response);
                                    })
                                    .catch(err => {
                                        log.error(err);
                                        throw err;
                                    });
                            })
                            .catch(err => {
                                log.error(err);
                                throw err;
                            });
                    }
                } else {
                    throw { message: "No Report Found!!!" };
                }
            } catch (error) {
                log.error(error);
                error = typeof error == "string" ? { message: error } : error;
                response.send({ status: 0, error: error });
            }
        });
        return this.router;
    }

    // async getRouter() {
    //     await this.routes.forEach(async route => {
    //         route = route.slice(0, -3);
    //         let path = `/${route.replace("Controller", "").toLowerCase()}`;
    //         let action = `../app/routes/${route}`;
    //         var ns = await import(action);
    //         this.router.use(path, new ns[route]().getRouter());
    //     });
    //     this.router.use("/load", new AccessLoadController().getRouter());
    //     return this.router;
    // }
}
